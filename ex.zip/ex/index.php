<?php

if(isset($_GET['pbutton']))
{
    session_start();
    $_SESSION['psch'] = strtolower("examicom_".$_GET['sch']);
    $_SESSION['user'] = $_GET['user'];
    $_SESSION['pdep'] = $_GET['department'];
    $_SESSION['ptype'] = $_GET['type'];
    $_SESSION['plevel'] = $_GET['level'];
    $_SESSION['ptitle'] = $_GET['sub'];
    
    header("location: test");
}

?>
<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from colorlib.com/etc/creative-agency/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 06 Nov 2018 14:05:12 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Exami - Nigeria's No.1 CBT Platform</title>
        <link rel="shortcut icon" type="img/png" href="img/icon-196x1961.png">
        <link rel="shortcut icon" sizes="196x196" href="img/icon-196x1961.png">
        <link rel="apple-touch-icon" href="img/icon-196x1961.png">

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CVarela+Round" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Owl Carousel -->
	<link type="text/css" rel="stylesheet" href="css/owl.carousel.css" />
	<link type="text/css" rel="stylesheet" href="css/owl.theme.default.css" />

	<!-- Magnific Popup -->
	<link type="text/css" rel="stylesheet" href="css/magnific-popup.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />
        <link type="text/css" rel="stylesheet" href="css/studentloginbox.css" />

	
</head>

<body>
	<!-- Header -->
	<header id="home">
		<!-- Background Image -->
		<div class="bg-img" style="background-image: url('img/back.png');">
			<div class="overlay"></div>
		</div>
		<!-- /Background Image -->

		<!-- Nav -->
		<nav id="nav" class="navbar nav-transparent">
			<div class="container">

				<div class="navbar-header">
					<!-- Logo -->
					<div class="navbar-brand">
						<a href="../exami/">
                                                    <img class="logo" src="img/exlogo.png" alt="logo">
                                                    <img class="logo-alt" src="img/extlogwhite.png" alt="logo">
						</a>
					</div>
					<!-- /Logo -->

					<!-- Collapse nav button -->
					<div class="nav-collapse">
						<span></span>
					</div>
					<!-- /Collapse nav button -->
				</div>

				<!--  Main navigation  -->
				<ul class="main-nav nav navbar-nav navbar-right">
					<li><a href="#home">Home</a></li>
					<li><a href="#about">About</a></li>
					
					<li><a href="#service">Services</a></li>
					<li><a href="#contact">Contact</a></li>
				</ul>
				<!-- /Main navigation -->

			</div>
		</nav>
		<!-- /Nav -->
                <!-- The Modal for studentslogin -->
  <div class="modal fade" id="studentslogin">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Student's Login Box</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
                                                             <div class="form stu_login">
                                                        <div class="alert alert-danger col-sm-12" id="errorMessage4"></div>
                                                        <div class="alert alert-success col-sm-12" id="successMessage4"></div>
                                                                    <form class="login-form" onsubmit="loginstudent(); return false;">
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                           <input class="form-control" type="text" name="student_username" id="student_username" placeholder="Username" required=""/>
                                                                        </div>
                                                           <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-graduation-cap"></i></span>
                                                           <select class="form-control" name="student_school_name" id="student_school_name" required="">
                                                               <option value="" selected="">SELECT SCHOOL</option>
                                                               <?php
                                                               require_once 'classes/config.php';
                                                               $getSchools = new config("examicom_records");
                                                               $getSchools = $getSchools->execute_return("SELECT school_name FROM schools");
                                                               for($i = 0; $i<count($getSchools); $i++)
                                                               {
                                                                   echo '<option value="'.$getSchools[$i]["school_name"].'">'.$getSchools[$i]["school_name"].'</option>';
                                                               }
                                                               ?>
                                                           </select>
                                                           </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                                           <input class="form-control" type="password" name="student_password" id="student_password" placeholder="password" required=""/>
                                                                        </div>
                                                           <button id="student_login_button">login</button>
                                                           <div id="loader_box4"><i class="fa fa-spin fa-2x"><img style="height: 50px; width: 50px;" src="img/exlogo.png"/></i></div>
                                                          
                                                         </form>
                                                       </div>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
                
                
                <!-- The Modal for studentslogin -->
  <div class="modal fade" id="practice">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Select Options Below</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
                                                             <div class="">
                                                        
                                                                 <form class="login-form"  method="GET" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                                                                 <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                           <input class="form-control" type="text" name="user" id="user" placeholder="Username" required=""/>
                                                                        </div>      
                                                           <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-graduation-cap"></i></span>
                                                           <select class="form-control" name="sch" onchange="setDep(this.value);" id="sch" required="">
                                                               <option value="" selected="">SELECT SCHOOL</option>
                                                               <?php
                                                               require_once 'classes/config.php';
                                                               $getSchools = new config("examicom_records");
                                                               $getSchools = $getSchools->execute_return("SELECT school_name FROM schools");
                                                               for($i = 0; $i<count($getSchools); $i++)
                                                               {
                                                                   echo '<option value="'.$getSchools[$i]["school_name"].'">'.$getSchools[$i]["school_name"].'</option>';
                                                               }
                                                               ?>
                                                           </select>
                                                           </div>
                                                                     <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setType(this.value);" class="form-control" id="department" name="department" required="">
                                                       <option value="" selected="">SELECT DEPARTMENT</option>
                                                   </select> </div>
                                                                     <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setLevel(this.value);" class="form-control" id="type" name="type" required="">
                                                       <option value="" selected="">SELECT TYPE</option>
                                                   </select> </div>
                                                                     <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select class="form-control" onchange="setSub(this.value);" id="level" name="level" required="">
                                                       <option value="" selected="">SELECT LEVEL</option>
                                                   </select></div>
            
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select class="form-control" id="sub" name="sub" required="">
                                                       <option value="" selected="">SELECT SUBJECT</option>
                                                   </select></div>
                                                                        
                                                                     <div style="text-align: center;"><button class="btn btn-success" name="pbutton">Start</button></div>
                                                          
                                                         </form>
                                                       </div>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
                                
                
 
                                
                <!-- The Modal for teacherslogin -->
  <div class="modal fade" id="teacherslogin">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Staffs's Login Box</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
                                                                       <div class="form s_login">
                                                        <div class="alert alert-danger col-sm-12" id="errorMessage2"></div>
                                                        <div class="alert alert-success col-sm-12" id="successMessage2"></div>
                                                                    <form class="login-form" onsubmit="loginstaff(); return false;">
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                           <input class="form-control" type="text" name="staff_username" id="staff_username" placeholder="Username" required=""/>
                                                                        </div>
                                                           <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-graduation-cap"></i></span>
                                                           <select class="form-control" name="staff_school_name" id="staff_school_name" required="">
                                                               <option value="" selected="">SELECT SCHOOL</option>
                                                               <?php
                                                               require_once 'classes/config.php';
                                                               $getSchools = new config("examicom_records");
                                                               $getSchools = $getSchools->execute_return("SELECT school_name FROM schools");
                                                               for($i = 0; $i<count($getSchools); $i++)
                                                               {
                                                                   echo '<option value="'.$getSchools[$i]["school_name"].'">'.$getSchools[$i]["school_name"].'</option>';
                                                               }
                                                               ?>
                                                           </select>
                                                           </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                                           <input class="form-control" type="password" name="staff_password" id="staff_password" placeholder="password" required=""/>
                                                                        </div>
                                                           <button id="staff_login_button">login</button>
                                                           <div id="loader_box2"><i class="fa fa-spin fa-2x"><img style="height: 50px; width: 50px;" src="img/exlogo.png"/></i></div>
                                                          
                                                         </form>
                                                       </div>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
                

                
                <!-- The Modal for Institutionsregistration -->
  <div class="modal fade" id="institutionsregistration">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Institution's Registration / Login Box</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
                                                        <div class="form i_login">
                                                            <div style="float:left; font-size: 90%; position: relative; top:-10px"><a href="activate_account.php">Activate account</a></div>
                                                        <div style="float:right; font-size: 90%; position: relative; top:-10px"><a href="#">Forgot password?</a></div>
                                                        <br>
                                                        <div class="alert alert-danger col-sm-12" id="errorMessage1"></div>
                                                        <div class="alert alert-success col-sm-12" id="successMessage1"></div>
                                                                    <form class="login-form" onsubmit="loginadmin(); return false;">
                                                                       
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                           <input class="form-control" type="text" name="admin_username1" id="admin_username1" placeholder="Username" required=""/>
                                                                        </div>
                                                           <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-graduation-cap"></i></span>
                                                           <select class="form-control" name="admin_school_name1" id="admin_school_name1" required="">
                                                               <option value="" selected="">SELECT SCHOOL</option>
                                                               <?php
                                                               require_once 'classes/config.php';
                                                               $getSchools = new config("examicom_records");
                                                               $getSchools = $getSchools->execute_return("SELECT school_name FROM schools");
                                                               for($i = 0; $i<count($getSchools); $i++)
                                                               {
                                                                   echo '<option value="'.$getSchools[$i]["school_name"].'">'.$getSchools[$i]["school_name"].'</option>';
                                                               }
                                                               ?>
                                                           </select>
                                                           </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                                           <input class="form-control" type="password" name="admin_password1" id="admin_password1" placeholder="password" required=""/>
                                                                        </div>
                                                           <button id="admin_login_button">login</button>
                                                           <div id="loader_box1"><i class="fa fa-spin fa-2x"><img style="height: 50px; width: 50px;" src="img/exlogo.png"/></i></div>
                                                           <a href="#" onclick="show_reg();">Click here to register..</a>
                                                         </form>
                                                       </div>
            
                                                                       <div class="form i_reg">
                                                                           <div class="alert alert-danger col-sm-12" id="errorMessage"></div>
                                                                            <div class="alert alert-success col-sm-12" id="successMessage"></div>
                                                                           <form class="reg-form-institute" onsubmit="register(); return false;">
                                                                               <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                                           <input class="form-control" type="text" name="admin_username" id="admin_username" placeholder="Username" required=""/>
                                                                               </div>
                                                                               <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-graduation-cap"></i></span>
                                                           <input class="form-control" type="text" name="admin_school_name" id="admin_school_name" placeholder="School Name" required=""/>
                                                                               </div>
                                                                               <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-caret-down"></i></span>
                                                           <select class="form-control" name="admin_school_type" id="admin_school_type" required="">
                                                               <option value="">School Type</option>
                                                               <option value="university">University</option>
                                                               <option value="polytechnic">Polytechnic</option>
                                                               <option value="college_of_education">College of Education</option>
                                                               <option value="organization">Organization</option>
                                                               <option value="senior_secondary_school">Senior Secondary School</option>
                                                               <option value="others">Others</option>
                                                           </select>
                                                                               </div>
                                                                               <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                                           <input class="form-control" type="email" name="admin_school_email" id="admin_school_email" placeholder="School Email Address" required=""/>
                                                                               </div>
                                                                               <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                                                               <input class="form-control" type="text" name="admin_school_telephone" id="admin_school_telephone" placeholder="School Telephone Number" required=""/>
                                                                               </div>
                                                                               <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-link"></i></span>
                                                                               <input class="form-control" type="text" name="admin_school_website" id="admin_school_website" placeholder="School Website Address(http or https ://www.domainname.com" required=""/>
                                                                               </div>
                                                                               <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                                                               <input class="form-control" type="password" name="admin_password" id="admin_password" placeholder="password" required=""/>
                                                                               </div>
                                                                               <button id="admin_button">Register</button>
                                                                               <div id="loader_box"><i class="fa fa-spin fa-2x"><img style="height: 50px; width: 50px;" src="img/exlogo.png"/></i></div>
                                                                               <a href="#" onclick="show_login();">Click here to login..</a>
                                                         </form>
                                                       </div>
            
                                                        
        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  

		<!-- home wrapper -->
		<div class="home-wrapper">
			<div class="container">
				<div class="row">

					<!-- home content -->
					<div class="col-md-10 col-md-offset-1">
						<div class="home-content">
							<h1 class="white-text">EXAMI</h1>
							<p class="white-text">Nigeria's No.1 CBT Platform
							</p>
							<button class="white-btn" data-toggle="modal" data-target="#studentslogin">Student</button>
							<button class="white-btn" data-toggle="modal" data-target="#teacherslogin">Staff</button>
                                                        <button class="white-btn" data-toggle="modal" data-target="#institutionsregistration">Institution</button>
                                                        <div class="home-content" style="text-align: center;">
                                                            <button class="white-btn" style="border-radius: 40px; webkit-border-radius: 40px; moz-border-radius: 40px;" data-toggle="modal" data-target="#practice">Test Yourself</button>
                                                        </div>
                                                </div>
					</div>
					<!-- /home content -->

				</div>
			</div>
		</div>
		<!-- /home wrapper -->

	</header>
	<!-- /Header -->

	<!-- About -->
	<div id="about" class="section md-padding">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- Section header -->
				<div class="section-header text-center">
					<h2 class="title">Welcome to Exami</h2>
				</div>
				<!-- /Section header -->

				<!-- about -->
				<div class="col-md-4">
					<div class="about">
						<i class="fa fa-cogs"></i>
						<h3>Full Exam Flexibility</h3>
						<p>To administrators, staffs and students</p>
					</div>
				</div>
				<!-- /about -->

				<!-- about -->
				<div class="col-md-4">
					<div class="about">
						<i class="fa fa-magic"></i>
						<h3>Awesome Features</h3>
						<p>Administrator management, staffs and student management, exam modes, exam result showing answers selected and correct answers.</p>
						
					</div>
				</div>
				<!-- /about -->

				<!-- about -->
				<div class="col-md-4">
					<div class="about">
						<i class="fa fa-mobile"></i>
						<h3>Fully Responsive</h3>
						<p>Can be used on any device.</p>
					</div>
				</div>
				<!-- /about -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /About -->


	
	<!-- Service -->
	<div id="service" class="section md-padding">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- Section header -->
				<div class="section-header text-center">
					<h2 class="title">What we offer</h2>
				</div>
				<!-- /Section header -->

				<!-- service -->
				<div class="col-md-4 col-sm-6">
					<div class="service">
						<i class="fa fa-desktop"></i>
						<h3>Online CBT exams</h3>
						<p>Register with Exami today and stop using papers, join the moving train of online examination writing.</p>
					</div>
				</div>
				<!-- /service -->

				<!-- service -->
				<div class="col-md-4 col-sm-6">
					<div class="service">
						<i class="fa fa-rocket"></i>
						<h3>99.9% Up-Time</h3>
						<p>Exami is available 24Hrs a day and 7 days a week (24/7).</p>
					</div>
				</div>
				<!-- /service -->

				<!-- service -->
				<div class="col-md-4 col-sm-6">
					<div class="service">
						<i class="fa fa-hand-o-right"></i>
						<h3>Trust</h3>
						<p>Bent on delievering quality services to online examination writing</p>
					</div>
				</div>
				<!-- /service -->

				

				<!-- service -->
				<div class="col-md-4 col-sm-6">
					<div class="service">
						<i class="fa fa-question"></i>
						<h3>Awesome Support</h3>
						<p>24/7 assistance from Exami.</p>
					</div>
				</div>
				<!-- /service -->

				<!-- service -->
				<div class="col-md-4 col-sm-6">
					<div class="service">
						<i class="fa fa-flask"></i>
						<h3>Reducing Exam Malpractice</h3>
						<p>Measures are taken on this platform to greatly reduce exam malpractices..</p>
					</div>
				</div>
				<!-- /service -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /Service -->


	<!-- Why Choose Us -->
	<div id="features" class="section md-padding bg-grey">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- why choose us content -->
				<div class="col-md-12">
					<div class="section-header">
						<h2 class="title">Why Choose Us</h2>
					</div>
					<p>Molestie at elementum eu facilisis sed odio. Scelerisque in dictum non consectetur a erat. Aliquam id diam maecenas ultricies mi eget mauris. Ultrices sagittis orci a scelerisque purus.</p>
					<div class="feature">
						<i class="fa fa-check"></i>
						<p>Quis varius quam quisque id diam vel quam elementum.</p>
					</div>
					<div class="feature">
						<i class="fa fa-check"></i>
						<p>Mauris augue neque gravida in fermentum.</p>
					</div>
					<div class="feature">
						<i class="fa fa-check"></i>
						<p>Orci phasellus egestas tellus rutrum.</p>
					</div>
					<div class="feature">
						<i class="fa fa-check"></i>
						<p>Nec feugiat nisl pretium fusce id velit ut tortor pretium.</p>
					</div>
				</div>
				<!-- /why choose us content -->

				
				<!-- /About slider -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /Why Choose Us -->



	<!-- Contact -->
	<div id="contact" class="section md-padding">

		<!-- Container -->
		<div class="container">

			<!-- Row -->
			<div class="row">

				<!-- Section-header -->
				<div class="section-header text-center">
					<h2 class="title">Get in touch</h2>
				</div>
				<!-- /Section-header -->

				<!-- contact -->
				<div class="col-sm-4">
					<div class="contact">
						<i class="fa fa-phone"></i>
						<h3>Phone</h3>
						<p>000-000000</p>
					</div>
				</div>
				<!-- /contact -->

				<!-- contact -->
				<div class="col-sm-4">
					<div class="contact">
						<i class="fa fa-envelope"></i>
						<h3>Email</h3>
						<p><a class="__cf_email__" data-cfemail="f89d95999194b88b8d8888978a8cd69b9795">[email&#160;protected]</a></p>
					</div>
				</div>
				<!-- /contact -->

				<!-- contact -->
				<div class="col-sm-4">
					<div class="contact">
						<i class="fa fa-map-marker"></i>
						<h3>Address</h3>
						<p>267, Iyana ipaja road, agege, Lagos. Nigeria</p>
					</div>
				</div>
				<!-- /contact -->

				<!-- contact form -->
				<div class="col-md-8 col-md-offset-2">
					<form class="contact-form">
						<input type="text" class="input" placeholder="Name">
						<input type="email" class="input" placeholder="Email">
						<input type="text" class="input" placeholder="Subject">
						<textarea class="input" placeholder="Message"></textarea>
						<button class="main-btn">Send message</button>
					</form>
				</div>
				<!-- /contact form -->

			</div>
			<!-- /Row -->

		</div>
		<!-- /Container -->

	</div>
	<!-- /Contact -->
        <script>
                      function setDep(e)
    {
         document.getElementById("department").value = "";
        document.getElementById("type").value = "";
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "ajax_to_php_connectors/pdetails.php",
        type: "post",
        data: "data=dep"+"&school="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("department").innerHTML ="<option value='' selected>Select Department</option>";
          document.getElementById("department").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
            function setType(e)
    {
        document.getElementById("type").value = "";
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "ajax_to_php_connectors/pdetails.php",
        type: "post",
        data: "data=type"+"&department="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("type").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("type").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel(e)
    {
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "ajax_to_php_connectors/pdetails.php",
        type: "post",
        data: "data=level"+"&type="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("level").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("level").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
     function setSub(e)
    {
        document.getElementById("sub").value = "";
        
         $.ajax({
        url: "ajax_to_php_connectors/pdetails.php",
        type: "post",
        data: "data=sub"+"&level="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("sub").innerHTML ="<option value='' selected>Select Subject</option>";
          document.getElementById("sub").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
            
            </script>
<?php include_once 'footer.php'; ?>
