<?php


session_start();

if(isset($_SESSION['paper']))
{
    include_once '../classes/config.php';
    $p = $_SESSION['paper'];
    $u = $_SESSION['user'];
    $ctime =    new config($_SESSION['sn']);
        $ctime->execute_no_return("UPDATE `ptimer` set h='0', m='0', s='0' WHERE username='$u' AND title='$p'");
        
        unset($_SESSION['paper']);
        unset($_SESSION['nquestion']);
        header("location: index.php");
}
 else {
header("location: index.php");    
}

?>