<?php 
$title = "Exam";

if(isset($_POST['usess']))
{
    session_start();
    $sn = $_POST['sn'];
    $_SESSION['nquestion'] = (int)$sn;
    $URL="exam.php";
    echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
}
if(isset($_POST['sendanswer']))
{
   
    if(isset($_POST['ans']))
    {
        session_start();
        include_once '../classes/config.php';
        $ans = strtolower($_POST['ans']);
        $sch = preg_replace('/\s+/', '_', $_SESSION['psch']);
        $qNo = $_POST['question'];
        $pap =  $_SESSION['paper'];
        $student = $_SESSION['user'];
        
        $d = $_SESSION['pdep'];
        $t = $_SESSION['ptype'];
        $l = $_SESSION['plevel'];
        $mark = "";
        //get pass
        $gpaa = new config($sch);
           $gpaa = $gpaa->execute_return("SELECT answer FROM pquestions WHERE title='$pap' AND sn='$qNo' AND department='$d' AND type='$t' AND level='$l'");
        if($gpaa[0]['answer'] == $ans)
        {
            $mark = "pass";
        }
        else
        {
            $mark = "fail";
        }
        
        
        //check if update or insert
        $cexist = new config($sch);
        $cexist = $cexist->execute_count_no_return("SELECT COUNT(*) FROM pexam_table WHERE student_username='$student' AND title='$pap' AND sn='$qNo'");
        
        if($cexist == 1)
        {
            //update
            $ustudent = new config($sch);
            $ustudent->execute_no_return("UPDATE `pexam_table` SET ans='$ans', mark='$mark' WHERE student_username='$student' AND title='$pap' AND sn='$qNo'");
            if((int)$qNo < $_SESSION['quests'])
            {
                $_SESSION['nquestion'] = $_SESSION['nquestion'] + 1;
            }
            
        }
        else
        {
            
            
            //insert
            $istudent = new config($sch);
            $istudent->execute_no_return("INSERT INTO `pexam_table`(`student_username`, `title`, `sn`, `ans`, `mark`) VALUES ('$student','$pap','$qNo','$ans', '$mark')");
            
            if((int)$qNo < $_SESSION['quests'])
            {
                $_SESSION['nquestion'] = $_SESSION['nquestion'] + 1;
            }
        }
    }
    else
    {
        
        session_start();
        include_once '../classes/config.php';
        $qNo = $_POST['question'];
        $use = $_SESSION['user'];
        $sna = preg_replace('/\s+/', '_', $_SESSION['psch']);
        
       $d = $_SESSION['pdep'];
        $t = $_SESSION['ptype'];
        $l = $_SESSION['plevel'];
        $e = $_SESSION['paper'];
        $getdQ = new config($sna);
        $getdQ = $getdQ->execute_return("SELECT questions FROM exam WHERE title='$e' AND department='$d' AND type='$t' AND level='$l'");
        $qq = (int)$getdQ[0]['questions'];
        if((int)$qNo < $qq)
            {
                $_SESSION['nquestion'] = $_SESSION['nquestion'] + 1;
            }
           
    
    }
   $URL="exam.php";
    echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
}
require_once 'header.php'; 
if(isset($_SESSION['ptitle']))
{
   
    $_SESSION['paper'] = $_SESSION['ptitle'];
    
    unset($_SESSION['ptitle']);
    $URL="exam.php";
    echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
}




if(!isset($_SESSION['paper']))
{
    
     $URL="../students";
    echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
}

   $paper =      $_SESSION['paper'];                        
   $duse = $_SESSION['user'];
   $dep = $dd;
   $typ = $tt;
   $lev = $ll;
   
//check if time is exhausted
$gettime = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
        $gettime = $gettime->execute_return("SELECT * FROM ptimer WHERE title='$paper' AND username='$duse'");
        
        if(count($gettime) > 0)
        {
            $h = (int)$gettime[0]['h'];
        $m = (int)$gettime[0]['m'];
        $s = (int)$gettime[0]['s'];
        if($h == 0 && $m == 0 && $s == 0)
        {
            $URL="../students";

            unset($_SESSION['paper']);
            unset($_SESSION['nquestion']);
             echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
        }
        }
        
//exam number of questions
$getq = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
        $getq = $getq->execute_return("SELECT * FROM exam WHERE title='$paper' AND department='$dep' AND type='$typ' AND level='$lev'");
        $dq = (int)$getq[0]['questions'];
        $aq = (int)$getq[0]['answers'];
        $is = $getq[0]['instruction'];
        $_SESSION['quests'] = $dq;
        
//select next questiom
    $nquestion =    new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
    $nquestion = $nquestion->execute_return("SELECT * FROM pexam_table WHERE student_username='$duse' AND title = '$paper' ORDER BY sn DESC LIMIT 1");
   
  if(!isset($_SESSION['nquestion']))
  {
        if(count($nquestion) <=0)
    {
        $_SESSION['nquestion'] = 1;
    }
 else {
         $_SESSION['nquestion'] =$dq;
     
     
     
        
}
  }
//when not clicked

    
    if(!isset( $_SESSION['quiz']))
    {
        $_SESSION['quiz']=date('H:i:s');
    }

?>

	
<style>
    input:radio
    {
        height: 30px;
        width: 30px;
    }
    .quesno{
        height: auto;
        background: #ffffff;
        padding-top: 4px;
        text-align: center;
    }
</style>
	<!-- Highlights - jumbotron -->
        <div class="jumbotron top-space" style="margin-top: 100px; background: #ffffff !important;">
            <div class="container">
			
                    <div class="row">
                    
                        <style>
                            #hour, #min, #sec
                            {
                                padding: 6px;
                                background-color: #00ad5f;
                                margin-right: 4px;
                                font-weight: bold;
                                font-size: 1em;
                                color: #ffffff;
                            }
                           
                            </style>
                        <div class="col-sm-12 questions">
                            <div style="text-align: center;">Time Remaining:&nbsp;<span id="hour"></span><span id="min"></span><span id="sec"></span></div>
                            <h2 style="text-align:center; font-weight: bold;"><?php echo $paper; ?></h2>
                            <h4 style="text-align:center;">Instruction: <?php echo $is; ?></h4>
           
            
                            <div class="card">
                                <div class="head" style="text-align: center"> <h3>Question
                                    <?php echo $_SESSION['nquestion']; ?></h3>
                                </div>
                                <div class="card-body" style="text-align: center;">
                                    <?php
                                    $snn = $_SESSION['nquestion'];
                                        $gtQ =  new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                    $gtQ = $gtQ->execute_return("SELECT * FROM `pquestions` WHERE sn='$snn' AND title='$paper' AND department='$dep' AND type='$typ' AND level='$lev'");
                                    if($gtQ[0]['image'] != "")
                                    {
                                        echo "<img style='height: 300px; width: 500px;' src='../staffs/".preg_replace('/\s+/', '_', $_SESSION['sn'])."/".$gtQ[0]['image'].".png' /> ";
                                    }
                                    echo "<h4 style='text-align: center; font-weight: bold;'> ".$gtQ[0]['question']."</h4>";
                                    if($aq == 2)
                                    {
                                        $checifansset = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                        $checifansset = $checifansset->execute_return("SELECT * FROM pexam_table WHERE sn = '$snn' AND student_username='$duse' AND title = '$paper'");
                                        if(count($checifansset) > 0)
                                        {
                                            //check if german
                                            $german = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                            $german = $german->execute_count_no_return("SELECT COUNT(*) FROM `pquestions` WHERE a='' AND b='' AND sn='$snn' AND title='$paper' AND department='$dep' AND type='$typ' AND level='$lev'");
                                            if($german == 1)
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                         <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />  
                                                             <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input name="ans" value="'.$checifansset[0]['ans'].'" style="width: 400px; margin-bottom: 5px; font-weight: bold; height: 30px;" type="text"/> <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                 
                                            }
                                            else if($checifansset[0]['ans'] == "a")
                                            {
                                               echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                         <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />  
                                                             <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i></div>
                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                            }
                                            else
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i></div>
                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                          
                                            }
                                            
                                  
                                        }
                                        else{
                                            //check if german
                                            $german = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                            $german = $german->execute_count_no_return("SELECT COUNT(*) FROM `pquestions` WHERE a='' AND b='' AND sn='$snn' AND title='$paper' AND department='$dep' AND type='$typ' AND level='$lev'");
                                            if($german == 1)
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                         <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />  
                                                             <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input name="ans" style="width: 400px; margin-bottom: 5px; font-weight: bold; height: 30px;" type="text"/> <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                 
                                            }
                                            else
                                            {
                                             echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i></div>
                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                       
                                  
                                        }
                                        }
                                          }
                                          else if($aq == 3)
                                    {
                                        $checifansset = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                        $checifansset = $checifansset->execute_return("SELECT * FROM pexam_table WHERE sn = '$snn' AND student_username='$duse' AND title = '$paper'");
                                        if(count($checifansset) > 0)
                                        {
                                            //check if german
                                            $german = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                            $german = $german->execute_count_no_return("SELECT COUNT(*) FROM `pquestions` WHERE a='' AND b='' AND c='' AND sn='$snn' AND title='$paper' AND department='$dep' AND type='$typ' AND level='$lev'");
                                            if($german == 1)
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                         <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />  
                                                             <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input name="ans" value="'.$checifansset[0]['ans'].'" style="width: 400px; margin-bottom: 5px; font-weight: bold; height: 30px;" type="text"/> <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                 
                                            }
                                            else if($checifansset[0]['ans'] == "a")
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i></div>
                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                       
                                            }
                                            else if($checifansset[0]['ans'] == "b")
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i></div>
                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                       
                                            }
                                            else
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i></div>
                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                       
                                         }
                                            
                                  
                                        }
                                        else{
                                            //check if german
                                            $german = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                            $german = $german->execute_count_no_return("SELECT COUNT(*) FROM `pquestions` WHERE a='' AND b='' AND c='' AND sn='$snn' AND title='$paper' AND department='$dep' AND type='$typ' AND level='$lev'");
                                            if($german == 1)
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                         <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />  
                                                             <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input name="ans" style="width: 400px; margin-bottom: 5px; font-weight: bold; height: 30px;" type="text"/> <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                 
                                            }
                                            else
                                            {
                                            echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i></div>
                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                         }
                                        }
                                          }
                                          else if($aq == 4)
                                    {
                                        $checifansset = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                        $checifansset = $checifansset->execute_return("SELECT * FROM pexam_table WHERE sn = '$snn' AND student_username='$duse' AND title = '$paper'");
                                        if(count($checifansset) > 0)
                                        {
                                            //check if german
                                            $german = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                            $german = $german->execute_count_no_return("SELECT COUNT(*) FROM `pquestions` WHERE a='' AND b='' AND c='' AND d='' AND sn='$snn' AND title='$paper' AND department='$dep' AND type='$typ' AND level='$lev'");
                                            if($german == 1)
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                         <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />  
                                                             <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input name="ans" value="'.$checifansset[0]['ans'].'" style="width: 400px; margin-bottom: 5px; font-weight: bold; height: 30px;" type="text"/> <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                 
                                            }
                                            else if($checifansset[0]['ans'] == "a")
                                            {
                                                echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" checked  name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i>
                                                          &nbsp;<input value="d" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">D. '.$gtQ[0]['d'].'</i></div>
</div>                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            '; }
                                            else if($checifansset[0]['ans'] == "b")
                                            {
                                                echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i>
                                                          &nbsp;<input value="d" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">D. '.$gtQ[0]['d'].'</i></div>
</div>                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';  }
                                            else if($checifansset[0]['ans'] == "c")
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i>
                                                          &nbsp;<input value="d" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">D. '.$gtQ[0]['d'].'</i></div>
</div>                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';        }
                                            else
                                            {
                                                echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i>
                                                          &nbsp;<input value="d" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">D. '.$gtQ[0]['d'].'</i></div>
</div>                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';   }
                                            
                                  
                                        }
                                        else{
                                            
                                            //check if german
                                            $german = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                           $german = $german->execute_count_no_return("SELECT COUNT(*) FROM `pquestions` WHERE a='' AND b='' AND c='' AND d='' AND sn='$snn' AND title='$paper' AND department='$dep' AND type='$typ' AND level='$lev'");
                                            if($german == 1)
                                            {
                                                
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                         <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />  
                                                             <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input name="ans" style="width: 400px; margin-bottom: 5px; font-weight: bold; height: 30px;" type="text"/> <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                 
                                            }
                                            else
                                            {
                                          echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i>
                                                          &nbsp;<input value="d" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">D. '.$gtQ[0]['d'].'</i></div>
</div>                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            '; }
                                        }
                                          }
                                          else
                                          {
                                               $checifansset = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                        $checifansset = $checifansset->execute_return("SELECT * FROM pexam_table WHERE sn = '$snn' AND student_username='$duse' AND title = '$paper'");
                                        if(count($checifansset) > 0)
                                        {
                                            //check if german
                                            $german = new config(preg_replace('/\s+/', '_', $_SESSION['ptitle']));
                                            $german = $german->execute_count_no_return("SELECT COUNT(*) FROM `pquestions` WHERE a='' AND b='' AND c='' AND d='' AND e='' AND sn='$snn' AND title='$paper' AND department='$dep' AND type='$typ' AND level='$lev'");
                                            if($german == 1)
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                         <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />  
                                                             <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input name="ans" value="'.$checifansset[0]['ans'].'" style="width: 400px; margin-bottom: 5px; font-weight: bold; height: 30px;" type="text"/> <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                 
                                            }
                                            else if($checifansset[0]['ans'] == "a")
                                            {
                                                echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i>
                                                          &nbsp;<input value="d" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">D. '.$gtQ[0]['d'].'</i></div>
</div>                                                         &nbsp;<input value="e" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">E. '.$gtQ[0]['e'].'</i></div>
</div>                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                            }
                                            else if($checifansset[0]['ans'] == "b")
                                            {
                                                echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i>
                                                          &nbsp;<input value="d" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">D. '.$gtQ[0]['d'].'</i></div>
</div>                                                         &nbsp;<input value="e" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">E. '.$gtQ[0]['e'].'</i></div>
</div>                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                            }
                                            else if($checifansset[0]['ans'] == "c")
                                            {
                                                echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i>
                                                          &nbsp;<input value="d" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">D. '.$gtQ[0]['d'].'</i></div>
</div>                                                         &nbsp;<input value="e" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">E. '.$gtQ[0]['e'].'</i></div>
</div>                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                            }
                                            else if($checifansset[0]['ans'] == "d")
                                            {
                                               echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i>
                                                          &nbsp;<input value="d" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">D. '.$gtQ[0]['d'].'</i></div>
</div>                                                         &nbsp;<input value="e" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">E. '.$gtQ[0]['e'].'</i></div>
</div>                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                         }
                                         else
                                         {
                                             echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a"  name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i>
                                                          &nbsp;<input value="d" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">D. '.$gtQ[0]['d'].'</i></div>
</div>                                                         &nbsp;<input value="e" checked name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">E. '.$gtQ[0]['e'].'</i></div>
</div>                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                     
                                         }
                                            
                                  
                                        }
                                        else{
                                            //check if german
                                            $german = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                            $german = $german->execute_count_no_return("SELECT COUNT(*) FROM `pquestions` WHERE a='' AND b='' AND c='' AND d='' AND e='' AND sn='$snn' AND title='$paper' AND department='$dep' AND type='$typ' AND level='$lev'");
                                            if($german == 1)
                                            {
                                                 echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                         <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />  
                                                             <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input name="ans" style="width: 400px; margin-bottom: 5px; font-weight: bold; height: 30px;" type="text"/> <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';
                                 
                                            }
                                            else
                                            {
                                          echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="danswer" method="post" enctype="multipart/form-data" >      
                                                            <input type="hidden" name="schooler" value ="'.$_SESSION['sn'].'" />
                                                                <input type="hidden" name="question" value ="'.$_SESSION['nquestion'].'" />  
                                                                 <input type="hidden" name="paper" value ="'.$_SESSION['paper'].'" />  
                                                                        <div style="margin-bottom: 25px; text-align:center;">
                                                           &nbsp;<input value="a"  name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">A. '.$gtQ[0]['a'].'</i>
                                                           &nbsp;<input value="b" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">B. '.$gtQ[0]['b'].'</i>
                                                               &nbsp;<input value="c" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">C. '.$gtQ[0]['c'].'</i>
                                                          &nbsp;<input value="d" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">D. '.$gtQ[0]['d'].'</i></div>
</div>                                                         &nbsp;<input value="e" name="ans" style="width: 30px; font-weight: bold; height: 30px;" type="radio"/>&nbsp;<i style="font-size: 1em !important;">E. '.$gtQ[0]['e'].'</i></div>
</div>                                                          <div style="text-align: center;"><button type="submit" class="btn btn-primary" name="sendanswer">Save</button></div>
                                                                        </form>
            ';  }
                                        }
                                          }
                                    
                                    ?>
                                </div>
                            </div>
                            
                        </div>
                            
                            <br>
                                <div class="col-sm-12 quesno" style="overflow-x: scroll;">
                            
                            <?php
                            $questioner =    new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
    $questioner = $questioner->execute_return("SELECT * FROM pexam_table WHERE student_username='$duse' AND title = '$paper'");
                           if(count($questioner) > 0)
                           {
                                for($s=1; $s<=$dq; $s++)
                            {
                                if($s == $_SESSION['nquestion'])
                                {
                                    $dd=    new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
    $dd = $dd->execute_return("SELECT * FROM pexam_table WHERE student_username='$duse' AND title = '$paper' AND sn='$s' LIMIT 1");
                                     if($_SESSION['nquestion'] == $dq && count($dd) > 0)
        {
             echo '
                            <form style="float:left; margin-right: 3px; margin-bottom: 3px; text-align:" action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" method="POST"><input name="sn" type="hidden" value="'.$s.'" /><button name="usess" class="btn-success" type="submit">Q'.$s.'</button></form>';
                                    
                                
        }
        else
        {
             echo '
                            <form style="float:left; margin-right: 3px; margin-bottom: 3px;" action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" method="POST"><input name="sn" type="hidden" value="'.$s.'" /><button name="usess" class="" type="submit">Q'.$s.'</button></form>';
                                    
                                
        }
                                   }
                                else
                                {
                                    $qler =    new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
    $qler = $qler->execute_return("SELECT * FROM pexam_table WHERE student_username='$duse' AND title = '$paper' AND sn='$s'");
    if(count($qler) >0)
    {
         echo '
                            <form style="float:left; margin-right: 3px; margin-bottom: 3px;" action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" method="POST"><input name="sn" type="hidden" value="'.$s.'" /><button name="usess" class="btn-success" type="submit">Q'.$s.'</button></form>';
                                    
    }
    else
    {
       
        
         echo '
                            <form style="float:left;margin-right: 3px; margin-bottom: 3px;" action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" method="POST"><input name="sn" type="hidden" value="'.$s.'" /><button name="usess" class="btn-danger" type="submit">Q'.$s.'</button></form>';
                                    
    }
                                }
                                
                            }
                           }
                           else
                           {
                                for($s=1; $s<=$dq; $s++)
                            {
                               if($s == $_SESSION['nquestion'])
                                {
                                    echo '
                            <form style="float:left; margin-right: 3px; margin-bottom: 3px;" action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" method="POST"><input name="sn" type="hidden" value="'.$s.'" /><button name="usess" class="" type="submit">Q'.$s.'</button></form>';
                                    
                                }else
                                {
                                    echo '
                            <form style="float:left; margin-right: 3px; margin-bottom: 3px;" action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" method="POST"><input name="sn" type="hidden" value="'.$s.'" /><button name="usess" class="btn-danger" type="submit">Q'.$s.'</button></form>';
                                    
                                }
                                        
                            
                            }
                           }
                            
                            ?>
                            
                        </div>
                            
                    </div>
                    
		
		</div>
	</div>
	<!-- /Highlights -->

	<script language ="javascript" >
    <?php
date_default_timezone_set("Africa/Lagos");
              $start=$_SESSION['quiz'];
              
              $end=date('Y-m-d H:i:s', strtotime( $_SESSION['quiz'] . ' +20 minutes' ) );
                echo "
                    var date_quiz_start='$start';
                    var date_quiz_end='$end';
                    var time_quiz_end=new Date('$end').getTime();";
      
        
        //check if username has time already
                $u = $_SESSION['user'];
                $p = $_SESSION['paper'];
        $ctime =    new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
        $ctime = $ctime->execute_return("SELECT * FROM ptimer WHERE username='$u' and title='$p'");
        if(count($ctime) > 0)
        {
            echo 'var tim;
        var hour= '.$ctime[0]['h'].';
        var min = '.$ctime[0]['m'].';
        var sec = '.$ctime[0]['s'].';';
        }
        else
        {
            
                    echo 'var tim;
        var hour= '.$getq[0]['hour'].';
        var min = '.$getq[0]['time'].';
        var sec = 00;';
        }
              
              ?>
        
        var f = new Date();
        var loop = 1000;
        function f1() {
            f2();
        }
        function f2() {
            if (parseInt(sec) > 0) {
                sec = parseInt(sec) - 1;
                document.getElementById("hour").innerHTML = hour+" H";
                document.getElementById("min").innerHTML = min+" M";
                document.getElementById("sec").innerHTML = sec+ " S";
                
                 $.post("../ajax_to_php_connectors/utime1.php",
    {
        h: hour,
        m: min,
        s: sec
    },
    function(data, status){
      
    });
                tim = setTimeout("f2()", 1000);
            }
            else if(parseInt(min) > 0){
                if (parseInt(sec) == 0) {
                    min = parseInt(min) - 1;
                    if (parseInt(min) < 0) {
                        clearTimeout(tim);
                        //end exam
                    }
                    else {
                        sec = 60;
                        document.getElementById("hour").innerHTML = hour+" H";
                document.getElementById("min").innerHTML = min+" M";
                document.getElementById("sec").innerHTML = sec+ " S";
                 $.post("../ajax_to_php_connectors/utime1.php",
    {
        h: hour,
        m: min,
        s: sec
    },
    function(data, status){
        
    });
                        tim = setTimeout("f2()", loop);
                    }
                }
               
            }
            else
            {
                 if(parseInt(min) == 0)
                {
                    hour = parseInt(hour) - 1;
                    if (parseInt(hour) < 0) {
                        clearTimeout(tim);
                        loop = 0;
                        //end exam
                        window.location.reload();
                    }
                    else
                    {
                        min = 60;
                        document.getElementById("hour").innerHTML = hour+" H";
                document.getElementById("min").innerHTML = min+" M";
                document.getElementById("sec").innerHTML = sec+ " S";
                        
                 $.post("../ajax_to_php_connectors/utime1.php",
    {
        h: hour,
        m: min,
        s: sec
    },
    function(data, status){
        
    });
                        tim = setTimeout("f2()", loop);
                    }
                }
            }
        }
    </script>

<?php require_once 'footer.php'; ?>