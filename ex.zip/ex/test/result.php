<?php 
$title = "Result";
require_once 'header.php'; 

?>

	
<style>
    input:radio
    {
        height: 30px;
        width: 30px;
    }
    .quesno{
        height: 700px;
        background: rgba(0,0,0,0.8);
    }
    
   .sele
    {
        background:#00ad5f !important;
        color: #000000 !important;
    }
    .bele
    {
        background:#ff182b !important;
        color: #000000 !important;
    }
    
    @media print
    {
      
        .sfooter, #loadeck
        {
            display: none !important;
        }
        .sele
    {
        background:#00ad5f !important;
        color: #ffffff !important;
    }
    .bele
    {
        background:#ff182b !important;
        color: #ffffff !important;
    }
    #myModal
    {
        position: relative !important;
    overflow:visible!important;
    }
        
        .switcher
        {
            background: #ffffff !important;
            color: #ffffff !important;
            border: none !important;
            
        }
        
        .switcher1
        {
            display: none;
        }
        
        
        p span{
            padding: 4px !important;
        }
        
    }
</style>
	<!-- Highlights - jumbotron -->
<?php

if(isset($_GET['result']))
{
    $user = $_SESSION['user'];
    $titee = base64_decode($_GET['result']);
    //check if student wrote exam
    
     $stu1 = new config($_SESSION['sn']);
    $stu1 = $stu1->execute_return("SELECT * FROM pexam_table WHERE student_username = '$user' AND title='$titee'");
    if(count($stu1) > 0)
    {
        $nA = new config($_SESSION['sn']);
    $nA = $nA->execute_return("SELECT * FROM exam WHERE title='$titee' AND department='$dd' AND type='$tt' AND level='$ll'");
    $que = new config($_SESSION['sn']);
    $que = $que->execute_return("SELECT * FROM pquestions WHERE title='$titee' AND department='$dd' AND type='$tt' AND level='$ll' ORDER BY sn ASC");
    
        $score = (int)$nA[0]['score'];
        $ascore = 0;
        $bscore = 0;
        $tscore = 0;
        $nQQ = (int)$nA[0]['questions'];
        if($nA[0]['strict'] == "true")
        {
            for($i=0; $i<count($stu1); $i++)
            {
                if($stu1[$i]['mark'] == "pass")
                {
                   $ascore = $ascore + $score;
                }
                else
                {
                    $bscore = $bscore + $score;
                }
            }
        }
        else
        {
            for($i=0; $i<count($stu1); $i++)
            {
                if($stu1[$i]['mark'] == "pass")
                {
                    $ascore = $ascore + $score;
                }
            }
        }
        $tscore = $ascore - $bscore;
        if($tscore < 0)
        {
            $tscore = 0;
        }
        $schn = new config($_SESSION['sn']);
        $schn = $schn->execute_return("SELECT * FROM administrator LIMIT 1");
        
        echo '<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg m2">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <div class="row">
        <div class="col-sm-4" style="text-align: center;">
        <img src="../administrator/'.$_SESSION['sn'].'/logo-'.$schn[0]['logoimage'].'.png" alt="'.$_SESSION['user'].'" style="width: 100px; height: 100px;" />
</div>
        <div class="col-sm-8">
        <button type="button" class="close" data-dismiss="modal" onclick="window.location.href=\'result.php\';">&times;</button>
        <h3 class="modal-title" style="text-align:center; font-weight: bold;">'.$schn[0]['schoolname'].'</h3>
         <h3 class="modal-title" style="text-align:center; font-weight: bold;">'.$titee.'</h3>
        <h2 class="modal-title" style="text-align:center; font-weight: bold;">Total Score: '.$tscore.' / '.($nQQ * $score).'</h2>
</div>
</div>

      </div>
       <div class="modal-body">
      
           <p style="text-align: left; font-size: 1.3em; font-weight: bold;">Username: '.$_SESSION['user'].' </p>
               <p style="text-align: left; font-size: 1.3em; font-weight: bold;">Department: '.$dd.' </p>
                   <p style="text-align: left; font-size: 1.3em; font-weight: bold;">Type: '.$tt.' </p>
                       <p style="text-align: left; font-size: 1.3em; font-weight: bold;">Level: '.$ll.' </p>
       <p style="text-align: center; font-size: 1.3em; font-weight: bold;">Exam Review</p>
        ';
        
        for($b=0; $b<count($que); $b++)
        {
            //find answer
            $sno = $que[$b]['sn'];
            $stu = new config($_SESSION['sn']);
    $stu = $stu->execute_return("SELECT * FROM pexam_table WHERE student_username = '$user' AND title='$titee' AND sn='$sno'");
                
                if(count($stu) > 0)
                {
                    echo '<br><p style="font-weight: bold; font-weight: 1.5em !important; color: #000000;">'.$que[$b]['sn'].'</p>';
                   if($que[$b]['image'] != "")
                    {
                        echo"<div style='text-align: center;'><img style='height: 150px; width: 350px;' src='../staffs/".$_SESSION['sn']."/".$que[$b]['image']."p.png' /></div> ";
                         echo '<p>  '.$que[$b]['question'].'</p>';
                    }
                   else
                   {
                        echo '<p>   '.$que[$b]['question'].'</p>';
                   }
                    
                    if((int)$nA[0]['answers'] == 2)
                    {
                        if($stu[0]['mark'] == "pass")
                        {
                             if($que[$b]['a'] == "" && $que[$b]['b'] == "")
                    {
                        
                                echo '  <span class="sele" style="padding: 4px;">a. '.$stu[0]['ans'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                           
                    }
                    else if($stu[0]['ans'] == "a")
                            {
                                echo '  <span class="sele" style="padding: 4px;">'.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                            else
                            {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span class="sele" style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                        }
                        else
                        {
                            if($que[$b]['a'] == "" && $que[$b]['b'] == "")
                    {
                        
                              echo '  <span class="bele" style="padding: 4px;">'.$stu[0]['ans'].'</span>  <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                    
                           
                    }
                            else if($stu[0]['ans'] == "a")
                            {
                                echo '  <span class="bele" style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                            else
                            {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span class="bele" style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                        }
                    }
                    
                    else if((int)$nA[0]['answers'] == 3)
                    {
                        if($stu[0]['mark'] == "pass")
                        {
                            if($que[$b]['a'] == "" && $que[$b]['b'] == "" && $que[$b]['c'] == "")
                    {
                        
                                echo '  <span class="sele" style="padding: 4px;">'.$stu[0]['ans'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                           
                    }
                            else if($stu[0]['ans'] == "a")
                            {
                                echo '  <span class="sele" style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                            else if($stu[0]['ans'] == "b")
                            {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span class="sele" style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                            else
                            {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span class="sele" style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                        }
                        else
                        {
                            if($que[$b]['a'] == "" && $que[$b]['b'] == "" && $que[$b]['c'] == "")
                    {
                        
                               echo '  <span class="bele" style="padding: 4px;">'.$stu[0]['ans'].'</span>  <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                    
                           
                    }
                            else if($stu[0]['ans'] == "a")
                            {
                                echo '  <span class="bele" style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                            else if($stu[0]['ans'] == "b")
                            {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span class="bele" style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                            else
                                {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span class="bele" style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                        }
                    }
                    
                    else if((int)$nA[0]['answers'] == 4)
                    {
                        if($stu[0]['mark'] == "pass")
                        {
                             if($que[$b]['a'] == "" && $que[$b]['b'] == "" && $que[$b]['c'] == "" && $que[$b]['d'] == "")
                    {
                        
                                echo '  <span class="sele" style="padding: 4px;">'.$stu[0]['ans'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                           
                    }else if($stu[0]['ans'] == "a")
                            {
                                echo '  <span class="sele" style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                            else if($stu[0]['ans'] == "b")
                            {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span class="sele" style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                            else if($stu[0]['ans'] == "c")
                            {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span class="sele" style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                            else
                                {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span class="sele" style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                        }
                        else
                        {
                              if($que[$b]['a'] == "" && $que[$b]['b'] == "" && $que[$b]['c'] == "" && $que[$b]['d'] == "")
                    {
                        
                                echo '  <span class="bele" style="padding: 4px;">'.$stu[0]['ans'].'</span>  <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                                 
                    }
                            else if($stu[0]['ans'] == "a")
                            {
                                echo '  <span class="bele" style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                            else if($stu[0]['ans'] == "b")
                            {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span class="bele" style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                            else if($stu[0]['ans'] == "c")
                                {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span class="bele" style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                            else
                            {
                                {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span class="bele" style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                            }
                        }
                    }
                    else
                    {
                         if($stu[0]['mark'] == "pass")
                        {
                             if($que[$b]['a'] == "" && $que[$b]['b'] == "" && $que[$b]['c'] == "" && $que[$b]['d'] == "" && $que[$b]['e'] == "")
                    {
                        
                                echo '  <span class="sele" style="padding: 4px;">'.$stu[0]['ans'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                           
                    }
                            else if($stu[0]['ans'] == "a")
                            {
                                echo '  <span class="sele" style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span style="padding: 4px;">e. '.$que[$b]['e'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                            else if($stu[0]['ans'] == "b")
                            {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span class="sele" style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span style="padding: 4px;">e. '.$que[$b]['e'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                            else if($stu[0]['ans'] == "c")
                            {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span class="sele" style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span style="padding: 4px;">e. '.$que[$b]['e'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                            else if($stu[0]['ans'] == "d")
                                {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span class="sele" style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span style="padding: 4px;">e. '.$que[$b]['e'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                            else
                                {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> </span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span class="sele" style="padding: 4px;">e. '.$que[$b]['e'].'</span> <span class="fa fa-check" style="color: green; font-weight: bold;">passed</span></p>';
                            }
                        }
                        else
                        {
                            if($que[$b]['a'] == "" && $que[$b]['b'] == "" && $que[$b]['c'] == "" && $que[$b]['d'] == "" && $que[$b]['e'] == "")
                    {
                        
                                echo '  <span class="bele" style="padding: 4px;">'.$stu[0]['ans'].'</span>  <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                             
                    }
                            else if($stu[0]['ans'] == "a")
                            {
                                echo '  <span class="bele" style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span style="padding: 4px;">e. '.$que[$b]['e'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                            else if($stu[0]['ans'] == "b")
                            {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span class="bele" style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span style="padding: 4px;">e. '.$que[$b]['e'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                            else if($stu[0]['ans'] == "c")
                                {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span class="bele" style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span style="padding: 4px;">e. '.$que[$b]['e'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            }
                            else if($stu[0]['ans'] == "d")
                            {
                                
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span class="bele" style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span class="bele" style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span style="padding: 4px;">e. '.$que[$b]['e'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            
                            }
                            else
                                {
                                echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span class="bele" style="padding: 4px;">e. '.$que[$b]['e'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                                
                            }
                        }
                    }
                    
                }
                else
                {
                    echo '<p style="font-weight: bold; font-weight: 1.5em !important; color: #000000;">'.$que[$b]['sn'].'</p>';
                    echo '<p>   '.$que[$b]['question'].'</p>';
                    
                                if($que[$b]['a'] == "" && $que[$b]['b'] == "" && $que[$b]['c'] == "" && $que[$b]['d'] == "" && $que[$b]['e'] == "")
                    {
                        
                                echo '  <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                          
                    }
                    else if((int)$nA[0]['answers'] == 5)
                    {
                         echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span style="padding: 4px;">e. '.$que[$b]['e'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            
                     }
                     else if((int)$nA[0]['answers'] == 4)
                    {
                         echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span style="padding: 4px;">d. '.$que[$b]['d'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            
                     }
                     else if((int)$nA[0]['answers'] == 3)
                    {
                         echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span style="padding: 4px;">c. '.$que[$b]['c'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            
                     }
                     else
                         {
                         echo '  <span style="padding: 4px;">a. '.$que[$b]['a'].'</span> <span style="padding: 4px;">b. '.$que[$b]['b'].'</span> <span class="fa fa-times" style="color: red; font-weight: bold;">failed</span> <span style="color: blue; font-weight: bold;">Answer: '.$que[$b]['answer'].'</span></p>';
                            
                     }
                }
                
            
        }
        
        echo '
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-primary pull-left" onclick="window.print();">Print</button>
        <button type="button" class="btn btn-default pull-right" data-dismiss="modal" onclick="window.location.href=\'result.php\';">Close</button>
      </div>
</div></div></div>';
        
        $qA = new config($_SESSION['sn']);
    $qA = $qA->execute_return("SELECT * FROM pquestions WHERE title='$titee' AND department='$dd' AND type='$tt' AND level='$ll'");
    }
    else
    {
        header("location : result.php");
    }
}

?>
        <div class="jumbotron top-space switcher" style="margin-top: 60px;">
            <div class="container">
                    
                    <div class="col-sm-12">
                        <?php
                        $u = $_SESSION['user'];
                        //delete empty timers
                        $deltime = new config($_SESSION['sn']);
                        $deltime->execute_no_return("DELETE FROM ptimer WHERE title=''");
                        echo '
		<div class="container">
			<div class="row" style="text-align: center;">
				<h4  class="lead switcher" style="font-size: 2.5em; margin-top: 20px; font-weight: bold;">'.$u.'</h4>
				<p class="tagline switcher" style="font-weight: bold;">Click any of the subjects if available to check your result</p>
				<p class="switcher1">'; 
                        $padded1 = array();
                                                            $acount1 = 0;
                                $getType = new config($_SESSION['sn']);
                                $getType = $getType->execute_return("SELECT title FROM `ptimer` WHERE username = '$u'");
                                if(count($getType) > 0)
                                {
                                    for($i = 0; $i<count($getType); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getType[$i]["title"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $dt = $getType[$i]["title"];
                                                               
                                                               
                                                               echo '<a class="btn btn-default btn-lg" href="result.php?result='. base64_encode($getType[$i]['title']).'" role="button">'.$getType[$i]['title'].'</a> ';
                
                                                           $padded1[$acount1] = $getType[$i]["title"];
                                    $acount1++;
                                                               
                                        }
                                }
                               
                                echo '</p>
			</div>
		</div>
	';  ?>
                    </div>
		
            
		</div>
	</div>
        <div style="text-align: center">
           <?php 
           if(isset($_GET['result']))
           {
               echo ' <button type="button" id="loadeck" class="btn btn-info btn-lg"  style="" data-toggle="modal" data-target="#myModal">Open Result</button>';
           }
           ?>
        </div>

<?php require_once 'footer.php'; ?>