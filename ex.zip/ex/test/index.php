<?php 
$title = "Dashboard";
require_once 'header.php'; 
if(isset($_SESSION['paper']))
{
    header("location: exam.php");
}
if(isset($_SESSION['ptitle']))
{
    $sch = $_SESSION['psch'];
$uss =   $_SESSION['user'];
$ddep = $_SESSION['pdep'];
$dtype = $_SESSION['ptype'];
$dlev = $_SESSION['plevel'];
$dtit = $_SESSION['ptitle'];
$deluser = new config(preg_replace('/\s+/', '_', $sch));
$deluser = $deluser->execute_no_return("DELETE FROM ptimer WHERE title='$dtit' AND username='$uss'");
$delq = new config(preg_replace('/\s+/', '_', $sch));
$delq = $delq->execute_no_return("DELETE FROM pexam_table WHERE title='$dtit' AND student_username='$uss'");
}

?>

	
		
	<!-- Highlights - jumbotron -->
	<div class="jumbotron top-space">
		<div class="container">
			
                    
		
		</div>
	</div>
	<!-- /Highlights -->

	

<?php require_once 'footer.php'; ?>