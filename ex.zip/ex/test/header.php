<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//Check if user is logged in
session_start();

include_once '../classes/config.php';
    $dd = $_SESSION['pdep'];
        $tt = $_SESSION['ptype'];
        $ll = $_SESSION['plevel'];
        //check if exam table is created
     $checkt = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                    $checkt = $checkt->execute_return("SHOW TABLES LIKE 'pexam_table'");
    if($checkt == false && count($checkt) <= 0)
                    {
        //create exam table
        $createexamtable = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
        $createexamtable->execute_no_return("CREATE TABLE `pexam_table` ( `id` INT(16) NOT NULL AUTO_INCREMENT, `student_username` VARCHAR(150) NOT NULL , `title` VARCHAR(150) NOT NULL , `sn` INT(16) NOT NULL , `ans` VARCHAR(150) NOT NULL , `mark` VARCHAR(150) NOT NULL, PRIMARY KEY (`id`)) ENGINE = InnoDB;");
        
    }
    $check= new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                    $check = $check->execute_return("SHOW TABLES LIKE 'ptimer'");
    if($check == false && count($check) <= 0)
                    {
        //create exam table
        $tim = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
        $tim->execute_no_return("CREATE TABLE `ptimer` ( `id` INT(16) NOT NULL AUTO_INCREMENT , `username` VARCHAR(150) NOT NULL , `title` VARCHAR(150) NOT NULL,  `h` VARCHAR(150) NOT NULL , `m` VARCHAR(150) NOT NULL , `s` VARCHAR(150) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;");
        
    }
    ?>


                       <!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author"      content="Sergey Pozhilov (GetTemplate.com)">
	
	<title>Exami - <?php echo $title; ?></title>
        <link rel="shortcut icon" type="img/png" href="../img/icon-196x1961.png">
        <link rel="shortcut icon" sizes="196x196" href="../img/icon-196x1961.png">
        <link rel="apple-touch-icon" href="../img/icon-196x1961.png">
	
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="assets/css/main.css">

	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="assets/js/html5shiv.js"></script>
	<script src="assets/js/respond.min.js"></script>
	<![endif]-->
</head>
<style>
    
    li a{
        border: 1px solid #ffffff !important;
        color: #ffffff !important;
    }
    
    </style>
<body class="home" <?php if($title == "Exam"){ echo 'onload="f1()"';} ?>>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                                <a class="navbar-brand" href="../students/"><img src="../img/extlogwhite.png" style="width: 80px; height: 60px;" alt="Exami Logo">Exami</a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
                                    <li><a class="btn" href="index.php">Dashboard</a></li>
                                    <?php if($title == "Dashboard")
                                    {
     echo ' <li><a class="btn" href="result.php">View Result</a></li>';
                                    }
?><?php if($title == "Exam")
                                    {
     echo ' <li><a class="btn" href="endpaper.php">END PAPER</a></li>';
                                    }?>
                                    
                                    <li><a class="btn"><?php echo  $_SESSION['user']; ?></a></li>
                                      <li><a class="btn" href="logout.php">RESTART</a></li>
                                   
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<!-- Header -->
<?php 
if($title == "Dashboard")
{
    echo '	<header id="head">
		<div class="container">
			<div class="row">
				<h1 class="lead">WELCOME, '.$_SESSION['user'].'</h1>
				<p class="tagline">TODAY\'S PAPERS WILL BE DISPLAYED HERE</p>
				<p>'; 
                                $getscheduled = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
                                $getscheduled = $getscheduled->execute_return("SELECT * FROM `exam` WHERE department='$dd' AND type='$tt' AND level='$ll'");
                                
                               
                                if(count($getscheduled) > 0)
                                {
                                    for($i=0; $i<count($getscheduled); $i++)
                                    {
          
                       echo '<a class="btn btn-default btn-lg" href="exam.php?paper='. base64_encode($getscheduled[$i]['title']).'" role="button">'.$getscheduled[$i]['title'].'</a> ';
                          
                  
                     }
                                }
                                echo '</p>
			</div>
		</div>
	</header>';
}
?>
	<!-- /Header -->