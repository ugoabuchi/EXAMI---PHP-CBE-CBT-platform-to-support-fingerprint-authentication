<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();

if(isset($_SESSION['paper']))
{
    include_once '../classes/config.php';
    $p = $_SESSION['paper'];
    $u = $_SESSION['user'];
    $ctime =    new config($_SESSION['sn']);
        $ctime->execute_no_return("DELETE FROM `ptimer` WHERE username='$u' AND title='$p'");
        
        $cquest =    new config($_SESSION['sn']);
        $cquest->execute_no_return("DELETE FROM `pexam_table` WHERE student_username='$u' AND title='$p'");
}
session_unset();
session_destroy();
header("location: ../");
?>