/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function register()
{
     
var url_regex = /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;

var username = document.getElementById("admin_username").value.toString();

var school_name = document.getElementById("admin_school_name").value.toString().toUpperCase();

var school_type = document.getElementById("admin_school_type").value.toString().toUpperCase();

var school_email = document.getElementById("admin_school_email").value.toString();

var school_telephone = document.getElementById("admin_school_telephone").value.toString();

var school_website = document.getElementById("admin_school_website").value.toString().toUpperCase();

var password = document.getElementById("admin_password").value.toString();

if(username =="" || school_name == "" || school_type == "" || school_email == "" || school_telephone == "" || school_website == "" || password == "")
{
document.getElementById("errorMessage").innerHTML = "Every of the field must be filled";
document.getElementById("successMessage").style.display = "none";
document.getElementById("errorMessage").style.display = "block";
}
else if(school_telephone.length != 11 || school_telephone.substr(0,0) != 0)
{
document.getElementById("errorMessage").innerHTML = "Invalid Telephone Number";
document.getElementById("successMessage").style.display = "none";
document.getElementById("errorMessage").style.display = "block";
}
else if(school_website == "" || url_regex.test(school_website))
{
    document.getElementById("errorMessage").innerHTML = "Invalid web url";
document.getElementById("successMessage").style.display = "none";
document.getElementById("errorMessage").style.display = "block";
}
else
{
document.getElementById("successMessage").innerHTML = "";
document.getElementById("errorMessage").innerHTML = "";
document.getElementById("successMessage").style.display = "none";
document.getElementById("errorMessage").style.display = "none";
document.getElementById("admin_button").style.display = "none";
document.getElementById("loader_box").style.display = "block";
document.getElementById("admin_username").setAttribute("readonly",true);
document.getElementById("admin_school_name").setAttribute("readonly",true);
document.getElementById("admin_school_type").setAttribute("readonly",true);
document.getElementById("admin_school_telephone").setAttribute("readonly",true);
document.getElementById("admin_school_website").setAttribute("readonly",true);
document.getElementById("admin_school_email").setAttribute("readonly",true);
document.getElementById("admin_password").setAttribute("readonly",true);

 $.ajax({
        url: "ajax_to_php_connectors/register.php",
        type: "post",
        data: "username="+username+"&school_name="+school_name+"&school_type="+school_type+"&school_telephone="+school_telephone+"&school_website="+school_website+"&school_email="+school_email+"&password="+password ,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
           if(myResp == "success")
           {
               document.getElementById("successMessage").innerHTML = "Regisstration was successful, an email containing a link to verify your account has been sent";
document.getElementById("errorMessage").innerHTML = "";
$("#errorMessage").slideUp("slow");
$("#successMessage").slideDown("slow");
document.getElementById("admin_button").style.display = "block";
document.getElementById("loader_box").style.display = "none";

document.getElementById("admin_username").value = "";
$("#admin_username").removeAttr("readonly");
document.getElementById("admin_school_name").value = "";
$("#admin_school_name").removeAttr("readonly");
document.getElementById("admin_school_type").value = "";
$("#admin_school_type").removeAttr("readonly");
document.getElementById("admin_school_telephone").value = "";
$("#admin_school_telephone").removeAttr("readonly");
document.getElementById("admin_school_website").value = "";
$("#admin_school_website").removeAttr("readonly");
document.getElementById("admin_school_email").value = "";
$("#admin_school_email").removeAttr("readonly");
document.getElementById("admin_password").value = "";
$("#admin_password").removeAttr("readonly");
           }
           else
           {
               document.getElementById("successMessage").innerHTML = "";
document.getElementById("errorMessage").innerHTML = "School name with "+document.getElementById("admin_school_name").value+" already exist";
document.getElementById("successMessage").style.display = "none";
$("#successMessage").slideUp("slow");
$("#errorMessage").slideDown("slow");
document.getElementById("errorMessage").style.display = "block";
document.getElementById("admin_button").style.display = "block";
document.getElementById("loader_box").style.display = "none";

document.getElementById("admin_username").value = "";
$("#admin_username").removeAttr("readonly");
document.getElementById("admin_school_name").value = "";
$("#admin_school_name").removeAttr("readonly");
document.getElementById("admin_school_type").value = "";
$("#admin_school_type").removeAttr("readonly");
document.getElementById("admin_school_telephone").value = "";
$("#admin_school_telephone").removeAttr("readonly");
document.getElementById("admin_school_website").value = "";
$("#admin_school_website").removeAttr("readonly");
document.getElementById("admin_school_email").value = "";
$("#admin_school_email").removeAttr("readonly");
document.getElementById("admin_password").value = "";
$("#admin_password").removeAttr("readonly");
           }

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });

}

}

