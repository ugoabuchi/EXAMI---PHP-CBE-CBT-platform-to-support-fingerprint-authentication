/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function loginstudent()
{
    document.getElementById("successMessage4").style.display = "none";
     document.getElementById("errorMessage4").style.display = "none";
    document.getElementById("errorMessage1").style.display = "none";
document.getElementById("errorMessage").style.display = "none";
document.getElementById("successMessage1").style.display = "none";
document.getElementById("successMessage").style.display = "none";
document.getElementById("errorMessage2").style.display = "none";
document.getElementById("successMessage2").style.display = "none";
var username = document.getElementById("student_username").value.toString();

var school_name = document.getElementById("student_school_name").value.toString().toUpperCase();

var password = document.getElementById("student_password").value.toString();

if(username =="" || school_name == "" || password == "")
{
document.getElementById("errorMessage4").innerHTML = "Every of the field must be filled";
document.getElementById("errorMessage4").style.display = "block";
}
else
{
document.getElementById("errorMessage4").innerHTML = "";
document.getElementById("errorMessage4").style.display = "none";
document.getElementById("student_login_button").style.display = "none";
document.getElementById("loader_box4").style.display = "block";
document.getElementById("student_username").setAttribute("readonly",true);
document.getElementById("student_school_name").setAttribute("readonly",true);
document.getElementById("student_password").setAttribute("readonly",true);

 $.ajax({
        url: "ajax_to_php_connectors/login.php",
        type: "post",
        data: "username="+username+"&school_name="+school_name+"&password="+password+"&usertype="+"student" ,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
           if(myResp == "success")
           {
               document.getElementById("successMessage4").innerHTML = "Login Successful, Redirecting to dashboard in 5s";
               
$("#successMessage4").slideDown("slow");
document.getElementById("student_login_button").style.display = "block";
document.getElementById("loader_box4").style.display = "none";

document.getElementById("student_username").value = "";
$("#student_username").removeAttr("readonly");
document.getElementById("student_school_name").value = "";
$("#student_school_name").removeAttr("readonly");
document.getElementById("student_password").value = "";
$("#student_password").removeAttr("readonly");
window.setTimeout(function(){window.location.href = "/ex/students";},5000);
           }
           else if(myResp == "home")
           {
               document.getElementById("errorMessage4").innerHTML = "Session expired, Please login again after page reloads, reloading in 5seconds";
$("#errorMessage4").slideDown("slow");
document.getElementById("student_login_button").style.display = "block";
document.getElementById("loader_box4").style.display = "none";

document.getElementById("student_username").value = "";
$("#student_username").removeAttr("readonly");
document.getElementById("student_school_name").value = "";
$("#student_school_name").removeAttr("readonly");
document.getElementById("student_password").value = "";
$("#student_password").removeAttr("readonly");
window.setTimeout(function(){window.location.href = "/ex/students";},5000);
           }
           else if(myResp == "staff")
           {
               document.getElementById("successMessage4").innerHTML = "Login Successful, Redirecting to dashboard in 5s";
               
$("#successMessage4").slideDown("slow");
document.getElementById("student_login_button").style.display = "block";
document.getElementById("loader_box4").style.display = "none";

document.getElementById("student_username").value = "";
$("#student_username").removeAttr("readonly");
document.getElementById("student_school_name").value = "";
$("#student_school_name").removeAttr("readonly");
document.getElementById("student_password").value = "";
$("#student_password").removeAttr("readonly");
window.setTimeout(function(){window.location.href = "/ex/students";},5000);
           }
           else if(myResp == "invalid_username_and_password_combination")
           {
document.getElementById("errorMessage4").innerHTML = "Invalid username and password combination";
$("#errorMessage4").slideDown("slow");
document.getElementById("student_login_button").style.display = "block";
document.getElementById("loader_box4").style.display = "none";

document.getElementById("student_username").value = "";
$("#student_username").removeAttr("readonly");
document.getElementById("student_school_name").value = "";
$("#student_school_name").removeAttr("readonly");
document.getElementById("student_password").value = "";
$("#student_password").removeAttr("readonly");
           }
           else
           {
               document.getElementById("errorMessage4").innerHTML = "Invalid username and password combination";
$("#errorMessage4").slideDown("slow");
document.getElementById("student_login_button").style.display = "block";
document.getElementById("loader_box4").style.display = "none";

document.getElementById("student_username").value = "";
$("#student_username").removeAttr("readonly");
document.getElementById("student_school_name").value = "";
$("#student_school_name").removeAttr("readonly");
document.getElementById("student_password").value = "";
$("#student_password").removeAttr("readonly");
           }

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });

}
}
function loginstaff()
{
    document.getElementById("errorMessage1").style.display = "none";
document.getElementById("errorMessage").style.display = "none";
document.getElementById("successMessage1").style.display = "none";
document.getElementById("successMessage").style.display = "none";
document.getElementById("errorMessage2").style.display = "none";
document.getElementById("successMessage2").style.display = "none";
var username = document.getElementById("staff_username").value.toString();

var school_name = document.getElementById("staff_school_name").value.toString().toUpperCase();

var password = document.getElementById("staff_password").value.toString();

if(username =="" || school_name == "" || password == "")
{
document.getElementById("errorMessage2").innerHTML = "Every of the field must be filled";
document.getElementById("errorMessage2").style.display = "block";
}
else
{
document.getElementById("errorMessage2").innerHTML = "";
document.getElementById("errorMessage2").style.display = "none";
document.getElementById("staff_login_button").style.display = "none";
document.getElementById("loader_box2").style.display = "block";
document.getElementById("staff_username").setAttribute("readonly",true);
document.getElementById("staff_school_name").setAttribute("readonly",true);
document.getElementById("staff_password").setAttribute("readonly",true);

 $.ajax({
        url: "ajax_to_php_connectors/login.php",
        type: "post",
        data: "username="+username+"&school_name="+school_name+"&password="+password+"&usertype="+"staff" ,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
           if(myResp == "success")
           {
               document.getElementById("successMessage2").innerHTML = "Login Successful, Redirecting to dashboard in 5s";
               
$("#successMessage2").slideDown("slow");
document.getElementById("staff_login_button").style.display = "block";
document.getElementById("loader_box2").style.display = "none";

document.getElementById("staff_username").value = "";
$("#staff_username").removeAttr("readonly");
document.getElementById("staff_school_name").value = "";
$("#staff_school_name").removeAttr("readonly");
document.getElementById("staff_password").value = "";
$("#staff_password").removeAttr("readonly");
window.setTimeout(function(){window.location.href = "/ex/staffs";},5000);
           }
           else if(myResp == "home")
           {
               document.getElementById("errorMessage2").innerHTML = "Session expired, Please login again after page reloads, reloading in 5seconds";
$("#errorMessage2").slideDown("slow");
document.getElementById("staff_login_button").style.display = "block";
document.getElementById("loader_box2").style.display = "none";

document.getElementById("staff_username").value = "";
$("#staff_username").removeAttr("readonly");
document.getElementById("staff_school_name").value = "";
$("#staff_school_name").removeAttr("readonly");
document.getElementById("staff_password").value = "";
$("#staff_password").removeAttr("readonly");
window.setTimeout(function(){window.location.href = "/ex";},5000);
           }
           else if(myResp == "staff")
           {
               document.getElementById("successMessage2").innerHTML = "Login Successful, Redirecting to dashboard in 5s";
               
$("#successMessage2").slideDown("slow");
document.getElementById("staff_login_button").style.display = "block";
document.getElementById("loader_box2").style.display = "none";

document.getElementById("staff_username").value = "";
$("#staff_username").removeAttr("readonly");
document.getElementById("staff_school_name").value = "";
$("#staff_school_name").removeAttr("readonly");
document.getElementById("staff_password").value = "";
$("#staff_password").removeAttr("readonly");
window.setTimeout(function(){window.location.href = "/ex/staffs";},5000);
           }
           else if(myResp == "invalid_username_and_password_combination")
           {
document.getElementById("errorMessage2").innerHTML = "Invalid username and password combination";
$("#errorMessage2").slideDown("slow");
document.getElementById("staff_login_button").style.display = "block";
document.getElementById("loader_box2").style.display = "none";

document.getElementById("staff_username").value = "";
$("#staff_username").removeAttr("readonly");
document.getElementById("staff_school_name").value = "";
$("#staff_school_name").removeAttr("readonly");
document.getElementById("staff_password").value = "";
$("#staff_password").removeAttr("readonly");
           }
           else
           {
               document.getElementById("errorMessage2").innerHTML = "Invalid username and password combination";
$("#errorMessage2").slideDown("slow");
document.getElementById("staff_login_button").style.display = "block";
document.getElementById("loader_box2").style.display = "none";

document.getElementById("staff_username").value = "";
$("#staff_username").removeAttr("readonly");
document.getElementById("staff_school_name").value = "";
$("#staff_school_name").removeAttr("readonly");
document.getElementById("staff_password").value = "";
$("#staff_password").removeAttr("readonly");
           }

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });

}
}
function loginadmin()
{
document.getElementById("errorMessage1").style.display = "none";
document.getElementById("errorMessage").style.display = "none";
document.getElementById("successMessage1").style.display = "none";
document.getElementById("successMessage").style.display = "none";
var username = document.getElementById("admin_username1").value.toString();

var school_name = document.getElementById("admin_school_name1").value.toString().toUpperCase();

var password = document.getElementById("admin_password1").value.toString();

if(username =="" || school_name == "" || password == "")
{
document.getElementById("errorMessage1").innerHTML = "Every of the field must be filled";
document.getElementById("errorMessage1").style.display = "block";
}
else
{
document.getElementById("errorMessage1").innerHTML = "";
document.getElementById("errorMessage1").style.display = "none";
document.getElementById("admin_login_button").style.display = "none";
document.getElementById("loader_box1").style.display = "block";
document.getElementById("admin_username1").setAttribute("readonly",true);
document.getElementById("admin_school_name1").setAttribute("readonly",true);
document.getElementById("admin_password1").setAttribute("readonly",true);
 $.ajax({
        url: "ajax_to_php_connectors/login.php",
        type: "post",
        data: "username="+username+"&school_name="+school_name+"&password="+password+"&usertype="+"administrator" ,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
           if(myResp == "not_activated")
           {
               document.getElementById("errorMessage1").innerHTML = "Account not activated, Click on the link sent to your mail. If you didint get one click on the activate button above.";
$("#errorMessage1").slideDown("slow");
document.getElementById("admin_login_button").style.display = "block";
document.getElementById("loader_box1").style.display = "none";

document.getElementById("admin_username1").value = "";
$("#admin_username1").removeAttr("readonly");
document.getElementById("admin_school_name1").value = "";
$("#admin_school_name1").removeAttr("readonly");
document.getElementById("admin_password1").value = "";
$("#admin_password1").removeAttr("readonly");
           }
           else if(myResp == "success")
           {
               document.getElementById("successMessage1").innerHTML = "Login Successful, Redirecting to dashboard in 5s";
               
$("#successMessage1").slideDown("slow");
document.getElementById("admin_login_button").style.display = "block";
document.getElementById("loader_box1").style.display = "none";

document.getElementById("admin_username1").value = "";
$("#admin_username1").removeAttr("readonly");
document.getElementById("admin_school_name1").value = "";
$("#admin_school_name1").removeAttr("readonly");
document.getElementById("admin_password1").value = "";
$("#admin_password1").removeAttr("readonly");
window.setTimeout(function(){window.location.href = "/ex/administrator";},5000);
           }
           else if(myResp == "home")
           {
               document.getElementById("errorMessage1").innerHTML = "Session expired, Please login again after page reloads, reloading in 5seconds";
$("#errorMessage1").slideDown("slow");
document.getElementById("admin_login_button").style.display = "block";
document.getElementById("loader_box1").style.display = "none";

document.getElementById("admin_username1").value = "";
$("#admin_username1").removeAttr("readonly");
document.getElementById("admin_school_name1").value = "";
$("#admin_school_name1").removeAttr("readonly");
document.getElementById("admin_password1").value = "";
$("#admin_password1").removeAttr("readonly");
window.setTimeout(function(){window.location.href = "/ex";},5000);
           }
           else if(myResp == "admin")
           {
               document.getElementById("successMessage1").innerHTML = "Login Successful, Redirecting to dashboard in 5s";
               
$("#successMessage1").slideDown("slow");
document.getElementById("admin_login_button").style.display = "block";
document.getElementById("loader_box1").style.display = "none";

document.getElementById("admin_username1").value = "";
$("#admin_username1").removeAttr("readonly");
document.getElementById("admin_school_name1").value = "";
$("#admin_school_name1").removeAttr("readonly");
document.getElementById("admin_password1").value = "";
$("#admin_password1").removeAttr("readonly");
window.setTimeout(function(){window.location.href = "/ex/administrator";},5000);
           }
           else if(myResp == "invalid_username_and_password_combination")
           {
document.getElementById("errorMessage1").innerHTML = "Invalid username and password combination";
$("#errorMessage1").slideDown("slow");
document.getElementById("admin_login_button").style.display = "block";
document.getElementById("loader_box1").style.display = "none";

document.getElementById("admin_username1").value = "";
$("#admin_username1").removeAttr("readonly");
document.getElementById("admin_school_name1").value = "";
$("#admin_school_name1").removeAttr("readonly");
document.getElementById("admin_password1").value = "";
$("#admin_password1").removeAttr("readonly");
           }
           else
           {
               document.getElementById("errorMessage1").innerHTML = "Invalid username and password combination";
$("#errorMessage1").slideDown("slow");
document.getElementById("admin_login_button").style.display = "block";
document.getElementById("loader_box1").style.display = "none";

document.getElementById("admin_username1").value = "";
$("#admin_username1").removeAttr("readonly");
document.getElementById("admin_school_name1").value = "";
$("#admin_school_name1").removeAttr("readonly");
document.getElementById("admin_password1").value = "";
$("#admin_password1").removeAttr("readonly");
           }

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });

}

}