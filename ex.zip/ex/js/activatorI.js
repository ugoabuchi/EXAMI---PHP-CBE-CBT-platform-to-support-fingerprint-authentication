/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function sendCode()
{
    document.getElementById("loader_boxSendI").style.display = "block";
    document.getElementById("successMessageSendCode").style.display = "none";
    var email = document.getElementById("userEmail").value;
    var school = document.getElementById("admin_school_name").value;
    document.getElementById("userEmail").setAttribute("readonly",true);
    document.getElementById("admin_school_name").setAttribute("readonly",true);
    $.ajax({
        url: "ajax_to_php_connectors/sendCodeI.php",
        type: "post",
        data: "email="+email+"&school_name="+school ,
        success: function (response) {
          // var myResp = $.trim(response.replace(/[\n]+/g, '')); 
         
document.getElementById("successMessageSendCode").style.display = "block";
document.getElementById("sendI").style.display = "block";
document.getElementById("loader_boxSendI").style.display = "none";

document.getElementById("userEmail").value = "";
$("#userEmail").removeAttr("readonly");
document.getElementById("admin_school_name").value = "";
$("#admin_school_name").removeAttr("readonly");

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });

}

function activate()
{
    document.getElementById("loader_boxActivateI").style.display = "block";
    document.getElementById("successMessageActivate").style.display = "none";
    document.getElementById("errorMessageActivate").style.display = "none";
    var code = document.getElementById("code").value;
    document.getElementById("code").setAttribute("readonly",true);
    $.ajax({
        url: "ajax_to_php_connectors/activateI.php",
        type: "post",
        data: "code="+code,
        success: function (response) {
        var myResp = $.trim(response.replace(/[\n]+/g, '')); 
         
         if(myResp == "success")
         {
            document.getElementById("successMessageActivate").style.display = "block";
            document.getElementById("activateI").style.display = "block";
            document.getElementById("loader_boxActivateI").style.display = "none";
            document.getElementById("code").value = "";
            $("#code").removeAttr("readonly");

         }
         else
         {
             document.getElementById("errorMessageActivate").style.display = "block";
            document.getElementById("activateI").style.display = "block";
            document.getElementById("loader_boxActivateI").style.display = "none";
            document.getElementById("code").value = "";
            $("#code").removeAttr("readonly");
         }

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
}
