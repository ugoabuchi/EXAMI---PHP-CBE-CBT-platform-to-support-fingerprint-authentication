/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function show_login()
{
    document.getElementsByClassName("i_reg")[0].style.display = "none";
    $(".i_login").slideDown("slow");
}
function show_reg()
{
    document.getElementsByClassName("i_login")[0].style.display = "none";
    $(".i_reg").slideDown("slow");
}