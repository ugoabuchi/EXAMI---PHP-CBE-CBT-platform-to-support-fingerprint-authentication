<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
ini_set('display_errors', 0);
ini_set('log_errors', 0);
include_once 'config.php';
include_once 'db_creator.php';
class registrator
{
    private $admin_username0 = null;
    private $school_name0 = null;
    private $school_type0 = null;
    private $school_telephone0 = null;
    private $school_website0 = null;
    private $school_email0 = null;
    private $admin_password0 = null;
    
    
            function __construct($admin_username1, $school_name1, $school_type1,$school_telephone1, $school_website1, $school_email1, $admin_password1)
    {
                $this->admin_username0 = $admin_username1;
                $this->school_name0 = strtoupper($school_name1); 
                $this->school_type0 = strtoupper($school_type1);
                $this->school_telephone0 = $school_telephone1;
                $this->school_website0 = strtoupper($school_website1);
                $this->school_email0 = $school_email1;
                $this->admin_password0 = $admin_password1;
        
    }
    
    function registrate_user()
    {
        //Create 4 random values for password security
        $rand1 = mt_rand();
  $rand2 = mt_rand();
  $rand3 = mt_rand();
  $rand4 = mt_rand();
  $rand5 = mt_rand();
        
        $this->admin_password0 = sha1($this->admin_password0).sha1($rand1).sha1($rand2).sha1($rand3).sha1($rand4).sha1($rand5);
        
        //CHECK IF DATABASE OF SCHOOLNAME EXIST
        $checker = new db_creator();
        $mycheckerresult = $checker->execute_return_check_db(preg_replace('/\s+/', '_', $this->school_name0));
        
        if($mycheckerresult[0]["IF(EXISTS (SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '".preg_replace('/\s+/', '_', $this->school_name0)."'), 'Yes','No')"] == "No")
        {
           
            //CREATE DB
         $createdb = new db_creator();
         $createdb->execute_no_return_create_db(preg_replace('/\s+/', '_', $this->school_name0));
             
        //CREATE ADMINISTRATIVE TABLE
        $create_tb_admin = new config(preg_replace('/\s+/', '_', $this->school_name0));
        $create_tb_admin->execute_no_return("CREATE TABLE administrator(
  id INT(25) NOT NULL AUTO_INCREMENT,
  logoimage TEXT NULL,
  username VARCHAR(150) NOT NULL,
  schoolname VARCHAR(150) NOT NULL,
  schooltype VARCHAR(150) NOT NULL,
  schooltelephone VARCHAR(150) NOT NULL,
  schoolwebsite VARCHAR(150) NOT NULL,
  schoolemail VARCHAR(150) NOT NULL,
  rand1 VARCHAR(150) NOT NULL,
  rand2 VARCHAR(150) NOT NULL,
  rand3 VARCHAR(150) NOT NULL,
  rand4 VARCHAR(150) NOT NULL,
  rand5 VARCHAR(150) NOT NULL,
  user_password VARCHAR(150) NOT NULL,
  dor DATE NOT NULL,
  paid VARCHAR(150) NOT NULL,
  activated VARCHAR(150) NOT NULL,
  PRIMARY KEY(id),
  UNIQUE(username)
);
");
        
        //INSERT ADMIN INTO ADMINISTRATIVE TABLE
        $create_new_admin = new config(preg_replace('/\s+/', '_', $this->school_name0));
        $create_new_admin->execute_no_return("INSERT
INTO
  administrator(
    username,
    schoolname,
    schooltype,
    schooltelephone,
    schoolwebsite,
    schoolemail,
    rand1,
    rand2,
    rand3,
    rand4,
    rand5,
    user_password,
    dor,
    paid,
    activated
  )
VALUES(
  '$this->admin_username0',
  '$this->school_name0',
  '$this->school_type0',
  '$this->school_telephone0',
  '$this->school_website0',
  '$this->school_email0',
  '$rand1',
  '$rand2',
  '$rand3',
  '$rand4',
  '$rand5',
  '$this->admin_password0',
  NOW(), 'false', 'false')");
        
        $create_session = new config(preg_replace('/\s+/', '_', $this->school_name0));
        $create_session->execute_no_return("CREATE TABLE sessioner(
  id INT(25) NOT NULL AUTO_INCREMENT,
  username VARCHAR(150) NOT NULL,
  sessioner_val VARCHAR(150) NOT NULL,
  dos DATE NOT NUll,
  PRIMARY KEY(id),
  UNIQUE(username)
);
");
        //CREATE ADMIN LOGIN DUMP
        $create_dump = new config(preg_replace('/\s+/', '_', $this->school_name0));
        $create_dump->execute_no_return("CREATE TABLE admin_login_dump (id INT(25) NOT NULL AUTO_INCREMENT, username VARCHAR(150) NOT NULL , sessionid VARCHAR(150) NOT NULL , dol DATE NOT NULL, PRIMARY KEY(id) );");
        //CREATE STAFF LOGIN DUMP
        $create_dump1 = new config(preg_replace('/\s+/', '_', $this->school_name0));
        $create_dump1->execute_no_return("CREATE TABLE staff_login_dump (id INT(25) NOT NULL AUTO_INCREMENT, username VARCHAR(150) NOT NULL , sessionid VARCHAR(150) NOT NULL , dol DATE NOT NULL, PRIMARY KEY(id) );");
        //CREATE STUDENT LOGIN DUMP
        $create_dump2 = new config(preg_replace('/\s+/', '_', $this->school_name0));
        $create_dump2->execute_no_return("CREATE TABLE student_login_dump (id INT(25) NOT NULL AUTO_INCREMENT, username VARCHAR(150) NOT NULL , sessionid VARCHAR(150) NOT NULL , dol DATE NOT NULL, PRIMARY KEY(id) );");
//INSERT INTO RECORDS SCHOOLS
        $saveschool = new config("records");
        $saveschool->execute_no_return("INSERT INTO `schools`(`school_name`, `activated`, `dos`) VALUES ('$this->school_name0','false',now())");
        $code = sha1(md5(md5(uniqid())));
        $ins = new config("records");
        $ins->execute_no_return("INSERT INTO `activation_code`(`email`, `school_name`, `code`, `dos`) VALUES ('$this->school_email0','$this->school_name0','$code',now())");
        
     mkdir("../administrator/".preg_replace('/\s+/', '_', $this->school_name0));
     mkdir("../staffs/".preg_replace('/\s+/', '_', $this->school_name0));
     mkdir("../students/".preg_replace('/\s+/', '_', $this->school_name0));
        return 1;
        }
        else{
            return 0;
        }
    }
    
}

?>

