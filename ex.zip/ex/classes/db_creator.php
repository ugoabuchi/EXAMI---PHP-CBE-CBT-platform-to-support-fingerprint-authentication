<?php

ini_set('display_errors', 1);
ini_set('log_errors', 1);
define("dbhost1", "localhost");
define("dbuser1", "root");
define("dbpassword1", "root");
define("dbtype1", "mysql");

class db_creator {

    private $conn = null;

    function __construct() {

        try {
            $this->conn = new PDO(dbtype1 . ":host=" . dbhost1, dbuser1, dbpassword1);
            // set the PDO error mode to exception
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
        } catch (PDOException $e) {

            die("<div style='width: 80%; margin: auto; padding: 20px; text-align: center; font-size: 22px; color: #ff0000; background: #000000;'>We are sorry for this, please check back later. Error code : 01011</div>");
        }
    }
function execute_return_check_db($dsql) {

        try {
            $this->conn = $this->conn->query("SELECT IF(EXISTS (SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '".$dsql."'), 'Yes','No')");
            $this->conn = $this->conn->fetchAll(PDO::FETCH_BOTH);
            return $this->conn;
        } catch (PDOException $e) {
            
            return 0;
        }
    }
    function execute_no_return_create_db($dsql) {

        try {
            $this->conn->exec("CREATE DATABASE IF NOT EXISTS ".$dsql.";GRANT ALL PRIVILEGES ON DATABASE '".$dsql."' to root;");
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return 1;
            
        } catch (PDOException $e) {
            return 0;
        }
    }

    
    function __destruct() {
        $this->conn = null;
    }

}



?>