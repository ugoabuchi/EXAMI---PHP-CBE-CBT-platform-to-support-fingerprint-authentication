<?php
/* 
 The function of this class is to control user login
 */
session_start();
ini_set('display_errors', 1);
ini_set('log_errors', 1);
include_once 'config.php';
class loginizer{
    //Creating private virables
    private $school_name_db0 = null;
    private $username0 = null;
    private $password0 = null;
    private $user_type = null;
    private $sessionid = null;
    
    //Creating default construct
    function __construct($school_namee_db1, $username1, $password1, $user_type){
        //Assigning default values
        $this->school_name_db0 = strtolower("examicom_".$school_namee_db1);
        $this->username0 = $username1;
        $this->password0 = $password1;
        $this->user_type = $user_type;
        $this->sessionid = md5(sha1(md5(mt_rand())));
    }
    
    //Used for login a user
    function loginize_user()
    {
        
       if($this->user_type == "student")
       {
            $this->username0 = strtoupper($this->username0);
//Checking if user exist
        $check_username_exist = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
        if($check_username_exist->execute_count_no_return("SELECT COUNT(*) FROM students WHERE username = '$this->username0'") == 1)
        {
            //Username Exist
            //GET RAND PASSWORD VALUES
            $getrannds = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            $getrannds_val = $getrannds->execute_return("SELECT * FROM students WHERE username = '$this->username0'");
            if($getrannds_val == 0)
            {
                return "invalid_username_and_password_combination";
            }
            else
            {
                $db_password = $getrannds_val[0]['password'];
                $form_password = sha1($this->password0).sha1($getrannds_val[0]['rand1']).sha1($getrannds_val[0]['rand2']).sha1($getrannds_val[0]['rand3']).sha1($getrannds_val[0]['rand4']).sha1($getrannds_val[0]['rand5']);
                if($db_password == $form_password)
                {
                    
                    $chkey = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
                    $chkey = $chkey->execute_count_no_return("SELECT COUNT(*) FROM keytable WHERE stu_username='$this->username0'");
                    if($chkey == 1)
                    {
                        $rmkey = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            $rmkey->execute_no_return("DELETE FROM keytable WHERE stu_username = '$this->username0'");
                    }
               $newlogin = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            if($newlogin->execute_no_return("INSERT INTO student_login_dump(username, sessionid, dol) VALUES('$this->username0', '$this->sessionid',now())") == 1)
            {
            $_SESSION['sessionid'] = $this->sessionid;
            $_SESSION['username'] = $this->username0;
            $_SESSION['school_name'] = $this->school_name_db0;
            } 
            
            //Check if old session is still available
            $checksession = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            if($checksession->execute_count_no_return("SELECT COUNT(*) FROM sessioner WHERE username = '$this->username0'") == 1)
            {
                //delete previous session value
            $delsession = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            $delsession->execute_no_return("DELETE FROM sessioner WHERE username = '$this->username0'");
            }
            
            //save to sessioner table
            $savesession = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            $savesession->execute_no_return("INSERT INTO `sessioner`(`username`, `sessioner_val`, `dos`) VALUES ('$this->username0', '$this->sessionid',now())");
                    return "success";
                
         
            
        
                }
                else
                {
                    return "invalid_username_and_password_combination";
                }
            }
        }
        else
        {
            return "invalid_username_and_password_combination";
        }
       }
       else if($this->user_type == "staff")
       {
           $this->username0 = strtoupper($this->username0);
//Checking if user exist
        $check_username_exist = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
        if($check_username_exist->execute_count_no_return("SELECT COUNT(*) FROM staffs WHERE email = '$this->username0' AND root='true'") == 1)
        {
            //Username Exist
            //GET RAND PASSWORD VALUES
            $getrannds = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            $getrannds_val = $getrannds->execute_return("SELECT * FROM staffs WHERE email = '$this->username0' AND root='true'");
            if($getrannds_val == 0)
            {
                return "invalid_username_and_password_combination";
            }
            else
            {
                $db_password = $getrannds_val[0]['password'];
                $form_password = sha1($this->password0).sha1($getrannds_val[0]['rand1']).sha1($getrannds_val[0]['rand2']).sha1($getrannds_val[0]['rand3']).sha1($getrannds_val[0]['rand4']).sha1($getrannds_val[0]['rand5']);
                if($db_password == $form_password)
                {
               $newlogin = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            if($newlogin->execute_no_return("INSERT INTO staff_login_dump(username, sessionid, dol) VALUES('$this->username0', '$this->sessionid',now())") == 1)
            {
            $_SESSION['sessionid'] = $this->sessionid;
            $_SESSION['username'] = $this->username0;
            $_SESSION['school_name'] = $this->school_name_db0;
            } 
            
            //Check if old session is still available
            $checksession = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            if($checksession->execute_count_no_return("SELECT COUNT(*) FROM sessioner WHERE username = '$this->username0'") == 1)
            {
                //delete previous session value
            $delsession = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            $delsession->execute_no_return("DELETE FROM sessioner WHERE username = '$this->username0'");
            }
            
            //save to sessioner table
            $savesession = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            $savesession->execute_no_return("INSERT INTO `sessioner`(`username`, `sessioner_val`, `dos`) VALUES ('$this->username0', '$this->sessionid',now())");
                    return "success";
                
         
            
        
                }
                else
                {
                    return "invalid_username_and_password_combination";
                }
            }
        }
        else
        {
            return "invalid_username_and_password_combination";
        }
       }
       else if($this->user_type == "administrator")
       {
           //Checking if user exist
        $check_username_exist = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
        if($check_username_exist->execute_count_no_return("SELECT COUNT(*) FROM administrator WHERE username = '$this->username0'") == 1)
        {
            //Username Exist
            //GET RAND PASSWORD VALUES
            $getrannds = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            $getrannds_val = $getrannds->execute_return("SELECT * FROM administrator WHERE username = '$this->username0'");
            if($getrannds_val == 0)
            {
                return "invalid_username_and_password_combination";
            }
            else
            {
                $db_password = $getrannds_val[0]['user_password'];
                $form_password = sha1($this->password0).sha1($getrannds_val[0]['rand1']).sha1($getrannds_val[0]['rand2']).sha1($getrannds_val[0]['rand3']).sha1($getrannds_val[0]['rand4']).sha1($getrannds_val[0]['rand5']);
                if($db_password == $form_password)
                {
                  
            
            
            //Check if user account is activated
            if($getrannds_val[0]["activated"] != "true")
            {
                return "not_activated";
            }
            else
            {
               $newlogin = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            if($newlogin->execute_no_return("INSERT INTO admin_login_dump(username, sessionid, dol) VALUES('$this->username0', '$this->sessionid',now())") == 1)
            {
            $_SESSION['sessionid'] = $this->sessionid;
            $_SESSION['username'] = $this->username0;
            $_SESSION['school_name'] = $this->school_name_db0;
            } 
            
            //Check if old session is still available
            $checksession = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            if($checksession->execute_count_no_return("SELECT COUNT(*) FROM sessioner WHERE username = '$this->username0'") == 1)
            {
                //delete previous session value
            $delsession = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            $delsession->execute_no_return("DELETE FROM sessioner WHERE username = '$this->username0'");
            }
            
            //save to sessioner table
            $savesession = new config(preg_replace('/\s+/', '_', $this->school_name_db0));
            $savesession->execute_no_return("INSERT INTO `sessioner`(`username`, `sessioner_val`, `dos`) VALUES ('$this->username0', '$this->sessionid',now())");
                    return "success";
                
            }
            
        
                }
                else
                {
                    return "invalid_username_and_password_combination";
                }
            }
        }
        else
        {
            return "invalid_username_and_password_combination";
        }
       }
         else {
            return 0;    
                }
    }
    

}

?>