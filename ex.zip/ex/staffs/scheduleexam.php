<?php 
$title = "Schedule Exam";
$active1 = "";
$active2 = "activer";
$active3 = "";
$active4 = "";
$active5 = "";
$active6 = "activer";
$active7 = "";
$active8 = "";
$active9 = "";
if(isset($_POST['schdelete']))
{
    require_once '../classes/config.php';
    $sch = preg_replace('/\s+/', '_', $_POST['schoolname']);
    $etitle = base64_decode($_POST['etitle']);
    $edep = base64_decode($_POST['edep']);
    $etype = base64_decode($_POST['etype']);
    $elev = base64_decode($_POST['elev']);
    //delete schedule
    $desch = new config($sch);
    $desch->execute_no_return("DELETE FROM schedule WHERE title='$etitle' AND department='$edep' AND type='$etype' AND level='$elev'");
    die("success");
}
if(isset($_POST['schedule']))
{
     require_once '../classes/config.php';
    $dep = $_POST['department'];
    $typ = $_POST['type'];
    $level = $_POST['level'];
    $tit = $_POST['subjecttitle'];
    $start = $_POST['start'];
    $sch = preg_replace('/\s+/', '_', $_POST['schoolname']);
    
    
     
     //insert it to schedule table
     $newsch = new config($sch);
     $newsch->execute_no_return("INSERT INTO `schedule`(`title`, `start_date`,`department`, `type`, `level`) VALUES ('$tit', '$start', '$dep', '$typ', '$level')");
     
     echo "success";
     exit();      
}
require_once 'header.php'; 
//check if schedule db is created
$schde = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
$schde = $schde->execute_return("SHOW TABLES LIKE 'schedule'");
 if($schde == false && count($schde) <= 0)
 {
     //create schedule db
     $schdb = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
     $schdb->execute_no_return("CREATE TABLE `schedule` ( `id` INT(16) NOT NULL AUTO_INCREMENT , `title` VARCHAR(150) NOT NULL , `start_date` DATE NOT NULL , `department` VARCHAR(150) NOT NULL , `type` VARCHAR(150) NOT NULL , `level` VARCHAR(150) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;");
 }
?>
<style>
    #loader, #successAlert, #errorAlert, #successAlert4
    {
        display: none;
    }
    </style>
<div class="container">
    <div class="row">
        <div class="col-sm-12">
                        <div class="alert alert-success" id="successAlert">
                <strong>Success!</strong><span id="sat"></span>
</div>
            <div class="alert alert-danger" id="errorAlert">
                <strong>Error!</strong><span id="eat"></span>
</div>
            <div class="card" style="text-align: center;">
                <div class="card-header">Schedule Exam</div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="scheduleexam" name="schedulingexam" method="post" enctype="multipart/form-data"> 
                        
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-group"></i></span>
                                                   <select class="form-control" onchange="setType(this.value);" id="department" name="department" required="">
                                                       <option value="" selected="">SELECT DEPARTMENT</option>
                                                       <?php
                                                       $username = $_SESSION['username'];
                                                       $schoolname = preg_replace('/\s+/', '_', $_SESSION["school_name"]);
                                                        $stafdep = new config($schoolname);
                                                        $stafdep = $stafdep->execute_return("SELECT department FROM staffs WHERE email = '$username'");
                                                       
                                                        $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($stafdep); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($stafdep[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$stafdep[$i]["department"].'">'.$stafdep[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $stafdep[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
                                                       
                                                       ?>
                                                   </select>
                                                                        </div>
               
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setLevel(this.value);" class="form-control" id="type" name="type" required="">
                                                       <option value="" selected="">SELECT TYPE</option>
                                                   </select> </div>
            
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setTitle(this.value);" class="form-control" id="level" name="level" required="">
                                                       <option value="" selected="">SELECT LEVEL</option>
                                                   </select></div>
                        <div id="subjecttitler"></div>
                                                        
                         <div id="loader"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-primary" id="cema" type="submit" name="schedule" onclick="scheduler();" value="Schedule Exam" style="margin-bottom: 5px;"/> 
                        
                </div>
                                                            
                                                            </form>
            <br>
           
</div>
                </div>
        
        <div class="col-sm-12">
            <div class="col-sm-12">
                        <div class="alert alert-success" id="successAlert4">
                <strong>Success!</strong><span id="sat4"></span>
</div>
            <div class="card-header" style="text-align: center;">Scheduled Exams</div>
                <div class="card-body">
                    <div class="table-responsive" style="max-height: 500px; background: #ffffff; color: #000000;">
            <table class="table" style="font-size: 14px !important;">
    <thead>
    <tbody id="tablebofy">
       <?php
       $exams = new config(preg_replace('/\s+/', '_', $_SESSION["school_name"]));
      $exams = $exams->execute_return("SELECT department, type, level FROM staffs WHERE email='$username' AND root='true'");
     
      $dep1 = $exams[0]['department'];
      $typ1 = $exams[0]['type'];
      $lev1 = $exams[0]['level'];
       //show all scheduled exam
       $getSchedule = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
       
       $getSchedule = $getSchedule->execute_return("SELECT * FROM `schedule` WHERE department = '$dep1' AND type='$typ1' AND level='$lev1'");
      
       if(count($getSchedule) > 0)
       {
          
           for($d=0; $d<count($getSchedule); $d++)
           {
                
               echo '<tr><td colspan="4" style="text-align: center;">'.($d+1).'</td><td colspan="4" style="text-align: center;">'.$getSchedule[$d]['title'].'</td><td colspan="4" style="text-align: center;">'.$getSchedule[$d]['start_date'].'</td><td colspan="4" style="text-align: center;"><form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" method="post" name="dscheduling'.$getSchedule[$d]['id'].'" id="myschediling'.$getSchedule[$d]['id'].'" enctype="multipart/form-data"><input type="hidden" value="'. base64_encode($getSchedule[$d]['title']).'" name="etitle"/><input type="hidden" value="'. base64_encode($getSchedule[$d]['department']).'" name="edep"/><input type="hidden" value="'. base64_encode($getSchedule[$d]['type']).'" name="etype"/><input type="hidden" value="'. base64_encode($getSchedule[$d]['level']).'" name="elev"/><input class="form-control" type="hidden" name="schoolname" value="'.$_SESSION['school_name'].'" required="" /><input class="btn btn-danger" type="submit" name="schdelete" onclick="sexami(\''.$getSchedule[$d]['id'].'\');" value="DELETE"/> </form></td></tr>';
           }
       }
       else
       {
           echo '<tr><td colspan="4" style="text-align: center;">No Scheduled exams yet.</td></tr>';
       }
       ?>
    </tbody>
            </table>
                    </div>
                </div>
        </div>
    </div>
</div>
<script>
    function scheduler()
    {
         $('#scheduleexam').ajaxForm({
      beforeSubmit: function() {
          document.getElementById("successAlert").style.display = "none";
          document.getElementById("errorAlert").style.display = "none";
      },
      
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
        if(myResp == "success")
        {
            document.getElementById("sat").innerHTML = " Exam successfully scheduled, reloading page in 5 seconds.";
            document.getElementById("successAlert").style.display = "block";
            document.getElementById("errorAlert").style.display = "none";
            
          window.setInterval(function(){window.location.reload();},5000);
        }
        else
        {
            document.getElementById("sat").innerHTML = " Oops something went wrong, please make sure to use the date format suggested.";
            document.getElementById("successAlert").style.display = "none";
            document.getElementById("errorAlert").style.display = "block";
        }
      }
      });
    }
    function setType(e)
    {
        document.getElementById("type").value = "";
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/loadschedule.php",
        type: "post",
        data: "data=type"+"&department="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("type").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("type").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel(e)
    {
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/loadschedule.php",
        type: "post",
        data: "data=level"+"&type="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("level").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("level").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    function setTitle(e)
    {
      
         $.ajax({
        url: "../ajax_to_php_connectors/loadschedule.php",
        type: "post",
        data: "data=exams"+"&level="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("subjecttitler").innerHTML = myResp;
          

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    function setRemains(e)
    {
       
         $.ajax({
       url: "../ajax_to_php_connectors/loadschedule.php",
        type: "post",
        data: "data=remains"+"&title="+e,
       success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("drem").innerHTML = myResp;
          

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function sexami(e) 
  {
      
    $('#myschediling'+e).ajaxForm({
      beforeSubmit: function() {
        
      document.getElementById("successAlert4").style.display = "none";
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
          document.getElementById("sat4").innerHTML = "Successfully deleted, refreshing page in 5 seconds.";
          document.getElementById("successAlert4").style.display = "block";
          window.setInterval(function(){window.location.href = "scheduleexam.php";},5000);
      }
      
        });
    }
    
</script>
<?php require_once 'footer.php'; ?>