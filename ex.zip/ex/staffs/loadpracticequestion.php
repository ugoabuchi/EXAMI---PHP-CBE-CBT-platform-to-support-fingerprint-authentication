<?php 
$title = "Load Practice Questions";
$active1 = "";
$active2 = "";
$active3 = "";
$active4 = "";
$active5 = "activer";
$active6 = "";
$active7 = "";
$active8 = "";
$active9 = "";
$listofexam = "";

if(isset($_POST['loadQ1']))
{
     require_once '../classes/config.php';
     $dep = $_POST['department1'];
     $typ = $_POST['type1'];
     $lev = $_POST['level1'];
     $title = $_POST['subjecttitle1'];
     $schname = preg_replace('/\s+/', '_', $_POST['schoolname2']);
     $sn = (int)$_POST['sn'];
     $quest = $_POST['quest'];
     $ans = $_POST['ans'];
     
     
     //get no of questions
     $getq = new config($schname);
        $getq = $getq->execute_return("SELECT * FROM exam WHERE title='$title' AND department='$dep' AND type='$typ' AND level='$lev'");
        $dq = (int)$getq[0]['questions'];
        if($sn < 1 || $sn > $dq)
        {
            die("sn");
        } 
        

        
       
   
     //get no of answers
      $getans = new config($schname);
        $getans = $getans->execute_return("SELECT answers FROM exam WHERE title='$title' AND department='$dep' AND type='$typ' AND level='$lev'");
        $dans = (int)$getans[0]['answers'];
        if($dans == 2)
        {
            $a = $_POST['a'];
            $b = $_POST['b'];
            //check if override is set
            if(isset($_POST['override1']))
            {
                $over = new config($schname);
                $over = $over->execute_return("SELECT * FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                if(count($over) > 0)
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $oupdate = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                    $oupdate->execute_no_return("UPDATE pquestions SET question = '$quest', image = '', a = '$a', b = '$b', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                   move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("osuccess");
 }
                        
                    }
                    else
                    {
                        //check im iset 
                        $gimage = new config($schname);
                    $gimage=$gimage->execute_return("SELECT image FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    if($gimage[0]['image'] == "")
                    {
                        $oupdate = new config($schname);
                    $oupdate->execute_no_return("UPDATE pquestions SET pquestions = '$quest', image = '', a = '$a', b = '$b', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    die("oupdate");
                    }
                    else
                    {
                        $imname = $dep."".$typ."".$lev."".$title."".$sn;
                        $oupdate = new config($schname);
                    $oupdate->execute_no_return("UPDATE pquestions SET pquestions = '$quest', image = '', a = '$a', b = '$b', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    unlink($schname."/".$imname."p.png");
                    die("oupdate");
                    }
                        
                    }
                    
                }
                else
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $oinsert = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`,  `image`, `a`, `b`, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '$imname', '$a', '$b', '$ans', '$dep', '$typ', '$lev')");
                    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("osuccess");
 }
                        
                    }
                    else
                    {
                        $oinsert = new config($schname);
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`,  `image`, `a`, `b`, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '', '$a', '$b', '$ans', '$dep', '$typ', '$lev')");
                    die("osuccess");
               
                    }
                    
                    
                }
            }
            else
            {
                
                $over = new config($schname);
                $over = $over->execute_return("SELECT * FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                if(count($over) <= 0)
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $oinsert = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, `image`, `a`, `b`, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '$imname', '$a', '$b', '$ans', '$dep', '$typ', '$lev')");
                    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("isuccess");
 }
                        
                    }
                    else
                    {
                        $oinsert = new config($schname);
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`,  `image`, `a`, `b`, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '', '$a', '$b', '$ans', '$dep', '$typ', '$lev')");
                    die("isuccess");
               
                    }
                }
                else{
                    die("exist");
                }
            }
        }
        
        else if($dans == 3)
        {
            $a = $_POST['a'];
            $b = $_POST['b'];
            $c = $_POST['c'];
            //check if override is set
            if(isset($_POST['override1']))
            {
                $over = new config($schname);
                $over = $over->execute_return("SELECT * FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                if(count($over) > 0)
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $oupdate = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                    
                    $oupdate->execute_no_return("UPDATE pquestions SET question = '$quest', image = '', a = '$a', b = '$b', c = '$c', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                   move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("osuccess");
 }
                        
                    }
                    else
                    {
                        //check im iset 
                        $gimage = new config($schname);
                    $gimage=$gimage->execute_return("SELECT image FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    if($gimage[0]['image'] == "")
                    {
                        $oupdate = new config($schname);
                    $oupdate->execute_no_return("UPDATE pquestions SET question = '$quest', image = '', a = '$a', b = '$b', c = '$c', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    die("oupdate");
                    }
                    else
                    {
                        $imname = $dep."".$typ."".$lev."".$title."".$sn;
                        $oupdate = new config($schname);
                    $oupdate->execute_no_return("UPDATE pquestions SET question = '$quest', image = '', a = '$a', b = '$b', c = '$c', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    unlink($schname."/".$imname."p.png");
                    die("oupdate");
                    }
                        
                    }
                    
                }
                else
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $oinsert = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`,  `image`, `a`, `b`, c, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '$imname', '$a', '$b', '$c' '$ans', '$dep', '$typ', '$lev')");
                    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("osuccess");
 }
                        
                    }
                    else
                    {
                        $oinsert = new config($schname);
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`,  `image`, `a`, `b`, c, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '', '$a', '$b', '$c', '$ans', '$dep', '$typ', '$lev')");
                    die("osuccess");
               
                    }
                    
                    
                }
            }
            else
            {
                $over = new config($schname);
                $over = $over->execute_return("SELECT * FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                if(count($over) <= 0)
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $oinsert = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                    
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`,  `image`, `a`, `b`, c, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '$imname', '$a', '$b', '$c', '$ans', '$dep', '$typ', '$lev')");
                    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("isuccess");
 }
                        
                    }
                    else
                    {
                        $oinsert = new config($schname);
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`,  `image`, `a`, `b`, c, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '', '$a', '$b', '$c', '$ans', '$dep', '$typ', '$lev')");
                    die("isuccess");
               
                    }
                }
                else{
                    die("exist");
                }
            }
        }
        else if($dans == 4)
        {
             $a = $_POST['a'];
            $b = $_POST['b'];
            $c = $_POST['c'];
            $d = $_POST['d'];
            //check if override is set
            if(isset($_POST['override1']))
            {
                $over = new config($schname);
                $over = $over->execute_return("SELECT * FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                if(count($over) > 0)
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $oupdate = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                    $oupdate = new config($schname);
                    $oupdate->execute_no_return("UPDATE pquestions SET question = '$quest', image = '', a = '$a', b = '$b', c = '$c', d = '$d', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                   move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("osuccess");
 }
                        
                    }
                    else
                    {
                        //check im iset 
                        $gimage = new config($schname);
                   $gimage= $gimage->execute_return("SELECT image FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    if($gimage[0]['image'] == "")
                    {
                        $oupdate = new config($schname);
                    $oupdate->execute_no_return("UPDATE pquestions SET question = '$quest', image = '', a = '$a', b = '$b', c = '$c', d = '$d', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    die("oupdate");
                    }
                    else
                    {
                        $imname = $dep."".$typ."".$lev."".$title."".$sn;
                        $oupdate = new config($schname);
                    $oupdate->execute_no_return("UPDATE pquestions SET question = '$quest', image = '', a = '$a', b = '$b', c = '$c', d = '$d', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    unlink($schname."/".$imname."p.png");
                    die("oupdate");
                    }
                        
                    }
                    
                }
                else
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $oinsert = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`,  `image`, `a`, `b`, c, d, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '$imname', '$a', '$b', '$c', '$d', '$ans', '$dep', '$typ', '$lev')");
                    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("osuccess");
 }
                        
                    }
                    else
                    {
                        $oinsert = new config($schname);
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`,  `image`, `a`, `b`, c, d, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '$imname', '$a', '$b', '$c', '$d', '$ans', '$dep', '$typ', '$lev')");
                    die("osuccess");
               
                    }
                    
                    
                }
            }
            else
            {
                $over = new config($schname);
                $over = $over->execute_return("SELECT * FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
              
                if(count($over) <= 0)
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $oinsert = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, `image`, `a`, `b`, c, d, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '$imname', '$a', '$b', '$c', '$d', '$ans', '$dep', '$typ', '$lev')");
                    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("isuccess");
 }
                        
                    }
                    else
                    {
                        $oinsert = new config($schname);
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, `image`, `a`, `b`, c, d, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '', '$a', '$b', '$c', '$d', '$ans', '$dep', '$typ', '$lev')");
                    die("isuccess");
               
                    }
                }
                else{
                    die("exist");
                }
            }
        }
        else
        {
            $a = $_POST['a'];
            $b = $_POST['b'];
            $c = $_POST['c'];
            $d = $_POST['d'];
            $e = $_POST['e'];
            //check if override is set
            if(isset($_POST['override1']))
            {
                $over = new config($schname);
                $over = $over->execute_return("SELECT * FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                if(count($over) > 0)
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
       $oupdate = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                   
                    $oupdate->execute_no_return("UPDATE pquestions SET question = '$quest', image = '', a = '$a', b = '$b', c = '$c', d = '$d', e = '$e', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("osuccess");
 }
                        
                    }
                    else
                    {
                        //check im iset 
                        $gimage = new config($schname);
                    $gimage = $gimage->execute_return("SELECT image FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    if($gimage[0]['image'] == "")
                    {
                        $oupdate = new config($schname);
                    $oupdate->execute_no_return("UPDATE pquestions SET question = '$quest', image = '', a = '$a', b = '$b', c = '$c', d = '$d', e = '$e', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    die("oupdate");
                    }
                    else
                    {
                        $imname = $dep."".$typ."".$lev."".$title."".$sn;
                        $oupdate = new config($schname);
                    $oupdate->execute_no_return("UPDATE pquestions SET question = '$quest', image = '', a = '$a', b = '$b', c = '$c', d = '$d', e = '$e', answer = '$ans' WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                    unlink($schname."/".$imname."p.png");
                    die("oupdate");
                    }
                        
                    }
                    
                }
                else
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $oinsert = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`,  `image`, `a`, `b`, c, d, e, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '$imname', '$a', '$b', '$c', '$d', '$e', '$ans', '$dep', '$typ', '$lev')");
                    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("osuccess");
 }
                        
                    }
                    else
                    {
                        $oinsert = new config($schname);
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, `image`, `a`, `b`, c, d, e, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '$imname', '$a', '$b', '$c', '$d', '$e', '$ans', '$dep', '$typ', '$lev')");
                    die("osuccess");
               
                    }
                    
                    
                }
            }
            else
            {
                $over = new config($schname);
                $over = $over->execute_return("SELECT * FROM pquestions WHERE sn='$sn' AND title = '$title' AND department='$dep' AND type = '$typ' AND level = '$lev'");
                if(count($over) <= 0)
                {
                    if(isset($_FILES['qimage']))
                    {
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $oinsert = new config($schname);
                    $imname = $dep."".$typ."".$lev."".$title."".$sn;
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, `image`, `a`, `b`, c, d, e, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '$imname', '$a', '$b', '$c', '$d', '$e', '$ans', '$dep', '$typ', '$lev')");
                    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("isuccess");
 }
                        
                    }
                    else
                    {
                        $oinsert = new config($schname);
                    $oinsert->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, `image`, `a`, `b`, c, d, e, `answer`, `department`, `type`, `level`) VALUES ('$sn', '$title', '$quest', '$imname', '$a', '$b', '$c', '$d', '$e', '$ans', '$dep', '$typ', '$lev')");
                    die("isuccess");
               
                    }
                }
                else{
                    die("exist");
                }
            }
        }
     
}
if(isset($_POST['update']))
{
    
    unset($_POST['update']);
    require_once '../classes/config.php';
    
    $sn = $_POST["sn"];
     $ans= $_POST["ans".$sn];
        $tit = $_POST['tit'];
        $dee = $_POST['dee'];
        $tee = $_POST['tee'];
        $lee = $_POST['lee'];
         $schname = preg_replace('/\s+/', '_', $_POST['schoolname']);
         
       
        
    
        if(isset($_FILES['qimage']))
        {
            
            if(count($_POST) == 14)
    {
       
        
        $q = $_POST["q".$sn];
        $a = $_POST["a".$sn];
        $b = $_POST["b".$sn];
        $c = $_POST["c".$sn];
        $d = $_POST["d".$sn];
        $e = $_POST["e".$sn];
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $updateer = new config($schname);
                    $imname = $dee."".$tee."".$lee."".$tit."".$sn;
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='$imname', a='$a', b='$b', c='$c', d='$d', e='$e', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("success");
 }
                        
                    
      
    }
    
    else if(count($_POST) == 13)
    {
        
      
        $q = $_POST["q".$sn];
        $a = $_POST["a".$sn];
        $b = $_POST["b".$sn];
        $c = $_POST["c".$sn];
        $d = $_POST["d".$sn];
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $updateer = new config($schname);
                    $imname = $dee."".$tee."".$lee."".$tit."".$sn;
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='$imname', a='$a', b='$b', c='$c', d='$d', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("success");
 }
                
       
    }
    else if(count($_POST) == 12)
    {
        
       
      
        $q = $_POST["q".$sn];
        $a = $_POST["a".$sn];
        $b = $_POST["b".$sn];
        $c = $_POST["c".$sn];
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $updateer = new config($schname);
                    $imname = $dee."".$tee."".$lee."".$tit."".$sn;
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='$imname', a='$a', b='$b', c='$c', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("success");
 }
                        
                    
     
    }
 else {
        $q = $_POST["q".$sn];
        $a = $_POST["a".$sn];
        $b = $_POST["b".$sn];
                        
                        $fileinfo = @getimagesize($_FILES["qimage"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "PNG",
        "JPG",
        "JPEG"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["qimage"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'imager';
        exit();
    } 
    else if (($_FILES["qimage"]["size"] > 4000000)) {
        echo 'size';
        exit();
    }
 else {
     
      $updateer = new config($schname);
                    $imname = $dee."".$tee."".$lee."".$tit."".$sn;
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='$imname', a='$a', b='$b', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
    move_uploaded_file($_FILES["qimage"]["tmp_name"], $schname."/".$imname."p.png");
                    die("success");
 }
                  
      
    }
        }
        else
        {
           
            
            if(count($_POST) == 14)
    {
       
        
        $q = $_POST["q".$sn];
        $a = $_POST["a".$sn];
        $b = $_POST["b".$sn];
        $c = $_POST["c".$sn];
        $d = $_POST["d".$sn];
        $e = $_POST["e".$sn];
       
             //check im iset 
                        $gimage = new config($schname);
                    $gimage = $gimage->execute_return("SELECT image FROM pquestions WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
                    if($gimage[0]['image'] == "")
                    {
                        $updateer = new config($schname);
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='', a='$a', b='$b', c='$c', d='$d', e='$e', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
    die("success");
                    }
                    else
                    {
                        $imname = $dee."".$tee."".$lee."".$tit."".$sn;
                        $updateer = new config($schname);
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='', a='$a', b='$b', c='$c', d='$d', e='$e', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
   unlink($schname."/".$imname."p.png");
                    die("success");
                    }
        
    }
    
    else if(count($_POST) == 13)
    {
        
      
        $q = $_POST["q".$sn];
        $a = $_POST["a".$sn];
        $b = $_POST["b".$sn];
        $c = $_POST["c".$sn];
        $d = $_POST["d".$sn];
        
                        $gimage = new config($schname);
                   $gimage = $gimage->execute_return("SELECT * FROM pquestions WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
                   
                    if($gimage[0]['image'] == "")
                    {
                        
                        $updateer = new config($schname);
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='', a='$a', b='$b', c='$c', d='$d', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
    die("success");
                    }
                    else
                    {
                        
                        $imname = $dee."".$tee."".$lee."".$tit."".$sn;
                        $updateer = new config($schname);
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='', a='$a', b='$b', c='$c', d='$d', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
                    
                    unlink($schname."/".$imname."p.png");
                    die("success");
                    }
        
    }
    else if(count($_POST) == 12)
    {
        
       
      
        $q = $_POST["q".$sn];
        $a = $_POST["a".$sn];
        $b = $_POST["b".$sn];
        $c = $_POST["c".$sn];
 
             //check im iset 
                        $gimage = new config($schname);
                    $gimage=$gimage->execute_return("SELECT image FROM pquestions WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
                    if($gimage[0]['image'] == "")
                    {
                        $updateer = new config($schname);
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='', a='$a', b='$b', c='$c', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
    die("success");
                    }
                    else
                    {
                        $imname = $dee."".$tee."".$lee."".$tit."".$sn;
                        $updateer = new config($schname);
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='', a='$a', b='$b', c='$c', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
   unlink($schname."/".$imname."p.png");
                    die("success");
                    }
        
    }
 else {
        $q = $_POST["q".$sn];
        $a = $_POST["a".$sn];
        $b = $_POST["b".$sn];
 
             //check im iset 
                        $gimage = new config($schname);
                    $gimage=$gimage->execute_return("SELECT image FROM pquestions WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
                    if($gimage[0]['image'] == "")
                    {
                        $updateer = new config($schname);
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='', a='$a', b='$b', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
    die("success");
                    }
                    else
                    {
                        $imname = $dee."".$tee."".$lee."".$tit."".$sn;
                        $updateer = new config($schname);
                    $updateer = $updateer->execute_no_return("UPDATE pquestions set question='$q', image='', a='$a', b='$b', answer='$ans' WHERE sn='$sn' AND title='$tit' AND department='$dee' AND type='$tee' AND level = '$lee'");
   unlink($schname."/".$imname."p.png");
                    die("success");
                    }
        
    }
        }
        
        
        
        
        
        
        
        
}
if(isset($_POST['loadQ']))
{
    require_once '../classes/config.php';
    $choolname = preg_replace('/\s+/', '_', $_POST['schoolname']);
    $department = $_POST['department'];
    $type = $_POST['type'];
    $level = $_POST['level'];
    $titler = $_POST['subjecttitle'];
    
 
    if($department == "" || $type == "" || $level == "" || $title == "" || !isset($_FILES["upload_file"]))
    {
        die("empty");
    }
    $fileinfo = @getimagesize($_FILES["upload_file"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    $filearra = array();
    $allowed_image_extension = array(
        "CSV"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["upload_file"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'invalidf';
        exit();
    } 
    
 else {
     $filename=$_FILES["upload_file"]["tmp_name"];		
 
 
		 if($_FILES["upload_file"]["size"] > 0)
		 {
                     require_once '../classes/config.php';
                    $file = fopen($filename, "r");
	        while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
	         {
                    $filearra = array_merge($filearra, array($getData));
                }
			
	         fclose($file);
                 
             
                 //compare number of rows with exam setting
                 
                 $getanswer = new config($choolname);
                 $getanswer = $getanswer->execute_return("SELECT questions,answers FROM exam WHERE title = '$titler' AND department = '$department' AND type='$type' AND level='$level'");
                 if(count($filearra) > (int)$getanswer[0]['questions'] || count($filearra) < 1)
                 {
                     die("invalidquestion");
                 }
                 for($i=0; $i<count($filearra); $i++)
                 {
                     if(count($filearra[$i]) != (((int)$getanswer[0]['answers']) + 3))
                     {
                         die("invalidanswers");
                     }
                     
                 }
                 
                 //check equal sn in csv
                 for($i=0; $i<count($filearra); $i++)
                        {
                      for($j=($i+1); $j<count($filearra); $j++)
                      {
                          if($filearra[$i][0] == $filearra[$j][0])
                          {
                              die("equalsn");
                          }
                      }
                        }
                        
                
    
                //dont forget to check overriden bytton
                if(isset($_POST['override']))
                {
                    
                    $remains = array();
                    //check if there any question to override
                    $prevquestion = new config($choolname);
                    $prevquestion = $prevquestion->execute_return("SELECT * FROM pquestions WHERE title='$titler' AND department = '$department' AND type = '$type' AND level = '$level'");
                    //remain question not uploaded
                    $rcount = count($prevquestion);
                    //count remain in files
                    $remain = 0;
                    for($i=0; $i<count($filearra); $i++)
                        {
                        $dsn = $filearra[$i][0];
                        $dch = new config($choolname);
                        $dch = $dch->execute_count_no_return("SELECT COUNT(*) FROM pquestions WHERE sn = '$dsn' AND title='$titler' AND department = '$department' AND type = '$type' AND level = '$level'");
                        
                        if($dch == 1)
                        {
                            continue;
                        }
                        else
                        {
                            $remain++;
                        }
                        }
                        if(($remain + $rcount) > (int)$getanswer[0]['questions'])
                        {
                            die("override_error");
                        }
                    if(count($prevquestion) > 0)
                    {
                        //override
                        for($i=0; $i<count($filearra); $i++)
                        {
                            //delet image if pressent
                            $xxxn = $filearra[$i][0];
                            
                            
                            
                            
                                $ch = new config($choolname);
                                
                                $ch = $ch->execute_return("SELECT * FROM pquestions WHERE sn = '$xxxn' AND title='$titler' AND department = '$department' AND type = '$type' AND level = '$level'");
                                if(count($ch) > 0)
                                {
                                    
                                    
                                    $psn = $filearra[$i][0];
                                    $gimage = new config($choolname);
                            $gimage = $gimage->execute_return("SELECT image FROM pquestions WHERE sn = '$psn' AND title='$titler' AND department = '$department' AND type = '$type' AND level = '$level'");
                    if($gimage[0]['image'] != "")
                    {
                        $imname = $department."".$type."".$level."".$titler."".$psn;
                         unlink($choolname."/".$imname."p.png");
                    }
                                    $dquest = $filearra[$i][1];
                                    $updatequestion = new config($choolname);
                                    if(((int)$getanswer[0]['answers']) == 2)
                                    {
                                        
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $ans = $filearra[$i][4];
                                        $updatequestion->execute_no_return("UPDATE pquestions SET question = '$dquest', image='', a = '$a', b = '$b', answer = '$ans' WHERE sn = '$psn' AND title='$titler' AND department = '$department' AND type = '$type' AND level = '$level'");
                                    }
                                    else if(((int)$getanswer[0]['answers']) == 3)
                                    {
                                         $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $ans = $filearra[$i][5];
                                        $updatequestion->execute_no_return("UPDATE pquestions SET question = '$dquest', image='', a = '$a', b = '$b', c = '$c', answer = '$ans' WHERE sn = '$psn' AND title='$titler' AND department = '$department' AND type = '$type' AND level = '$level'");
                                    }
                                    else if(((int)$getanswer[0]['answers']) == 4)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $d = $filearra[$i][5];
                                        $ans = $filearra[$i][6];
                                        $updatequestion->execute_no_return("UPDATE pquestions SET question = '$dquest', image='', a = '$a', b = '$b', c = '$c', d = '$d', answer = '$ans' WHERE sn = '$psn' AND title='$titler' AND department = '$department' AND type = '$type' AND level = '$level'");
                                   
                                    }
                                    else
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $d = $filearra[$i][5];
                                        $e = $filearra[$i][6];
                                        $ans = $filearra[$i][7];
                                        $updatequestion->execute_no_return("UPDATE pquestions SET question = '$dquest', image='', a = '$a', b = '$b', c = '$c', d = '$d', e = '$e', answer = '$ans' WHERE sn = '$psn' AND title='$titler' AND department = '$department' AND type = '$type' AND level = '$level'");
                                   
                                   
                                    }
                                    
                                }
                            
                        }
                        
                        //Insert the remainders
                        for($i=0; $i<count($filearra); $i++)
                        {
                                $xxxn = $filearra[$i][0];
                            
                                $ch = new config($choolname);
                                $ch = $ch->execute_return("SELECT * FROM pquestions WHERE sn = '$xxxn' AND title='$titler' AND department = '$department' AND type = '$type' AND level = '$level'");
                                if(count($ch) > 0)
                                {
                                    continue;
                                }
                                else
                                {
                                    //insert
                                    $psn = $filearra[$i][0];
                                    $dquest = $filearra[$i][1];
                                    $insertnew = new config($choolname);
                                    if(((int)$getanswer[0]['answers']) == 2)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $ans = $filearra[$i][4];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest', '','$a','$b','$ans','$department','$type','$level')");
                                    }
                                    else if(((int)$getanswer[0]['answers']) == 3)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $ans = $filearra[$i][5];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `c`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c', '$ans','$department','$type','$level')");
                                    }
                                    else if(((int)$getanswer[0]['answers']) == 4)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $d = $filearra[$i][5];
                                        $ans = $filearra[$i][6];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `c`, `d`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c','$d','$ans','$department','$type','$level')");
                                    }
                                    else
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $d = $filearra[$i][5];
                                        $e = $filearra[$i][6];
                                        $ans = $filearra[$i][7];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `c`, `d`, `e`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c','$d','$e','$ans','$department','$type','$level')");
                                    
                                    }
                                }
                            
                        }
                        die("updatesuccess");
                    }
                    else
                    {
                        for($i=0; $i<count($filearra); $i++)
                        {
                             $psn = $filearra[$i][0];
                                    $dquest = $filearra[$i][1];
                                    $insertnew = new config($choolname);
                                    if(((int)$getanswer[0]['answers']) == 2)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $ans = $filearra[$i][4];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$ans','$department','$type','$level')");
                                    }
                                    else if(((int)$getanswer[0]['answers']) == 3)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $ans = $filearra[$i][5];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `c`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c', '$ans','$department','$type','$level')");
                                    }
                                    else if(((int)$getanswer[0]['answers']) == 4)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $d = $filearra[$i][5];
                                        $ans = $filearra[$i][6];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `c`, `d`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c','$d','$ans','$department','$type','$level')");
                                    }
                                    else
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $d = $filearra[$i][5];
                                        $e = $filearra[$i][6];
                                        $ans = $filearra[$i][7];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `c`, `d`, `e`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c','$d','$e','$ans','$department','$type','$level')");
                                    
                                    }
                        }
                        die("insuccess");
                    }
                    
                }
                else
                {
                   
                   $prevquestion = new config($choolname);
                    $prevquestion = $prevquestion->execute_return("SELECT * FROM pquestions WHERE title='$titler' AND department = '$department' AND type = '$type' AND level = '$level'");
                   if(count($prevquestion) > 0)
                    {
                      
                        
                        //skip if sn is not empty
                        for($i=0; $i<count($filearra); $i++)
                        { $xxxn = $filearra[$i][0];
                            
                                $ch = new config($choolname);
                                $ch = $ch->execute_return("SELECT * FROM pquestions WHERE sn = '$xxxn' AND title='$titler' AND department = '$department' AND type = '$type' AND level = '$level'");
                                if(count($ch) > 0)
                                {
                                    continue;
                                }
                                else
                                {
                                     //insert
                                    $psn = $filearra[$i][0];
                                    $dquest = $filearra[$i][1];
                                    $insertnew = new config($choolname);
                                    if(((int)$getanswer[0]['answers']) == 2)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $ans = $filearra[$i][4];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$ans','$department','$type','$level')");
                                    }
                                    else if(((int)$getanswer[0]['answers']) == 3)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $ans = $filearra[$i][5];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `c`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c','$ans','$department','$type','$level')");
                                    }
                                    else if(((int)$getanswer[0]['answers']) == 4)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $d = $filearra[$i][5];
                                        $ans = $filearra[$i][6];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image `a`, `b`, `c`, `d`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c','$d','$ans','$department','$type','$level')");
                                    }
                                    else
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $d = $filearra[$i][5];
                                        $e = $filearra[$i][6];
                                        $ans = $filearra[$i][7];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `c`, `d`, `e`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c','$d','$e','$ans','$department','$type','$level')");
                                    
                                    }
                                }
                            
                        }
                        
                        die("updatesuccess");
                    }
                    else
                    {
                        for($i=0; $i<count($filearra); $i++)
                        {
                             $psn = $filearra[$i][0];
                                    $dquest = $filearra[$i][1];
                                    $insertnew = new config($choolname);
                                    if(((int)$getanswer[0]['answers']) == 2)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $ans = $filearra[$i][4];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$ans','$department','$type','$level')");
                                    }
                                    else if(((int)$getanswer[0]['answers']) == 3)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $ans = $filearra[$i][5];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `c`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c', '$ans','$department','$type','$level')");
                                    }
                                    else if(((int)$getanswer[0]['answers']) == 4)
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $d = $filearra[$i][5];
                                        $ans = $filearra[$i][6];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `c`, `d`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c','$d','$ans','$department','$type','$level')");
                                    }
                                    else
                                    {
                                        $a = $filearra[$i][2];
                                        $b = $filearra[$i][3];
                                        $c = $filearra[$i][4];
                                        $d = $filearra[$i][5];
                                        $e = $filearra[$i][6];
                                        $ans = $filearra[$i][7];
                                        $insertnew->execute_no_return("INSERT INTO `pquestions`(`sn`, `title`, `question`, image, `a`, `b`, `c`, `d`, `e`, `answer`, `department`, `type`, `level`) VALUES ('$psn','$titler','$dquest','','$a','$b','$c','$d','$e','$ans','$department','$type','$level')");
                                    
                                    }
                        }
                        die("insuccess");
                    }
                }
                
                
                
                
                 }
                 else
                 {
                     die("emptyf");
                 }
    }
  
}
require_once 'header.php'; 

 //check if questions table is set
                 $checkt = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                    $checkt = $checkt->execute_return("SHOW TABLES LIKE 'pquestions'");
    if($checkt == false && count($checkt) <= 0)
    {
        //create table;
        $questions = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $questions->execute_no_return("CREATE TABLE `pquestions` ( `id` INT(16) NOT NULL AUTO_INCREMENT , `sn` INT(16) NOT NULL , `title` VARCHAR(150) NOT NULL , `question` TEXT NOT NULL , `image` VARCHAR(150) NOT NULL , `a` VARCHAR(150) NULL , `b` VARCHAR(150) NULL , `c` VARCHAR(150) NULL , `d` VARCHAR(150) NULL , `e` VARCHAR(150) NULL , `answer` VARCHAR(150) NULL , `department` VARCHAR(150) NOT NULL , `type` VARCHAR(150) NOT NULL , `level` VARCHAR(150) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;");
    }
?>

<style>
    .progress {text-align:left;margin-top:20px;display:none; position:relative; width:100%; border: 1px solid #ddd; padding: 1px; border-radius: 3px; }
.bar { background-color:#2E64FE; width:0%; height:30px; border-radius: 3px; }
.percent { position:absolute; display:inline-block; left:48%; top: 0px; bottom: 2px; color: #ffffff; font-weight: bold; }
#out
{
  margin-top:20px;
  width:300px;
}
    #loader, #successAlert, #errorAlert, #loadering, #errorAlert1, #successAlert1, #errorAlert2, #successAlert2, #errorAlert3, #successAlert3, #loader1
    {
        display: none;
    }
    
    .fortune_modal
    {
        padding: 5px;
        width: 90%;
        margin: auto;
        position: fixed;
        right: 5px;
        left: 5px;
        top: 5px;
        z-index: 999999999 !important;
        background: rgba(26,0,0,0.8);
        display: none;
    }
    
    .fortune_modal_head{
        color: #ffffff;
        margin-bottom: 20px;
        
    }
    
    .fortune_modal_head i{
        cursor: crosshair;
    }
    
    .fortune_modal_body
    {
        padding: 3px;
        background: rgb(255,255,255); 
        text-align: center;
        height: 700px;
        overflow-x: auto;
    }
    </style>
    <?php
    if(isset($_GET['title']) && isset($_GET['dep']) && isset($_GET['type']) && isset($_GET['level']))
    {
        echo '<style>'
        . ' .header-desktop{'
                . 'z-index: 0 !important;'
                . '} '
                . '</style>';
        $tit = base64_decode($_GET['title']);
        $dee = base64_decode($_GET['dep']);
        $tee = base64_decode($_GET['type']);
        $lee = base64_decode($_GET['level']);
        $schoolname = preg_replace('/\s+/', '_', $_SESSION['school_name']);
        //get exam answers no
        $getans = new config($schoolname);
        $getans = $getans->execute_return("SELECT answers FROM exam WHERE title='$tit' AND department='$dee' AND type='$tee' AND level='$lee'");
        $dans = (int)$getans[0]['answers'];
        echo '<div class=" container fortune_modal">
        <div class="fortune_modal_head">
            <i class="fa fa-times-circle pull-right exit" onclick="document.getElementsByClassName(\'fortune_modal\')[0].style.display=\'none\';"></i>
            
        </div>
        <div class="alert alert-success" id="successAlert2">
                <strong>Success!</strong><span id="sat2"></span>
</div>
            <div class="alert alert-danger" id="errorAlert2">
                <strong>Error!</strong><span id="eat2"></span>
</div>
        <div class="fortune_modal_body">';
        //select all question int he exam that meets criteria
            $question = new config($schoolname);
            $question = $question->execute_return("SELECT * FROM pquestions WHERE title='$tit' AND department='$dee' AND type='$tee' AND level='$lee' ORDER BY sn ASC");
       
            
            for($i=0; $i<count($question); $i++)
            {
                if($dans == 2)
                {
                    echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="former'.$question[$i]["sn"].'" method="post" enctype="multipart/form-data" >      
                                                            <div class="input-group">
                                                           <span class="input-group-addon" style="background: none; border: none; font-size: 1em !important;"><i>'.$question[$i]["sn"].'</i></span>
                                                         <input class="form-control" type="hidden" name="tit" value="'.$tit.'" required="" /><input class="form-control" type="hidden" name="dee" value="'.$dee.'" required="" /><input class="form-control" type="hidden" name="tee" value="'.$tee.'" required="" /><input class="form-control" type="hidden" name="lee" value="'.$lee.'" required="" /> <input class="form-control" type="hidden" name="schoolname" value="'.$_SESSION['school_name'].'" required="" /><input type="hidden" name="sn" value="'.$question[$i]["sn"].'" />
                                                           <textarea class="form-control" name="q'.$question[$i]["sn"].'" required="" style="height: 50px; resize: none; border: none; font-size: 1em !important;">'.$question[$i]["question"].'</textarea>
                                                                        </div> 
                                                                        <p style="text-align: center;">Upload Question Image(Optional): Image must be less or eqaul to 4mb and must be in either of the following format: jpg, png, jpeg.</p>
               
               <div class="input-group"  style="margin-bottom:10px;">
                                       
                                    <span class="input-group-addon"><i class="fa fa-upload"></i></span>
                                    <input type="file" accept=".jpg, .png, .jpeg" name="qimage" class="form-control" />
               </div>
                                                                        <div style="margin-bottom: 25px; text-align:left;">
                                                          
                                                           &nbsp;<i style="font-size: 1em !important;">A.</i>&nbsp;<input  name="a'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["a"].'"/>
                                                           &nbsp;<i style="font-size: 1em !important;">B.</i>&nbsp;<input name="b'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["b"].'"/>
                                                               &nbsp;<i style="font-size: 1em !important;">Ans.</i>&nbsp;<input name="ans'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["answer"].'"/>
</div>                                                          <button type="submit" class="btn btn-primary" name="update" onclick = "updateQ(\''.$question[$i]["sn"].'\');">Update Question '.$question[$i]["sn"].'</button>
                                                                        </form>
            ';
                }
                else if($dans == 3)
                {
                    echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="former'.$question[$i]["sn"].'" method="post" enctype="multipart/form-data" >      
                                                            <div class="input-group">
                                                           <span class="input-group-addon" style="background: none; border: none; font-size: 1em !important;"><i>'.$question[$i]["sn"].'</i></span>
                                                          <input class="form-control" type="hidden" name="tit" value="'.$tit.'" required="" /><input class="form-control" type="hidden" name="dee" value="'.$dee.'" required="" /><input class="form-control" type="hidden" name="tee" value="'.$tee.'" required="" /><input class="form-control" type="hidden" name="lee" value="'.$lee.'" required="" /><input class="form-control" type="hidden" name="schoolname" value="'.$_SESSION['school_name'].'" required="" /><input type="hidden" name="sn" value="'.$question[$i]["sn"].'" />
                                                           <textarea class="form-control" name="q'.$question[$i]["sn"].'" required="" style="height: 50px; resize: none; border: none; font-size: 1em !important;">'.$question[$i]["question"].'</textarea>
                                                                        </div> 
                                                                        <p style="text-align: center;">Upload Question Image(Optional): Image must be less or eqaul to 4mb and must be in either of the following format: jpg, png, jpeg.</p>
               
               <div class="input-group"  style="margin-bottom:10px;">
                                       
                                    <span class="input-group-addon"><i class="fa fa-upload"></i></span>
                                    <input type="file" accept=".jpg, .png, .jpeg" name="qimage" class="form-control" />
               </div>
                                                                        <div style="margin-bottom: 25px; text-align:left;">
                                                          
                                                           &nbsp;<i style="font-size: 1em !important;">A.</i>&nbsp;<input  name="a'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["a"].'"/>
                                                           &nbsp;<i style="font-size: 1em !important;">B.</i>&nbsp;<input name="b'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["b"].'"/>
                                                            &nbsp;<i style="font-size: 1em !important;">C.</i>&nbsp;<input name="c'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["c"].'"/>   
                                                               &nbsp;<i style="font-size: 1em !important;">Ans.</i>&nbsp;<input name="ans'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["answer"].'"/>
</div>                                                          <button type="submit" class="btn btn-primary" name="update" onclick = "updateQ(\''.$question[$i]["sn"].'\');">Update Question '.$question[$i]["sn"].'</button>
                                                                        </form>
            ';
                }
                else if($dans == 4)
                {
                    echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="former'.$question[$i]["sn"].'" method="post" enctype="multipart/form-data" >      
                                                            <div class="input-group">
                                                           <span class="input-group-addon" style="background: none; border: none; font-size: 1em !important;"><i>'.$question[$i]["sn"].'</i></span>
                                                          <input class="form-control" type="hidden" name="tit" value="'.$tit.'" required="" /><input class="form-control" type="hidden" name="dee" value="'.$dee.'" required="" /><input class="form-control" type="hidden" name="tee" value="'.$tee.'" required="" /><input class="form-control" type="hidden" name="lee" value="'.$lee.'" required="" /><input class="form-control" type="hidden" name="schoolname" value="'.$_SESSION['school_name'].'" required="" /><input type="hidden" name="sn" value="'.$question[$i]["sn"].'" />
                                                           <textarea  id="editor'.$question[$i]["sn"].'" onclick="initSample(\''.$question[$i]["sn"].'\');" class="form-control" name="q'.$question[$i]["sn"].'" required="" style="height: 50px; resize: none; border: none; font-size: 1em !important;">'.$question[$i]["question"].'</textarea>
                                                                        </div> 
                                                                        <p style="text-align: center;">Upload Question Image(Optional): Image must be less or eqaul to 4mb and must be in either of the following format: jpg, png, jpeg.</p>
               
               <div class="input-group"  style="margin-bottom:10px;">
                                       
                                    <span class="input-group-addon"><i class="fa fa-upload"></i></span>
                                    <input type="file" accept=".jpg, .png, .jpeg" name="qimage" class="form-control" />
               </div>
                                                                        <div style="margin-bottom: 25px; text-align:left;">
                                                          
                                                           &nbsp;<i style="font-size: 1em !important;">A.</i>&nbsp;<input  name="a'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["a"].'"/>
                                                           &nbsp;<i style="font-size: 1em !important;">B.</i>&nbsp;<input name="b'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["b"].'"/>
                                                            &nbsp;<i style="font-size: 1em !important;">C.</i>&nbsp;<input name="c'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["c"].'"/>
                                                            &nbsp;<i style="font-size: 1em !important;">D.</i>&nbsp;<input name="d'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["d"].'"/>   
                                                               &nbsp;<i style="font-size: 1em !important;">Ans.</i>&nbsp;<input name="ans'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["answer"].'"/>
</div>                                                         <button type="submit" class="btn btn-primary" name="update" onclick = "updateQ(\''.$question[$i]["sn"].'\');">Update Question '.$question[$i]["sn"].'</button>
                                                                        </form>
            ';
                }
                else
                {
                    
                    echo '<form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="former'.$question[$i]["sn"].'" method="post" enctype="multipart/form-data" >      
                                                            <div class="input-group">
                                                           <span class="input-group-addon" style="background: none; border: none; font-size: 1em !important;"><i>'.$question[$i]["sn"].'</i></span>
                                                         <input class="form-control" type="hidden" name="tit" value="'.$tit.'" required="" /><input class="form-control" type="hidden" name="dee" value="'.$dee.'" required="" /><input class="form-control" type="hidden" name="tee" value="'.$tee.'" required="" /><input class="form-control" type="hidden" name="lee" value="'.$lee.'" required="" /><input class="form-control" type="hidden" name="schoolname" value="'.$_SESSION['school_name'].'" required="" /> <input type="hidden" name="sn" value="'.$question[$i]["sn"].'" />
                                                           <textarea class="form-control" name="q'.$question[$i]["sn"].'" required="" style="height: 50px; resize: none; border: none; font-size: 1em !important;">'.$question[$i]["question"].'</textarea>
                                                                        </div> 
                                                                        <p style="text-align: center;">Upload Question Image(Optional): Image must be less or eqaul to 4mb and must be in either of the following format: jpg, png, jpeg.</p>
               
               <div class="input-group"  style="margin-bottom:10px;">
                                       
                                    <span class="input-group-addon"><i class="fa fa-upload"></i></span>
                                    <input type="file" accept=".jpg, .png, .jpeg" name="qimage" class="form-control" />
               </div>
                                                                        <div style="margin-bottom: 25px; text-align:left;">
                                                          
                                                           nbsp;<i style="font-size: 1em !important;">A.</i>&nbsp;<input  name="a'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["a"].'"/>
                                                           &nbsp;<i style="font-size: 1em !important;">B.</i>&nbsp;<input name="b'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["b"].'"/>
                                                            &nbsp;<i style="font-size: 1em !important;">C.</i>&nbsp;<input name="c'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["c"].'"/>
                                                            &nbsp;<i style="font-size: 1em !important;">D.</i>&nbsp;<input name="d'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["d"].'"/> 
                                                                &nbsp;<i style="font-size: 1em !important;">E.</i>&nbsp;<input name="e'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["e"].'"/> 
                                                                
                                                               &nbsp;<i style="font-size: 1em !important;">Ans.</i>&nbsp;<input name="ans'.$question[$i]["sn"].'" style="width: 70px; font-weight: bold; height: 40px;" type="" value="'.$question[$i]["answer"].'"/>
</div>                                                         <button type="submit" class="btn btn-primary" name="update" onclick = "updateQ(\''.$question[$i]["sn"].'\');">Update Question '.$question[$i]["sn"].'</button>
                                                                        </form>
            ';
                }
            }
        
        
        
        
        
        
         echo '
        
</div>
    </div>
    <script>
    $(".fortune_modal").slideDown(2000);
    </script> ';
       
    }
    
    ?>
    
    
    
<div class="container">
    <div class="row">
        <div class="col-sm-5">
            
            
            <div class="alert alert-success" id="successAlert">
                <strong>Success!</strong><span id="sat"></span>
</div>
            <div class="alert alert-danger" id="errorAlert">
                <strong>Error!</strong><span id="eat"></span>
</div>
            <div class="card" style="text-align: center;">
                <div class="card-header">Upload exam CSV questions</div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="loadquestions" name="questionloader" method="post" enctype="multipart/form-data"> 
                        
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-group"></i></span>
                                                   <select class="form-control" onchange="setType(this.value);" id="department" name="department" required="">
                                                       <option value="" selected="">SELECT DEPARTMENT</option>
                                                       <?php
                                                       $username = $_SESSION['username'];
                                                       $schoolname = preg_replace('/\s+/', '_', $_SESSION["school_name"]);
                                                        $stafdep = new config($schoolname);
                                                        $stafdep = $stafdep->execute_return("SELECT department FROM staffs WHERE email = '$username'");
                                                       
                                                        $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($stafdep); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($stafdep[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$stafdep[$i]["department"].'">'.$stafdep[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $stafdep[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
                                                       
                                                       ?>
                                                   </select>
                                                                        </div>
               
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setLevel(this.value);" class="form-control" id="type" name="type" required="">
                                                       <option value="" selected="">SELECT TYPE</option>
                                                   </select> </div>
            
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setTitle(this.value);" class="form-control" id="level" name="level" required="">
                                                       <option value="" selected="">SELECT LEVEL</option>
                                                   </select></div>
                        <div id="subjecttitler"></div>
                                                        
                         <div id="loader"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success" id="cema" type="submit" name="loadQ" onclick="loadingQ();" value="Load Questions" style="margin-bottom: 5px;"/> 
                        
                </div>
                                                            
                                                            </form>
            <br>
           
</div>
                </div>
      
        <div class="col-sm-7">
          
            
            <div class="alert alert-success" id="successAlert3">
                <strong>Success!</strong><span id="sat3"></span>
</div>
            <div class="alert alert-danger" id="errorAlert3">
                <strong>Error!</strong><span id="eat3"></span>
</div>
            <div class="card" style="text-align: center;">
                <div class="card-header">Add question</div>
                <div class="card-body">
                    
                    
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="loadquestions1" name="questionloader1" method="post" enctype="multipart/form-data"> 
                        
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-group"></i></span>
                                                   <select class="form-control" onchange="setType1(this.value);" id="department1" name="department1" required="">
                                                       <option value="" selected="">SELECT DEPARTMENT</option>
                                                       <?php
                                                       $username = $_SESSION['username'];
                                                       $schoolname = preg_replace('/\s+/', '_', $_SESSION["school_name"]);
                                                        $stafdep = new config($schoolname);
                                                        $stafdep = $stafdep->execute_return("SELECT department FROM staffs WHERE email = '$username'");
                                                       
                                                        $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($stafdep); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($stafdep[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$stafdep[$i]["department"].'">'.$stafdep[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $stafdep[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
                                                       
                                                       ?>
                                                   </select>
                                                                        </div>
               
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setLevel1(this.value);" class="form-control" id="type1" name="type1" required="">
                                                       <option value="" selected="">SELECT TYPE</option>
                                                   </select> </div>
            
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setTitle1(this.value);" class="form-control" id="level1" name="level1" required="">
                                                       <option value="" selected="">SELECT LEVEL</option>
                                                   </select></div>
                        <div id="subjecttitler1"></div>
                                                        
                         <div id="loader1"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success" id="cema1" type="submit" name="loadQ1" onclick="loadingQ1();" value="Add Question" style="margin-bottom: 5px;"/> 
                        
                </div>
                                                            
                                                            </form>
                    
                </div>
            </div>
        
            
            
            
            
            
        </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="card" style="text-align: center;">
                <div class="card-header">Exams Loaded</div>
                <div class="card-body">
                   <div class="table-responsive" style="max-height: 500px; background: #ffffff; color: #000000;">
            <table class="table" style="font-size: 14px !important;">
    <thead>
      <tr>
          <th style="text-align:center;">#</th>
          <th style="text-align:center;">Title</th>
        <th style="text-align:center;">Question Loaded</th>
        <th style="text-align:center;">Question Remaining</th>
        <th style="text-align:center;">Edit</th>
      </tr>
    </thead>
    <tbody id="tablebofy">
     <?php
     $staff = $_SESSION['username'];
     $gets = new config($schoolname);
     $gets = $gets->execute_return("SELECT department, type, level FROM staffs WHERE email ='$staff'");
     $staffdep = $gets[0]['department'];
     $stafftype = $gets[0]['type'];
     $stafflevel = $gets[0]['level'];
     //get * details of loaded titles
     $getd = new config($schoolname);
     $getd = $getd->execute_return("SELECT title, department, type, level FROM pquestions WHERE department = '$staffdep' AND type = '$stafftype' AND level = '$stafflevel'");
    
    if(count($getd) > 0)
    {
         $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getd); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getd[$i]["title"] == $padded1[$j]['title'])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $padded1[$acount1] = $getd[$i];
                                                               $acount1++;
                                                               
                                                           }
                                      for($a=0; $a<count($padded1); $a++)
                                      {
                                          $loaded = 0;
                                          $total = 0;
                                          $remaining = 0;
                                          $title = $padded1[$a]['title'];
                                          $depart = $padded1[$a]['department'];
                                          $ty = $padded1[$a]['type'];
                                          $le = $padded1[$a]['level'];
                                          
                                          for($b=0; $b<count($padded1[$a]); $b++)
                                          {
                                              //get questions uploaded, and remainings
                                              $getRemains = new config($schoolname);
     $getRemains = $getRemains->execute_count_return("SELECT COUNT(*) FROM pquestions WHERE title = '$title' AND department = '$depart' AND type = '$ty' AND level = '$le'");
     $loaded = (int)$getRemains;
     
     //get question no;
      $getqno = new config($schoolname);
     $getqno = $getqno->execute_return("SELECT questions FROM exam WHERE title = '$title' AND department = '$depart' AND type = '$ty' AND level = '$le'");
     $total = (int)$getqno[0]['questions'];
     $remaining = $total - $loaded;
     
                                          }
                                          
                                          echo '<tr><td style="text-align: center;">'.($a + 1).'</td><td style="text-align: center;">'.$title.'</td><td style="text-align: center;">'.$loaded.'</td><td style="text-align: center;">'.$remaining.'</td><td><a class="btn btn-primary" href="'. htmlspecialchars($_SERVER["PHP_SELF"]).'?title='. base64_encode($title).'&dep='. base64_encode($depart).'&type='. base64_encode($ty).'&level='. base64_encode($le).'">Edit</a></td></tr>';
                                      }
    }
    else
    {
        echo '<tr><td colspan="5" style="text-align: center;">You have not uploaded any questions yet.</td></tr>';
    }
     ?>
    </tbody>
  </table>
            </div>
                    </div>
                </div>
        </div>
                
    </div>
</div>

<script>
    function updateQ(e)
    {
        $('#former'+e).ajaxForm({
      beforeSubmit: function() {
          
      },
      
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
          if(myResp == "success")
          {
              document.getElementById("sat2").innerHTML = " Successfully updated, refreshing page in 5seconds.";
              document.getElementById("errorAlert2").style.display = "none";
      document.getElementById("successAlert2").style.display = "block";
      window.setInterval(function(){window.location.reload();},5000);
          }
          else if(myResp == "imager")
               {
              document.getElementById("eat2").innerHTML = " File is not of proper image format.";
              document.getElementById("errorAlert2").style.display = "block";
      document.getElementById("successAlert2").style.display = "none";
          }
          else if(myResp == "size")
               {
              document.getElementById("eat2").innerHTML = " Image size is greater than 4mb.";
              document.getElementById("errorAlert2").style.display = "block";
      document.getElementById("successAlert2").style.display = "none";
          }
           
          else
          {
              document.getElementById("eat2").innerHTML = " Oops, please refresh the page and try again.";
              document.getElementById("errorAlert2").style.display = "block";
      document.getElementById("successAlert2").style.display = "none";
          }
      }
      });
      
    }
     function loadingQ1()
    {
        $('#loadquestions1').ajaxForm({
      beforeSubmit: function() {
          document.getElementById("errorAlert3").style.display = "none";
          document.getElementById("successAlert3").style.display = "none";
          document.getElementById("loader1").style.display = "block";
          document.getElementById("cema1").style.display = "none";
          
      },
      
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
          if(myResp == "sn")
          {
              document.getElementById("eat3").innerHTML = " Serial number is not valid based on exam settings.";
              document.getElementById("errorAlert3").style.display = "block";
          document.getElementById("successAlert3").style.display = "none";
          document.getElementById("loader1").style.display = "none";
          document.getElementById("cema1").style.display = "block";
          }
          else if(myResp == "exist")
          {
              document.getElementById("eat3").innerHTML = " Question with such serial number already exist. To override use the override checkbox.";
              document.getElementById("errorAlert3").style.display = "block";
          document.getElementById("successAlert3").style.display = "none";
          document.getElementById("loader1").style.display = "none";
          document.getElementById("cema1").style.display = "block";
          }
          else if(myResp == "imager")
          {
              document.getElementById("eat3").innerHTML = " File is not of proper image format.";
              document.getElementById("errorAlert3").style.display = "block";
          document.getElementById("successAlert3").style.display = "none";
          document.getElementById("loader1").style.display = "none";
          document.getElementById("cema1").style.display = "block";
          }
          else if(myResp == "size")
          {
              document.getElementById("eat3").innerHTML = " Image file is greater than 4mb";
              document.getElementById("errorAlert3").style.display = "block";
          document.getElementById("successAlert3").style.display = "none";
          document.getElementById("loader1").style.display = "none";
          document.getElementById("cema1").style.display = "block";
          }
          else if(myResp == "oupdate")
          {
              document.getElementById("sat3").innerHTML = " Question successfully updated, refreshing page in 5 seconds";
              document.getElementById("errorAlert3").style.display = "none";
          document.getElementById("successAlert3").style.display = "block";
          document.getElementById("loader1").style.display = "none";
          document.getElementById("cema1").style.display = "block";
          window.setInterval(function(){window.location.reload();},5000);
          }
          else if(myResp == "osuccess")
          {
              document.getElementById("sat3").innerHTML = " New Question successfully Added, refreshing page in 5 seconds";
              document.getElementById("errorAlert3").style.display = "none";
          document.getElementById("successAlert3").style.display = "block";
          document.getElementById("loader1").style.display = "none";
          document.getElementById("cema1").style.display = "block";
          window.setInterval(function(){window.location.reload();},5000);
          }
          else if(myResp == "isuccess")
          {
              document.getElementById("sat3").innerHTML = " New Question successfully Added, refreshing page in 5 seconds";
              document.getElementById("errorAlert3").style.display = "none";
          document.getElementById("successAlert3").style.display = "block";
          document.getElementById("loader1").style.display = "none";
          document.getElementById("cema1").style.display = "block";
          window.setInterval(function(){window.location.reload();},5000);
          }
          else
          {
              document.getElementById("eat3").innerHTML = " Oops something went wrong, please refresh the page and try again.";
              document.getElementById("errorAlert3").style.display = "block";
          document.getElementById("successAlert3").style.display = "none";
          document.getElementById("loader1").style.display = "none";
          document.getElementById("cema1").style.display = "block";
          }
      }
      });
      
    }
    function loadingQ()
    {
       
        var bar = $('#bar');
    var percent = $('#percent');
    
    $('#loadquestions').ajaxForm({
      beforeSubmit: function() {
           document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "none";
        document.getElementById("cema").style.display = "none";
        document.getElementById("progress_div").style.display="block";
        var percentVal = '0%';
        bar.width(percentVal);
        percent.html(percentVal);
      },
      uploadProgress: function(event, position, total, percentComplete) {
        var percentVal = percentComplete + '%';
        bar.width(percentVal);
        percent.html(percentVal);
      },
      success: function() {
        var percentVal = '100%';
        bar.width(percentVal);
        percent.html(percentVal);
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
          if(myResp == "empty")
          {
              document.getElementById("eat").innerHTML = " No field must must be blank, please browse the website properly.";
              percentVal = '0%';
               document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
        document.getElementById("cema").style.display = "block";
        document.getElementById("progress_div").style.display="none";
          }
          else if(myResp == "invalidf")
          {
              document.getElementById("eat").innerHTML = " File is not in CSV format.";
              percentVal = '0%';
               document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
        document.getElementById("cema").style.display = "block";
        document.getElementById("progress_div").style.display="none";
          }
          else if(myResp == "invalidquestion")
          {
              document.getElementById("eat").innerHTML = " Invalid number of questions, please check your CSV file.";
              percentVal = '0%';
               document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
        document.getElementById("cema").style.display = "block";
        document.getElementById("progress_div").style.display="none";
          }
          else if(myResp == "invalidanswers")
          {
              document.getElementById("eat").innerHTML = " A field in your CSV contains invalid number of answer, please check your CSV file.";
              percentVal = '0%';
               document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
        document.getElementById("cema").style.display = "block";
        document.getElementById("progress_div").style.display="none";
          }
          else if(myResp == "equalsn")
          {
              document.getElementById("eat").innerHTML = " More than one field have the same Serial Number, please check your CSV file.";
              percentVal = '0%';
               document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
        document.getElementById("cema").style.display = "block";
        document.getElementById("progress_div").style.display="none";
          }
          else if(myResp == "override_error")
          {
              document.getElementById("eat").innerHTML = " Invalid number of questions to insert after override, please check your CSV file.";
              percentVal = '0%';
               document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
        document.getElementById("cema").style.display = "block";
        document.getElementById("progress_div").style.display="none";
          }
          else if(myResp == "updatesuccess")
          {
              document.getElementById("sat").innerHTML = " Exam questions updated successfully, refreshing page in 5 seconds.";
              percentVal = '0%';
               document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "block";
        document.getElementById("cema").style.display = "block";
        document.getElementById("progress_div").style.display="none";
        window.setInterval(function(){window.location.reload();},5000);
          }
          else if(myResp == "insuccess")
          {
              document.getElementById("sat").innerHTML = " Exam questions uploaded successfully, refreshing page in 5 seconds.";
              percentVal = '0%';
               document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "block";
        document.getElementById("cema").style.display = "block";
        document.getElementById("progress_div").style.display="none";
        window.setInterval(function(){window.location.reload();},5000);
          }
          else if(myResp == "emptyf")
          {
              document.getElementById("eat").innerHTML = " Your CSV file is empty, Please check your CSV file.";
              percentVal = '0%';
               document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
        document.getElementById("cema").style.display = "block";
        document.getElementById("progress_div").style.display="none";
          }
          else
          {
              document.getElementById("eat").innerHTML = " Oops, an error occurred, please refresh the page and try again.";
              percentVal = '0%';
               document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
        document.getElementById("cema").style.display = "block";
        document.getElementById("progress_div").style.display="none";
          }
          
      }
      }); 
    }
    function setType(e)
    {
        document.getElementById("type").value = "";
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getexami1.php",
        type: "post",
        data: "data=type"+"&department="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("type").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("type").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel(e)
    {
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getexami1.php",
        type: "post",
        data: "data=level"+"&type="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("level").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("level").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    function setTitle(e)
    {
      
         $.ajax({
        url: "../ajax_to_php_connectors/getexami1.php",
        type: "post",
        data: "data=exams"+"&level="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("subjecttitler").innerHTML = myResp;
          

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
     function setType1(e)
    {
        document.getElementById("type1").value = "";
        document.getElementById("level1").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/gexami1.php",
        type: "post",
        data: "data=type"+"&department="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("type1").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("type1").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel1(e)
    {
        document.getElementById("level1").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/gexami1.php",
        type: "post",
        data: "data=level"+"&type="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("level1").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("level1").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    function setTitle1(e)
    {
      
         $.ajax({
        url: "../ajax_to_php_connectors/gexami1.php",
        type: "post",
        data: "data=exams"+"&level="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("subjecttitler1").innerHTML = myResp;
          

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
     function setRemains(e)
    {
       
         $.ajax({
       url: "../ajax_to_php_connectors/getexami1.php",
        type: "post",
        data: "data=remains"+"&title="+e,
       success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("drem").innerHTML = myResp;
          

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    function setRemains1(e)
    {
       
         $.ajax({
       url: "../ajax_to_php_connectors/gexami1.php",
        type: "post",
        data: "data=remains"+"&title="+e,
       success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("drem1").innerHTML = myResp;
          

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
</script>
<?php require_once 'footer.php'; ?>