<?php 
$title = "New Exam";
$active1 = "";
$active2 = "activer";
$active3 = "";
$active4 = "";
$active5 = "";
$active6 = "";
$active7 = "";
$active8 = "";
$active9 = "";
if(isset($_POST['createdexam']))
{
    
    require_once '../classes/config.php';
    $examtitle = strtoupper($_POST['subjecttitle']);
    $examcode = strtoupper($_POST['subjectcode']);
    $questionno = (int)$_POST['numberofquesion'];
    $answerno = (int)$_POST['numberofanswer'];
    $score = (int)$_POST['score'];
    $examtime = (int)$_POST['examtime'];
    $examhour = $_POST['examhour'];
    if($examhour == null || $examhour == "")
    {
        $examhour = 0;
    }
    if($examhour < 0)
    {
        $examhour = 0;
    }
    $examinstruction = $_POST['examinstuction'];
    $department = $_POST['department'];
    $type = $_POST['type'];
    $level = $_POST['level'];
    $schoolname = preg_replace('/\s+/', '_', $_POST['schoolname1']);
    
if($examtitle == "" || $score =="" || $examcode == "" || $examhour < 0 || $questionno < 1 || $questionno > 100 || $answerno == 0 || $answerno < 2 || $examtime < 5 || $examtime > 240 || $examtime == 0 || $examinstruction == "" || $schoolname == "")
{
    die("field");
}
else{
    //check if exam table exist
    $checkt = new config($schoolname);
                    $checkt = $checkt->execute_return("SHOW TABLES LIKE 'exam'");
    if($checkt == false && count($checkt) <= 0)
                    {
        //create exam table
        $createexamtable = new config($schoolname);
        $createexamtable->execute_no_return("CREATE TABLE `exam` ( `id` INT(16) NOT NULL AUTO_INCREMENT , `title` VARCHAR(150) NOT NULL , `code` VARCHAR(150) NOT NULL , `questions` VARCHAR(150) NOT NULL , `answers` INT(16) NOT NULL , `score` VARCHAR(150) NOT NULL, `keymode` VARCHAR(150) NOT NULL, `strict` VARCHAR(150) NOT NULL, `time` VARCHAR(150) NOT NULL , `hour` VARCHAR(150) NOT NULL, `instruction` TEXT NOT NULL , `department` VARCHAR(150) NOT NULL , `type` VARCHAR(150) NOT NULL , `level` VARCHAR(150) NOT NULL , `loaded` VARCHAR(150) NOT NULL , `doc` DATE NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;");
        
    }
    
    //check if exam already exist
    $examexisr = new config($schoolname);
    $examexisr = $examexisr->execute_count_no_return("SELECT COUNT(*) FROM exam WHERE title = '$examtitle' AND department = '$department' AND type='$type' AND level='$level'");
    if($examexisr == 1)
    {
        die("exist");
    }
    else
    {
         //Save new exam;
        $saveexam = new config($schoolname);
        if(isset($_POST['strict']))
        {
           
             $saveexam->execute_no_return("INSERT INTO `exam`(`title`, `code`, `questions`, `answers`,keymode, `strict`, `score`, `time`, `hour`, `instruction`, `department`, `type`, `level`, `loaded`, `doc`) VALUES ('$examtitle','$examcode','$questionno','$answerno','false', 'true', '$score', '$examtime', '$examhour', '$examinstruction','$department', '$type', '$level', 'false', now())");
        }
        else
        {
            
             $saveexam->execute_no_return("INSERT INTO `exam`(`title`, `code`, `questions`, `answers`,keymode, `strict`, `score`, `time`, `hour`, `instruction`, `department`, `type`, `level`, `loaded`, `doc`) VALUES ('$examtitle','$examcode','$questionno','$answerno','false',  'false', '$score', '$examtime', '$examhour', '$examinstruction','$department', '$type', '$level', 'false', now())");
        }
       
       $ukey = new config($schoolname);
       if(isset($_POST['keymode']))
       {
           $ukey->execute_no_return("UPDATE exam SET keymode='true' WHERE title = '$examtitle' AND department = '$department' AND type='$type' AND level='$level'");
       }
        die("success");
    }
    
}
}
require_once 'header.php'; ?>
<style>
    #loader, #successAlert, #errorAlert
    {
        display: none;
    }
    </style>
<div class="container">
    <div class="row">
        <div class="col-sm-5">
            <div class="alert alert-success" id="successAlert">
                <strong>Success!</strong><span id="sat1"></span>
</div>
            <div class="alert alert-danger" id="errorAlert">
                <strong>Error!</strong><span id="eat1"></span>
</div>
            <div class="card" style="text-align: center;">
                <div class="card-header">Create Exam</div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="examform" name="addexam" method="post" enctype="multipart/form-data"> 
                        
                                           
                                                           
                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-header"></i></span>
                                                           <input class="form-control" type="text" id="subjecttitle" name="subjecttitle" value="" required="" placeholder="Subject Title" />
                                                                        </div>
                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-hashtag"></i></span>
                                                           <input type="text"  class="form-control" id="subjectcode" value="" name="subjectcode" required="" placeholder="Subject Code"/>
                                                           
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-question"></i></span>
                                                           <input type="number" id="numberofquesion" min="1" max="100" class="form-control" name="numberofquesion" value="" required="" placeholder="No of Questions">
                                                          
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-question-circle"></i></span>
                                                           <input type="number" id="numberofanswer" min="2" max="5" class="form-control" value="" name="numberofanswer" required="" placeholder="No of Answers">
                                                          
                                                                        </div>
                         <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-question-circle"></i></span>
                                                           <input type="number" id="score" min="1" max="100" class="form-control" value="" name="score" required="" placeholder="Score Per Question">
                                                          
                                                                        </div>
                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-lock"> Key Mode</i></span>
                                                           <input type="checkbox" id="keymode" class="form-control" name="keymode">
                                                          
                                                                        </div>
                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-key"> Strict Policy</i></span>
                                                           <input type="checkbox" id="strict" class="form-control" name="strict">
                                                          
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <input class="form-control" type="hidden" name="schoolname1" value="<?php echo $_SESSION["school_name"]; ?>" required="" />
                                                           <span class="input-group-addon"><i class="fa fa-clock"></i></span>
                                                           <input class="form-control" id="examhour" max="4" type="number" name="examhour" value="" placeholder="Exam TIme in Hour" />
                                                                        </div>
                                                             <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <input class="form-control" type="hidden" name="schoolname1" value="<?php echo $_SESSION["school_name"]; ?>" required="" />
                                                           <span class="input-group-addon"><i class="fa fa-clock"></i></span>
                                                           <input class="form-control" id="examtime" min="5" max="59" type="number" name="examtime" value="" required="" placeholder="Exam TIme in minutes" />
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-info"></i></span>
                                                   <textarea class="form-control" id="examinstuction" style="height: 100px; resize: none;" name="examinstuction" value="" required="" placeholder="Exam Instruction"></textarea>
                                                                        </div>
                       
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-group"></i></span>
                                                   <select class="form-control" onchange="setType(this.value);" id="department" name="department" required="">
                                                       <option value="" selected="">SELECT DEPARTMENT</option>
                                                       <?php
                                                       $username = $_SESSION['username'];
                                                       $schoolname = preg_replace('/\s+/', '_', $_SESSION["school_name"]);
                                                        $stafdep = new config($schoolname);
                                                        $stafdep = $stafdep->execute_return("SELECT department FROM staffs WHERE email = '$username'");
                                                       
                                                        $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($stafdep); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($stafdep[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$stafdep[$i]["department"].'">'.$stafdep[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $stafdep[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
                                                       
                                                       ?>
                                                   </select>
                                                                        </div>
               
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setLevel(this.value);" class="form-control" id="type" name="type" required="">
                                                       <option value="" selected="">SELECT TYPE</option>
                                                   </select> </div>
            
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select class="form-control" id="level" name="level" required="">
                                                       <option value="" selected="">SELECT LEVEL</option>
                                                   </select></div>
                                                        
                         <div id="loader"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success" id="cema" type="submit" name="createdexam" onclick="cexam();" value="Create" style="margin-bottom: 5px;"/> 
                        
                </div>
                                                            
                                                            </form>
            <br>
           
</div>
                </div>
        
        <div class="col-sm-7">
            <div class="card" style="text-align: center;">
                <div class="card-header">Exams</div>
                <div class="card-body">
                    <div class="table-responsive" style="max-height: 500px; background: #ffffff; color: #000000;">
            <table class="table" style="font-size: 14px !important;">
    <thead>
      <tr>
          <th style="text-align:center;">#</th>
          <th style="text-align:center;">Title</th>
        <th style="text-align:center;">Code</th>
        <th style="text-align:center;">No. of Questions</th>
        <th style="text-align:center;">No. of Answers</th>
        <th style="text-align:center;">Score per Question</th>
        <th style="text-align:center;">Key Mode</th>
        <th style="text-align:center;">Strict Policy</th>
        <th style="text-align:center;">Time(Hour)</th>
        <th style="text-align:center;">Time(minutes)</th>
        <th style="text-align:center;">Department</th>
        <th style="text-align:center;">Type</th>
        <th style="text-align:center;">Level</th>
        <th style="text-align:center;">Loaded</th>
      </tr>
    </thead>
    <tbody id="tablebofy">
      <?php
      //check if exam table exist
      $checkt = new config($schoolname);
                    $checkt = $checkt->execute_return("SHOW TABLES LIKE 'exam'");
    if($checkt == true && count($checkt) > 0)
                    {
      //check if any exam exist at all
      $counter = 0;
      $exams = new config(preg_replace('/\s+/', '_', $_SESSION["school_name"]));
      $exams = $exams->execute_return("SELECT department, type, level FROM staffs WHERE email='$username' AND root='true'");
     
          $dep = $exams[0]['department'];
          $typ = $exams[0]['type'];
          $lev = $exams[0]['level'];
          //check if exam exist for criteria
          $exami = new config(preg_replace('/\s+/', '_', $_SESSION["school_name"]));
          $exami =  $exami->execute_return("SELECT * FROM exam WHERE department = '$dep' AND type = '$typ' AND level = '$lev'");
          
          if(count($exami) > 0)
          {
             for($j=0; $j<count($exami); $j++)
             {
                  $counter++;
             if($exami[$j]['strict'] == "true" || $exami[$j]['keymode'] == "true")
             {
                 if($exami[$j]['strict'] == "true" && $exami[$j]['keymode'] == "true")
             {
                 echo '<tr><td style="text-align: center;">'.$counter.'</td><td style="text-align: center;">'.$exami[$j]["title"].'</td><td style="text-align: center;">'.$exami[$j]["code"].'</td><td style="text-align: center;">'.$exami[$j]["questions"].'</td><td style="text-align: center;">'.$exami[$j]["answers"].'</td><td style="text-align: center;">'.$exami[$j]["score"].'</td><td style="text-align: center;">ON</td><td style="text-align: center;">ON</td><td style="text-align: center;">'.$exami[$j]["hour"].'</td><td style="text-align: center;">'.$exami[$j]["time"].'</td><td style="text-align: center;">'.$exami[$j]["department"].'</td><td style="text-align: center;">'.$exami[$j]["type"].'</td><td style="text-align: center;">'.$exami[$j]["level"].'</td><td style="text-align: center;">'.$exami[$j]["loaded"].'</td></tr>';
                
             }
             else if($exami[$j]['strict'] == "true" && $exami[$j]['keymode'] == "false")
             {
                 echo '<tr><td style="text-align: center;">'.$counter.'</td><td style="text-align: center;">'.$exami[$j]["title"].'</td><td style="text-align: center;">'.$exami[$j]["code"].'</td><td style="text-align: center;">'.$exami[$j]["questions"].'</td><td style="text-align: center;">'.$exami[$j]["answers"].'</td><td style="text-align: center;">'.$exami[$j]["score"].'</td><td style="text-align: center;">OFF</td><td style="text-align: center;">ON</td><td style="text-align: center;">'.$exami[$j]["hour"].'</td><td style="text-align: center;">'.$exami[$j]["time"].'</td><td style="text-align: center;">'.$exami[$j]["department"].'</td><td style="text-align: center;">'.$exami[$j]["type"].'</td><td style="text-align: center;">'.$exami[$j]["level"].'</td><td style="text-align: center;">'.$exami[$j]["loaded"].'</td></tr>';
            
             }
             else
             {
                  echo '<tr><td style="text-align: center;">'.$counter.'</td><td style="text-align: center;">'.$exami[$j]["title"].'</td><td style="text-align: center;">'.$exami[$j]["code"].'</td><td style="text-align: center;">'.$exami[$j]["questions"].'</td><td style="text-align: center;">'.$exami[$j]["answers"].'</td><td style="text-align: center;">'.$exami[$j]["score"].'</td><td style="text-align: center;">ON</td><td style="text-align: center;">OFF</td><td style="text-align: center;">'.$exami[$j]["hour"].'</td><td style="text-align: center;">'.$exami[$j]["time"].'</td><td style="text-align: center;">'.$exami[$j]["department"].'</td><td style="text-align: center;">'.$exami[$j]["type"].'</td><td style="text-align: center;">'.$exami[$j]["level"].'</td><td style="text-align: center;">'.$exami[$j]["loaded"].'</td></tr>';
            
             }
                   }
             else
             {
                 echo '<tr><td style="text-align: center;">'.$counter.'</td><td style="text-align: center;">'.$exami[$j]["title"].'</td><td style="text-align: center;">'.$exami[$j]["code"].'</td><td style="text-align: center;">'.$exami[$j]["questions"].'</td><td style="text-align: center;">'.$exami[$j]["answers"].'</td><td style="text-align: center;">'.$exami[$j]["score"].'</td><td style="text-align: center;">OFF</td><td style="text-align: center;">OFF</td><td style="text-align: center;">'.$exami[$j]["hour"].'</td><td style="text-align: center;">'.$exami[$j]["time"].'</td><td style="text-align: center;">'.$exami[$j]["department"].'</td><td style="text-align: center;">'.$exami[$j]["type"].'</td><td style="text-align: center;">'.$exami[$j]["level"].'</td><td style="text-align: center;">'.$exami[$j]["loaded"].'</td></tr>';
             }
             }
              
          }
          else{
               echo '<tr><td colspan="12" style="text-align: center;">No exam created yet.</td></tr>';
          }
          
      
      
      
      
                    }
                    else
                    {
                        echo '<tr><td colspan="12" style="text-align: center;">No exam created yet.</td></tr>';
                    }
      ?>
    </tbody>
  </table>
            </div>
                </div>
                </div>
        </div>
    </div>
</div>
<script>
    function cexam() 
  {
      
    $('#examform').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "none";
      document.getElementById("cema").style.display = "none";
      document.getElementById("loader").style.display = "block";
      
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
        if(myResp == "field")
        {
            document.getElementById("errorAlert").innerHTML = " All field must be filled.";
            document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
      document.getElementById("cema").style.display = "inline";
      document.getElementById("loader").style.display = "none";
      document.getElementById("subjecttitle").value = "";
      document.getElementById("subjectcode").value = "";
      document.getElementById("numberofquesion").value = "";
      document.getElementById("numberofanswer").value = "";
      document.getElementById("examtime").value = "";
      document.getElementById("examinstuction").value = "";
        }
        else if(myResp == "exist")
        {
            document.getElementById("errorAlert").innerHTML = " Subject title already exist.";
            document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
      document.getElementById("cema").style.display = "inline";
      document.getElementById("loader").style.display = "none";
      document.getElementById("subjecttitle").focus();
        }
        else if(myResp == "success")
        {
            document.getElementById("successAlert").innerHTML = " Subject successfully added, refresshing page in 5 seconds.";
            document.getElementById("successAlert").style.display = "block";
      document.getElementById("errorAlert").style.display = "none";
      document.getElementById("cema").style.display = "inline";
      document.getElementById("loader").style.display = "none";
      document.getElementById("subjecttitle").value = "";
      document.getElementById("subjectcode").value = "";
      document.getElementById("numberofquesion").value = "";
      document.getElementById("numberofanswer").value = "";
      document.getElementById("examtime").value = "";
      document.getElementById("examinstuction").value = "";
      window.setInterval(function(){window.window.location.reload();},5000);
        }
        else
        {
            document.getElementById("errorAlert").innerHTML = " Error occured, please refresh this page.";
            document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
      document.getElementById("cema").style.display = "inline";
      document.getElementById("loader").style.display = "none";
      document.getElementById("subjecttitle").value = "";
      document.getElementById("subjectcode").value = "";
      document.getElementById("numberofquesion").value = "";
      document.getElementById("numberofanswer").value = "";
      document.getElementById("examtime").value = "";
      document.getElementById("examinstuction").value = "";
        }
      }
    }); 
  }
  
  function setType(e)
    {
        document.getElementById("type").value = "";
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getdstaffdetails.php",
        type: "post",
        data: "data=type"+"&department="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("type").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("type").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel(e)
    {
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getdstaffdetails.php",
        type: "post",
        data: "data=level"+"&type="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("level").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("level").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    
</script>
<?php require_once 'footer.php'; ?>