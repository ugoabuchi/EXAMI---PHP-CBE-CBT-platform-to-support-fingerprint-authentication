<?php 
$title = "Dashboard";
$active1 = "activer";
$active2 = "";
$active3 = "";
$active4 = "";
$active5 = "";
$active6 = "";
$active7 = "";
$active8 = "";
$active9 = "";
require_once 'header.php'; ?>
                     
<?php require_once 'footer.php'; ?>