<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//Check if user is logged in
session_start();
 if(isset($_SESSION['depppp']))
                                                           {
                                                               unset($_SESSION['depppp']);
                                                               
                                                               
                                                           }
                                                           if(isset($_SESSION['tyyyyp']))
                                                               {
                                                                   unset($_SESSION['tyyyyp']);
                                                                   
                                                                   
                                                               }
                                                               if(isset($_SESSION['levvv']))
                                                           {
                                                               unset($_SESSION['levvv']);
                                                               
                                                               
                                                           }
                                                               
                                                                if(isset($_SESSION['titling']))
                      {
                          unset($_SESSION['titling']);
                      }
include_once '../classes/config.php';
    if(isset($_SESSION['sessionid']) && isset($_SESSION['username']) && isset($_SESSION['school_name']))
    {
        $username = $_SESSION['username'];
        $session_val = $_SESSION['sessionid'];
        //check if session exist in database
        $cSession = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $cSession = $cSession->execute_return("SELECT * FROM `sessioner` WHERE username = '$username' AND sessioner_val = '$session_val'");
        if(count($cSession) > 0)
        {
            date_default_timezone_set("Africa/Lagos");
            $datedb = $cSession[0]['dos'];
            $dateR = date_create($datedb);
            $cDate = date_create(date("Y-m-d"));
            $diff=date_diff($cDate,$dateR);
            $dcount =  (int)$diff->format("%a");
            if($dcount != 0)
            {
                
                //delete previous session value
            $delsession = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
            $delsession->execute_no_return("DELETE FROM sessioner WHERE username = '$username'");
            session_unset();
            session_destroy();
            header("location: ../");
            }
            
        }
        else
        {
            session_unset();
            session_destroy();
            header("location: ../");
        }
    }
    else
    {
         session_unset();
     session_destroy();
     header("location: ../");
    }
    //check if session username is of staff
    $duse = $_SESSION['username'];
    $checkduse = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
    $checkduse = $checkduse->execute_count_no_return("SELECT COUNT(*) FROM staffs WHERE email = '$duse' AND root='true'");
    if($checkduse != 1)
    {
        session_unset();
     session_destroy();
     header("location: ../");
    }
    //Check if user image is set in database
    $username = $_SESSION['username'];
    $useim = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
    $useim = $useim->execute_return("SELECT * FROM staffs WHERE email = '$username' AND root='true'");
    if($useim[0]['image'] == "" || $useim[0]['image'] == null)
    {
        header("location: updatestaffim.php");
    }
    
    ?>

<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from colorlib.com/polygon/cooladmin/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 17 Sep 2018 18:55:58 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <title>Exami - <?php echo $title; ?></title>
        <link rel="shortcut icon" type="img/png" href="../img/icon-196x1961.png">
        <link rel="shortcut icon" sizes="196x196" href="../img/icon-196x1961.png">
        <link rel="apple-touch-icon" href="../img/icon-196x1961.png">

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet">
    <link href="vendor/slick/slick.css" rel="stylesheet">
    <link href="vendor/select2/select2.min.css" rel="stylesheet">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet">
    
      
  
  <script src="../ckeditor/ckeditor.js"></script>
	<script src="../ckeditor/samples/js/sample.js"></script>
        <link rel="stylesheet" href="../ckeditor/samples/css/samples.css">
	<link rel="stylesheet" href="../ckeditor/samples/toolbarconfigurator/lib/codemirror/neo.css">
<script src="vendor/jquery-3.2.1.min.js"></script>
<script src="vendor/dt.js"></script>
<script src="vendor/dp.js"></script>
<script src="vendor/bf.js"></script>
<script src="vendor/jzip.js"></script>
<script src="vendor/pdfmaker.js"></script>
<script src="vendor/vfonts.js"></script>
<script src="vendor/btn5.js"></script>
<script src="vendor/btnprint.js"></script>


     <script type="text/javascript" src="vendor/jquery.form.js"></script>
</head>
<style>
    .activer
    {
        font-weight: bold;
    }
    </style>
<body>
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.php">
                            <img src="../img/exlogo.png" alt="EXAMI" style="height: 80px; width: 100px;" /><span style="color: #0062cc; font-weight: bold;">Exami</span>
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                       <li class="<?php echo $active1 ?>">
                            <a href="../staffs/">
                                <i class="fas fa-tachometer-alt fa-1x"></i>Dashboard</a>
                        </li>
                        <li class="<?php echo $active2 ?>">
                                    <a href="createexam.php"><i class="fas fa-bookmark fa-1x"></i>Create Exam</a>
                                </li>
                        <li class="<?php echo $active3 ?>">
                                    <a href="editexam.php"><i class="fas fa-book fa-1x"></i>Edit Exam</a>
                                </li>
                        <li class="<?php echo $active4 ?>">
                                    <a href="loadexamquestion.php"><i class="fas fa-pencil-alt fa-1x"></i>Load Exam questions</a>
                                </li>
                                <li class="<?php echo $active5 ?>">
                                    <a href="loadpracticequestion.php"><i class="fas fa-pencil-alt fa-1x"></i>Load Practice questions</a>
                                </li>
                        <li class="<?php echo $active6 ?>">
                                    <a href="scheduleexam.php"><i class="fas fa-eye fa-1x"></i>Schedule Exam</a>
                                </li>
                                
                                <li class="<?php echo $active7 ?>">
                                    <a href="resetstudent.php"><i class="fas fa-print fa-1x"></i>Reset Student Time</a>
                                </li>
                                <li class="<?php echo $active8 ?>">
                                    <a href="printresult.php"><i class="fas fa-save fa-1x"></i>Print Result</a>
                                </li>
                                <li class="<?php echo $active9 ?>">
                                    <a href="examkey.php"><i class="fas fa-key fa-1x"></i>Exam Key</a>
                                </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="../staffs/">
                    <img src="../img/exlogo.png" alt="EXAMI" style="height: 80px; width: 100px;" /><span style="color: #0062cc; font-weight: bold;">Exami</span>
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="<?php echo $active1 ?>">
                            <a href="../staffs/">
                                <i class="fas fa-tachometer-alt fa-1x"></i>Dashboard</a>
                        </li>
                        <li class="<?php echo $active2 ?>">
                                    <a href="createexam.php"><i class="fas fa-bookmark fa-1x"></i>Create Exam</a>
                                </li>
                        <li class="<?php echo $active3 ?>">
                                    <a href="editexam.php"><i class="fas fa-book fa-1x"></i>Edit Exam</a>
                                </li>
                        <li class="<?php echo $active4 ?>">
                                    <a href="loadexamquestion.php"><i class="fas fa-pencil-alt fa-1x"></i>Load Exam questions</a>
                                </li>
                               <li class="<?php echo $active5 ?>">
                                    <a href="loadpracticequestion.php"><i class="fas fa-pencil-alt fa-1x"></i>Load Practice questions</a>
                                </li>
                        <li class="<?php echo $active6 ?>">
                                    <a href="scheduleexam.php"><i class="fas fa-eye fa-1x"></i>Schedule Exam</a>
                                </li>
                                
                                <li class="<?php echo $active7 ?>">
                                    <a href="resetstudent.php"><i class="fas fa-print fa-1x"></i>Reset Student Time</a>
                                </li>
                                <li class="<?php echo $active8 ?>">
                                    <a href="printresult.php"><i class="fas fa-save fa-1x"></i>Print Result</a>
                                </li>
                                <li class="<?php echo $active9 ?>">
                                    <a href="examkey.php"><i class="fas fa-key fa-1x"></i>Exam Key</a>
                                </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop" style="z-index: 3;">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="#" method="POST">
                                <input class="au-input au-input--xl" type="text" name="search" placeholder="Search for datas &amp; reports..." />
                                <button class="au-btn--submit" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                </button>
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-comment-more"></i>
                                        <span class="quantity">1</span>
                                        <div class="mess-dropdown js-dropdown">
                                            <div class="mess__title">
                                                <p>You have 2 news message</p>
                                            </div>
                                            <div class="mess__item">
                                                <div class="image img-cir img-40">
                                                    <img src="images/icon/avatar-06.jpg" alt="Michelle Moreno" />
                                                </div>
                                                <div class="content">
                                                    <h6>Michelle Moreno</h6>
                                                    <p>Have sent a photo</p>
                                                    <span class="time">3 min ago</span>
                                                </div>
                                            </div>
                                            <div class="mess__item">
                                                <div class="image img-cir img-40">
                                                    <img src="images/icon/avatar-04.jpg" alt="Diane Myers" />
                                                </div>
                                                <div class="content">
                                                    <h6>Diane Myers</h6>
                                                    <p>You are now connected on message</p>
                                                    <span class="time">Yesterday</span>
                                                </div>
                                            </div>
                                            <div class="mess__footer">
                                                <a href="#">View all messages</a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="<?php echo preg_replace('/\s+/', '_', $_SESSION['school_name'])."/".$_SESSION['username']."-".$useim[0]['image'].".png" ?>" alt="<?php echo $_SESSION['username']; ?>" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#"><?php echo $_SESSION['username']; ?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="<?php echo preg_replace('/\s+/', '_', $_SESSION['school_name'])."/".$_SESSION['username']."-".$useim[0]['image'].".png" ?>" alt="<?php echo $_SESSION['username']; ?>" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#"><?php echo $useim[0]['surname']." ".$useim[0]['othernames']; ?></a>
                                                    </h5>
                                                    <span class="email">[<?php echo $useim[0]['email']; ?>]</span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Account</a>
                                                </div>
                                                
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">