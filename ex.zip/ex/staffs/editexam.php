<?php 
$title = "Edit Exam";
$active1 = "";
$active2 = "";
$active3 = "activer";
$active4 = "";
$active5 = "";
$active6 = "";
$active7 = "";
$active8 = "";
$active9 = "";
$listofexam = "";
if(isset($_POST['editcreatedexam']))
{
    session_start();
    require_once '../classes/config.php';
    $schoolname = preg_replace('/\s+/', '_',$_POST['schoolname1']);
    //check if any field is empty
    if($_POST['subjecttitle'] == "" || $_POST['subjectcode'] == "" || $_POST['score'] == "" || $_POST['numberofquesion'] == "" || $_POST['numberofanswer'] == "" || $_POST['examtime'] == "" || $_POST['examhour'] == "" || $_POST['examinstuction'] == "" || $_POST['departmentv'] == "" || $_POST['typev'] == "" || $_POST['levelv'] == "")
    {
        die("empty");
    }
    else
    {
        $otitle = $_SESSION['titling'];
        $title = strtoupper($_POST['subjecttitle']);
        $code = strtoupper($_POST['subjectcode']);
        $questionno = $_POST['numberofquesion'];
        $answerno = $_POST['numberofanswer'];
        $score = $_POST['score'];
        $examtime = $_POST['examtime'];
        $examhour = $_POST['examhour'];
        $examinstruction = $_POST['examinstuction'];
        $department = strtoupper($_POST['departmentv']);
        $type = strtoupper($_POST['typev']);
        $level = strtoupper($_POST['levelv']);
        
        //check if title is changed
        if($otitle != $title)
        {
            //check if title exist
            $checktitle = new config($schoolname);
            $checktitle = $checktitle->execute_count_no_return("SELECT COUNT(*) FROM exam WHERE title = '$title' AND department = '$department' AND type = '$type' AND level = '$level'");
        
            if($checktitle == 1)
            {
                die("exist");
            }
        }
        //check if it is loaded
        $loaded = new config($schoolname);
        $loaded = $loaded->execute_return("SELECT loaded FROM exam WHERE title = '$otitle' AND department = '$department' AND type = '$type' AND level = '$level'");
        if($loaded[0]['loaded'] == "true")
        {
            die("loaded");
        }
        //udpdate exam details
        $updateexam = new config($schoolname);
        if(isset($_POST['strict']) || isset($_POST['keymode']))
        {
            if(isset($_POST['strict']) && isset($_POST['keymode']))
            {
                $updateexam->execute_no_return("UPDATE `exam` SET `title`='$title',`code`='$code',`questions`='$questionno',`answers`='$answerno', score='$score', `keymode`='true', `strict`='true',`time`='$examtime', `hour`='$examhour',`instruction`='$examinstruction' WHERE title='$otitle' AND department = '$department' AND type = '$type' AND level = '$level'");
       
            }
            else if(isset($_POST['strict']) && !isset($_POST['keymode']))
            {
                $updateexam->execute_no_return("UPDATE `exam` SET `title`='$title',`code`='$code',`questions`='$questionno',`answers`='$answerno', score='$score', `keymode`='false', `strict`='true',`time`='$examtime', `hour`='$examhour',`instruction`='$examinstruction' WHERE title='$otitle' AND department = '$department' AND type = '$type' AND level = '$level'");
       
            }
            else
            {
                 $updateexam->execute_no_return("UPDATE `exam` SET `title`='$title',`code`='$code',`questions`='$questionno',`answers`='$answerno', score='$score', `keymode`='true', `strict`='false',`time`='$examtime', `hour`='$examhour',`instruction`='$examinstruction' WHERE title='$otitle' AND department = '$department' AND type = '$type' AND level = '$level'");
       
            }
             }
        else
        {
            $updateexam->execute_no_return("UPDATE `exam` SET `title`='$title',`code`='$code',`questions`='$questionno',`answers`='$answerno', score='$score', `keymode`='false', `strict`='false',`time`='$examtime', `hour`='$examhour',`instruction`='$examinstruction' WHERE title='$otitle' AND department = '$department' AND type = '$type' AND level = '$level'");
        }
   
        die("success");
    }
}
if(isset($_POST['viewexams']))
{
    session_start();
    require_once '../classes/config.php';
    $schoolname = preg_replace('/\s+/', '_', $_SESSION["school_name"]);
    $dep = $_POST['department'];
    $typ    = $_POST['type'];
    $lev = $_POST['level'];
    $counter = 0;
    //check if any exam exist
    $exami = new config($schoolname);
    $exami = $exami->execute_return("SELECT * FROM exam WHERE department = '$dep' AND type = '$typ' AND level = '$lev'");
    if(count($exami) > 0)
    {
        for($i=0; $i<count($exami); $i++)
        {
            $counter++;
            if($exami[$i]['strict'] == "true" || $exami[$i]['keymode'] == "true")
             {
                if($exami[$i]['strict'] == "true" && $exami[$i]['keymode'] == "true")
                {
                    $listofexam .= '<tr><td style="text-align: center;">'.$counter.'</td><td style="text-align: center;">'.$exami[$i]["title"].'</td><td style="text-align: center;">'.$exami[$i]["code"].'</td><td style="text-align: center;">'.$exami[$i]["questions"].'</td><td style="text-align: center;">'.$exami[$i]["answers"].'</td><td style="text-align: center;">'.$exami[$i]["score"].'</td><td style="text-align: center;">ON</td><td style="text-align: center;">ON</td><td style="text-align: center;">'.$exami[$i]["hour"].'</td><td style="text-align: center;">'.$exami[$i]["time"].'</td><td style="text-align: center;">'.$exami[$i]["department"].'</td><td style="text-align: center;">'.$exami[$i]["type"].'</td><td style="text-align: center;">'.$exami[$i]["level"].'</td><td style="text-align: center;">'.$exami[$i]["loaded"].'</td><td><a class="btn btn-primary" href="'. htmlspecialchars($_SERVER["PHP_SELF"]).'?title='. base64_encode($exami[$i]['title']).'&code='. base64_encode($exami[$i]['code']).'&dep='. base64_encode($exami[$i]['department']).'&type='. base64_encode($exami[$i]['type']).'&level='. base64_encode($exami[$i]['level']).'">Edit</a></td></tr>';
            
                }
                else if($exami[$i]['strict'] == "true" && $exami[$i]['keymode'] == "false")
                {
                    $listofexam .= '<tr><td style="text-align: center;">'.$counter.'</td><td style="text-align: center;">'.$exami[$i]["title"].'</td><td style="text-align: center;">'.$exami[$i]["code"].'</td><td style="text-align: center;">'.$exami[$i]["questions"].'</td><td style="text-align: center;">'.$exami[$i]["answers"].'</td><td style="text-align: center;">'.$exami[$i]["score"].'</td><td style="text-align: center;">OFF</td><td style="text-align: center;">ON</td><td style="text-align: center;">'.$exami[$i]["hour"].'</td><td style="text-align: center;">'.$exami[$i]["time"].'</td><td style="text-align: center;">'.$exami[$i]["department"].'</td><td style="text-align: center;">'.$exami[$i]["type"].'</td><td style="text-align: center;">'.$exami[$i]["level"].'</td><td style="text-align: center;">'.$exami[$i]["loaded"].'</td><td><a class="btn btn-primary" href="'. htmlspecialchars($_SERVER["PHP_SELF"]).'?title='. base64_encode($exami[$i]['title']).'&code='. base64_encode($exami[$i]['code']).'&dep='. base64_encode($exami[$i]['department']).'&type='. base64_encode($exami[$i]['type']).'&level='. base64_encode($exami[$i]['level']).'">Edit</a></td></tr>';
            
                }
                else
                {
                    $listofexam .= '<tr><td style="text-align: center;">'.$counter.'</td><td style="text-align: center;">'.$exami[$i]["title"].'</td><td style="text-align: center;">'.$exami[$i]["code"].'</td><td style="text-align: center;">'.$exami[$i]["questions"].'</td><td style="text-align: center;">'.$exami[$i]["answers"].'</td><td style="text-align: center;">'.$exami[$i]["score"].'</td><td style="text-align: center;">ON</td><td style="text-align: center;">OFF</td><td style="text-align: center;">'.$exami[$i]["hour"].'</td><td style="text-align: center;">'.$exami[$i]["time"].'</td><td style="text-align: center;">'.$exami[$i]["department"].'</td><td style="text-align: center;">'.$exami[$i]["type"].'</td><td style="text-align: center;">'.$exami[$i]["level"].'</td><td style="text-align: center;">'.$exami[$i]["loaded"].'</td><td><a class="btn btn-primary" href="'. htmlspecialchars($_SERVER["PHP_SELF"]).'?title='. base64_encode($exami[$i]['title']).'&code='. base64_encode($exami[$i]['code']).'&dep='. base64_encode($exami[$i]['department']).'&type='. base64_encode($exami[$i]['type']).'&level='. base64_encode($exami[$i]['level']).'">Edit</a></td></tr>';
            
                }
                   }
             else
             {
                 $listofexam .= '<tr><td style="text-align: center;">'.$counter.'</td><td style="text-align: center;">'.$exami[$i]["title"].'</td><td style="text-align: center;">'.$exami[$i]["code"].'</td><td style="text-align: center;">'.$exami[$i]["questions"].'</td><td style="text-align: center;">'.$exami[$i]["answers"].'</td><td style="text-align: center;">'.$exami[$i]["score"].'</td><td style="text-align: center;">OFF</td><td style="text-align: center;">OFF</td><td style="text-align: center;">'.$exami[$i]["hour"].'</td><td style="text-align: center;">'.$exami[$i]["time"].'</td><td style="text-align: center;">'.$exami[$i]["department"].'</td><td style="text-align: center;">'.$exami[$i]["type"].'</td><td style="text-align: center;">'.$exami[$i]["level"].'</td><td style="text-align: center;">'.$exami[$i]["loaded"].'</td><td><a class="btn btn-primary" href="'. htmlspecialchars($_SERVER["PHP_SELF"]).'?title='. base64_encode($exami[$i]['title']).'&code='. base64_encode($exami[$i]['code']).'&dep='. base64_encode($exami[$i]['department']).'&type='. base64_encode($exami[$i]['type']).'&level='. base64_encode($exami[$i]['level']).'">Edit</a></td></tr>';
             }
            
        }
        die($listofexam);
    }
    else
    {
        die("notfound");
    }
}
require_once 'header.php'; ?>
<style>
    #loader, #successAlert, #errorAlert, #loadering, #errorAlert1, #successAlert1
    {
        display: none;
    }
    </style>
<div class="container">
    <div class="row">
        <div class="col-sm-5">
            
            
            <div class="alert alert-success" id="successAlert">
                <strong>Success!</strong><span id="sat"></span>
</div>
            <div class="alert alert-danger" id="errorAlert">
                <strong>Error!</strong><span id="eat"></span>
</div>
            <div class="card" style="text-align: center;">
                <div class="card-header">Select Exam to View</div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="editexamform" name="editexam" method="post" enctype="multipart/form-data"> 
                        
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           <input class="form-control" type="hidden" name="schoolname1" value="<?php echo $_SESSION["school_name"]; ?>" required="" />
                                                   <span class="input-group-addon"><i class="fa fa-group"></i></span>
                                                   <select class="form-control" onchange="setType(this.value);" id="department" name="department" required="">
                                                       <option value="" selected="">SELECT DEPARTMENT</option>
                                                       <?php
                                                       $username = $_SESSION['username'];
                                                       $schoolname = preg_replace('/\s+/', '_', $_SESSION["school_name"]);
                                                        $stafdep = new config($schoolname);
                                                        $stafdep = $stafdep->execute_return("SELECT department FROM staffs WHERE email = '$username'");
                                                       
                                                        $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($stafdep); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($stafdep[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$stafdep[$i]["department"].'">'.$stafdep[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $stafdep[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
                                                       
                                                       ?>
                                                   </select>
                                                                        </div>
               
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setLevel(this.value);" class="form-control" id="type" name="type" required="">
                                                       <option value="" selected="">SELECT TYPE</option>
                                                   </select> </div>
            
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select class="form-control" id="level" name="level" required="">
                                                       <option value="" selected="">SELECT LEVEL</option>
                                                   </select></div>
                                                        
                         <div id="loader"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success" id="cema" type="submit" name="viewexams" onclick="viewexam();" value="View Exam to Edit" style="margin-bottom: 5px;"/> 
                        
                </div>
                                                            
                                                            </form>
            <br>
           
</div>
                </div>
        <?php 
    $ste = "";
    if(isset($_GET['title']))
                    {
    $ste = "(".base64_decode($_GET['title']).")";
                    }
                    ?>
        <div class="col-sm-7">
          
              <?php
              if(isset($_GET['title']) && isset($_GET['code']) && isset($_GET['dep']) && isset($_GET['type']) && isset($_GET['level']))
              {
                  $titler = base64_decode($_GET['title']);
                  $coder = base64_decode($_GET['code']);
                  $deppp = base64_decode($_GET['dep']);
                  $typp = base64_decode($_GET['type']);
                  $levv = base64_decode($_GET['level']);
                  
                  //check if parameter exist in exam table
                  
                  $selectexam = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                  $selectexam = $selectexam->execute_return("SELECT * FROM exam WHERE title = '$titler' AND code = '$coder' AND department = '$deppp' AND type = '$typp' AND level = '$levv'");
                  if(count($selectexam) > 0)
                  {
                      if(isset($_SESSION['titling']))
                      {
                          unset($_SESSION['titling']);
                      }
                      if(isset($_SESSION['codling']))
                      {
                          unset($_SESSION['codling']);
                      }
                      $_SESSION['titling'] = $titler;
                      
                      echo '<div class="card"><div class="alert alert-success" id="successAlert1">
                <strong>Success!</strong><span id="sat1"></span>
</div>
            <div class="alert alert-danger" id="errorAlert1">
                <strong>Error!</strong><span id="eat1"></span>
</div><div class="card-header" style="text-align: center; font-weight: bold;">Edit Panel <?php echo $ste; ?></div>
          <div class="card-body" style="text-align: center;" id="result"><form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="editerexamform" name="editerexam" method="post" enctype="multipart/form-data"> 
                        
                                           
                                                           
                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-header"></i></span>
                                                           <input class="form-control" type="text" id="subjecttitle" name="subjecttitle" value="'.$selectexam[0]["title"].'" required=""/>
                                                                        </div>
                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-hashtag"></i></span>
                                                           <input type="text"  class="form-control" id="subjectcode" value="'.$selectexam[0]["code"].'" name="subjectcode" required="" placeholder="Subject Code"/>
                                                           
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-question"></i></span>
                                                           <input type="number" id="numberofquesion" min="1" max="100" class="form-control" name="numberofquesion" value="'.$selectexam[0]["questions"].'" required="" placeholder="No of Questions">
                                                          
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-question-circle"></i></span>
                                                           <input type="number" id="numberofanswer" min="2" max="5" class="form-control" value="'.$selectexam[0]["answers"].'" name="numberofanswer" required="" placeholder="No of Answers">
                                                          
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-question-circle"></i></span>
                                                           <input type="number" id="score" min="1" max="100" class="form-control" value="'.$selectexam[0]["score"].'" name="score" required="" placeholder="Score Per Question">
                                                          
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-lock"> Key Mode</i></span>
                                                           ';
                      if($selectexam[0]['keymode'] == "true")
                      {
                          echo '<input type="checkbox" id="keymode" class="form-control" checked name="keymode">';
                      }
                      else
                      {
                          echo '<input type="checkbox" id="keymode" class="form-control" name="keymode">';
                      }
                      echo '
                                                          
                                                                        </div>
                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-key"> Strict Policy</i></span>
                                                           ';
                      if($selectexam[0]['strict'] == "true")
                      {
                          echo '<input type="checkbox" id="strict" class="form-control" checked name="strict">';
                      }
                      else
                      {
                          echo '<input type="checkbox" id="strict" class="form-control" name="strict">';
                      }
                      echo '
                                                          
                                                                        </div>
                                                                        
                                                             <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <input class="form-control" type="hidden" name="schoolname1" value="'.$_SESSION["school_name"].'" required="" />
                                                           <span class="input-group-addon"><i class="fa fa-clock"></i></span>
                                                           <input class="form-control" id="examhour" min="0" max="4" type="number" name="examhour" value="'.$selectexam[0]["hour"].'" required="" placeholder="Exam TIme in Hours" />
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-clock"></i></span>
                                                           <input class="form-control" id="examtime" min="5" max="59" type="number" name="examtime" value="'.$selectexam[0]["time"].'" required="" placeholder="Exam TIme in minutes" />
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-info"></i></span>
                                                   <textarea class="form-control" id="examinstuction" style="height: 100px; resize: none;" name="examinstuction" required="" placeholder="Exam Instruction">'.$selectexam[0]["instruction"].'</textarea>
                                                                        </div>
                       
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-group"></i></span>
                                                   <input type="text" class="form-control" value="'.$selectexam[0]["department"].'" id="departmentv" name="departmentv" required="">
                                                      
                                                                        </div>
               
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <input type="text" value="'.$selectexam[0]["type"].'" class="form-control" id="typev" name="typev" required="">
                                                        </div>
            
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <input type="text" value="'.$selectexam[0]["level"].'" class="form-control" id="levelv" name="levelv" required="">
                                                      </div>
                                                        
                         <div id="loadering"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success" id="cem" type="submit" name="editcreatedexam" onclick="ceditexam();" value="Update" style="margin-bottom: 5px;"/> 
                        
                </div>
                                                            
                                                            </form></div></div>';
                  }
                  else{
                      echo '<div class="card">
                
                <div class="card-body">
                Invalid exam parameters. Please browse the website properly.
            <br>
           
</div>
                </div>';
                  }
              }
              else
              {
                   echo '<div class="card">
                
                <div class="card-body">
                Click on edit button to edit exam
            <br>
           
</div>
                </div>';
              }
              ?>
          </div>
        </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="card" style="text-align: center;">
                <div class="card-header">Exams</div>
                <div class="card-body">
                    <div class="table-responsive" style="max-height: 500px; background: #ffffff; color: #000000;">
            <table class="table" style="font-size: 14px !important;">
    <thead>
      <tr>
          <th style="text-align:center;">#</th>
          <th style="text-align:center;">Title</th>
        <th style="text-align:center;">Code</th>
        <th style="text-align:center;">No. of Questions</th>
        <th style="text-align:center;">No. of Answers</th>
        <th style="text-align:center;">Score Per question</th>
        <th style="text-align:center;">Key Mode</th>
        <th style="text-align:center;">Strict Policy</th>
        <th style="text-align:center;">Time(hours)</th>
        <th style="text-align:center;">Time(minutes)</th>
        <th style="text-align:center;">Department</th>
        <th style="text-align:center;">Type</th>
        <th style="text-align:center;">Level</th>
        <th style="text-align:center;">Loaded</th>
        <th style="text-align:center;"></th>
      </tr>
    </thead>
    <tbody id="tablebofy">
        <tr><td style="text-align: center;" colspan="12">Make selection above in order to view and edit student.</td></tr>
    </tbody>
            </table>
                    </div>
                </div>
        </div>
                
    </div>
</div>
<script>
    
    function ceditexam()
    {
          
    $('#editerexamform').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert1").style.display = "none";
      document.getElementById("successAlert1").style.display = "none";
      document.getElementById("cem").style.display = "none";
      document.getElementById("loadering").style.display = "block";
      
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
          if(myResp == "empty")
          {
              document.getElementById("eat1").innerHTML = " No field must be left blank.";
              document.getElementById("errorAlert1").style.display = "block";
      document.getElementById("successAlert1").style.display = "none";
      document.getElementById("cem").style.display = "block";
      document.getElementById("loadering").style.display = "none";
          }
          else if(myResp == "exist")
          {
              document.getElementById("eat1").innerHTML = " Exam title for department, type and level already exist.";
              document.getElementById("errorAlert1").style.display = "block";
      document.getElementById("successAlert1").style.display = "none";
      document.getElementById("cem").style.display = "block";
      document.getElementById("loadering").style.display = "none";
          }
          else if(myResp == "loaded")
          {
              document.getElementById("eat1").innerHTML = " You can not edit this exam because questions for it has been loaded. Refreshing page in 10 seconds.";
              document.getElementById("errorAlert1").style.display = "block";
      document.getElementById("successAlert1").style.display = "none";
      document.getElementById("cem").style.display = "block";
      document.getElementById("loadering").style.display = "none";
      window.setInterval(function(){window.location.href = "editexam.php";},10000);
          }
          else if(myResp == "success")
          {
              document.getElementById("sat1").innerHTML = " Exam successfully updated. refreshing page in 5 seconds.";
              document.getElementById("errorAlert1").style.display = "none";
      document.getElementById("successAlert1").style.display = "block";
      document.getElementById("cem").style.display = "block";
      document.getElementById("loadering").style.display = "none";
      window.setInterval(function(){window.location.href = "editexam.php";},5000);
          }
          else
          {
              document.getElementById("eat1").innerHTML = " Oops, something went wrong, please refresh the page and try again.";
              document.getElementById("errorAlert1").style.display = "block";
      document.getElementById("successAlert1").style.display = "none";
      document.getElementById("cem").style.display = "block";
      document.getElementById("loadering").style.display = "none";
          }
      }
      }); 
    }
     function viewexam() 
  {
      
    $('#editexamform').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "none";
      document.getElementById("cema").style.display = "none";
      document.getElementById("loader").style.display = "block";
      
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
          if(myResp == "notfound")
          {
              document.getElementById("errorAlert").innerHTML = " Exam not found for selection made."
              document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
      document.getElementById("cema").style.display = "block";
      document.getElementById("loader").style.display = "none";
          }
          else
          {
              document.getElementById("successAlert").innerHTML = " Exam successfully found, check below to edit."
              document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "block";
      document.getElementById("cema").style.display = "block";
      document.getElementById("loader").style.display = "none";
      document.getElementById("tablebofy").innerHTML = "";
      document.getElementById("tablebofy").innerHTML = myResp;
          }
      }
    }); 
  }
  
    function setType(e)
    {
        document.getElementById("type").value = "";
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getdstaffdetails.php",
        type: "post",
        data: "data=type"+"&department="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("type").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("type").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel(e)
    {
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getdstaffdetails.php",
        type: "post",
        data: "data=level"+"&type="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("level").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("level").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
</script>
<?php require_once 'footer.php'; ?>