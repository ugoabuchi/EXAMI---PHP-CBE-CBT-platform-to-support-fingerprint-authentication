<?php 
$title = "Print Result";
$active1 = "";
$active2 = "";
$active3 = "";
$active4 = "";
$active5 = "";
$active6 = "";
$active7 = "";
$active8 = "activer";
$active9 = "";
require_once 'header.php'; ?>
<style>
.dt-buttons span
{
    padding: 8px !important;
    color: #ffffff !important;
    background: green !important;
    border: none !important;
   
}
.dt-buttons
{
     margin-bottom: 6px !important;
}
#tabler_paginate a
{
     padding: 2px !important;
    color: #ffffff !important;
    background: green !important;
    border: none !important;
    font-size: 13px;
    margin-right: 5px;
}
    #loader, #successAlert, #errorAlert
    {
        display: none;
    }
    .fortune_modal
    {
        padding: 5px;
        width: 90%;
        margin: auto;
        position: fixed;
        right: 5px;
        left: 5px;
        top: 5px;
        z-index: 999999999 !important;
        background: rgb(255,255,255);
        display: none;
    }
    
    .fortune_modal_head{
        color: #ffffff;
        margin-bottom: 20px;
        
    }
    
    .fortune_modal_head i{
        cursor: crosshair;
    }
    
    .fortune_modal_body
    {
        padding: 3px;
        background: rgb(255,255,255); 
        text-align: center;
    }
    @media print
    {
        .header-desktop, .logo, .dt-buttons,#tabler_paginate, #tabler_filter{
            display: none !important;
        }
       .fortune_modal,  .fortune_modal_body
    {
        position: relative !important;
    overflow:visible!important;
    }
    
    .bdy, .btn-primary{
        display: none;
    }
    }
    </style>
    <?php 
    if(isset($_POST["ExportType"]))
{
            
       include_once '../classes/config.php';
     
    $sch = preg_replace('/\s+/', '_', $_POST['sn']);
    $title = $_POST['tit'];
    $dep8 = $_POST['dep'];
    $typ8 = $_POST['typ'];
    $lev8 = $_POST['lev'];
    $data = array();
    $edetail = new config($sch);
    $edetail = $edetail->execute_return("SELECT questions, answers, strict, score FROM exam WHERE department='$dep8' AND type='$typ8' AND level='$lev8' AND title='$title'");
    $ques = (int)$edetail[0]['questions'];
    $sco = (int)$edetail[0]['score'];

    $stide = new config($sch);
    $stide = $stide->execute_return("SELECT * FROM `students` WHERE department='$dep8' AND type='$typ8' AND level='$lev8'");

    for($r=0; $r<count($stide); $r++)
    {
        $ascore =0;
        $bscore = 0;
        $tscore = 0;
        $user = $stide[$r]['username'];
        //add name to excel array
        
          $data = array_merge($data, array($r=>array("surname"=>$stide[$r]['surname'], "othernames"=>$stide[$r]['othernames'], "username"=>$stide[$r]['username'])));
         
        $sdetail = new config($sch);
        $sdetail = $sdetail->execute_return("SELECT * FROM exam_table WHERE student_username='$user' AND title='$title'");
        if(count($sdetail) > 0)
        {
            for($y=0; $y<count($sdetail); $y++)
            {
                if($sdetail[$y]['mark'] == "pass")
                {
                    $ascore = $ascore + $sco;
                }
                else
                {
                    $bscore = $bscore + $sco;
                }
            }
            
            if($edetail[0]['strict'] == "true")
            {
                if(($ascore - $bscore) < 0)
                {
                    $tscore = 0;
                }
                else
                {
                    $tscore = $ascore - $bscore;
                }
            }
            else
            {
                $tscore = $ascore;
                
            }
            
          
          
            $data[$r] = array_merge($data[$r], array("tscore"=>$tscore));
          
          
        
        }
        else
        {
            $data[$r] = array_merge($data[$r], array("tscore"=>"0"));
            
        }
    }
    
    $filename = "Export_excel.xls";
    header("Content-Type: text/plain");
    header("Content-Disposition: attachment; filename=\"$filename\""); 
    header("Content-Type: application/vnd.ms-excel;charset=UTF-16LE");
    $isPrintHeader = false;
    if (! empty($data)) {
        foreach ($data as $row) {
            if (! $isPrintHeader) {
                echo implode("\t", array_keys($row)) . "\n";
                $isPrintHeader = true;
            }
            echo implode("\t", array_values($row)) . "\n";
        }
    }
    exit();
}


  if(isset($_POST['resettime']))
   {
    
     include_once '../classes/config.php';
     $schn = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $schn = $schn->execute_return("SELECT * FROM administrator LIMIT 1");
    $sch = preg_replace('/\s+/', '_', $_POST['sch']);
    $title = $_POST['title'];
    $dep8 = $_POST['department'];
    $typ8 = $_POST['type'];
    $lev8 = $_POST['level'];
     
        echo '<style>'
        . ' .header-desktop{'
                . 'z-index: 0 !important;'
                . '} '
                . '</style>';
    
    
    echo '<div class=" container fortune_modal">
        <div class="fortune_modal_head">
            <i class="fa fa-times-circle pull-right exit" style="color: #000000;" onclick="document.getElementsByClassName(\'fortune_modal\')[0].style.display=\'none\';"></i>
            <div class="row">
        <div class="col-sm-4" style="text-align: center;">
        <img src="../administrator/'.preg_replace('/\s+/', '_', $_SESSION['school_name']).'/logo-'.$schn[0]['logoimage'].'.png" alt="'.$_SESSION['school_name'].'" style="width: 100px; height: 100px;" />
</div>
                <div class="col-sm-8">
                    <h3 class="modal-title" style="text-align:center; font-weight: bold;">'.$schn[0]['schoolname'].'</h3>
         <h3 class="modal-title" style="text-align:center; font-weight: bold;">'.$title.'</h3>
         <p style="text-align:center; color:#000000; font-weight: bold;">'.$dep8.' '.$typ8.'   '.$lev8.' result</p>
                </div>
                    
            </div>
            <div><hr style="width: 100%; height: 1px; background: #000000;"></div>
        </div>
    <div class="fortune_modal_body">
    <iframe id="txtArea1" style="display:none"></iframe>
        <div class="table-responsive" background: #ffffff; color: #000000;">
        
 <form action="'.$_SERVER["PHP_SELF"].'" method="post" id="export-form">
    <input type="hidden" value="'.$_SESSION['username'].'" name="ExportType"/>
    <input type="hidden" value="'.$_SESSION['school_name'].'" name="sn"/>
    <input type="hidden" value="'.$title.'" name="tit"/>
    <input type="hidden" value="'.$dep8.'" name="dep"/>
    <input type="hidden" value="'.$typ8.'" name="typ"/>
    <input type="hidden" value="'.$lev8.'" name="lev"/>
    </form>
    <div style="text-align: center; margin-bottom: 10px;"><button class="btn btn-primary" id="btnExport" onclick="lio();">Filter | Search | Export</button> &nbsp;<button class="btn btn-primary" onclick="window.print();">Print</button></div>
            <table class="display nowrap" id="tabler" style="width:100%">
    <thead>
      <tr>
          <th style="text-align:center;">Sn</th>
          <th style="text-align:center;">Surname</th>
          <th style="text-align:center;">Name</th>
        <th style="text-align:center;">Username</th>
        <th style="text-align:center;">Score</th>
      </tr>
    </thead>
    <tbody id="tablebofy">
    ';
    
    
    $edetail = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
    $edetail = $edetail->execute_return("SELECT questions, answers, strict, score FROM exam WHERE department='$dep8' AND type='$typ8' AND level='$lev8' AND title='$title'");
    $ques = (int)$edetail[0]['questions'];
    $sco = (int)$edetail[0]['score'];
    $stide = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
    $stide = $stide->execute_return("SELECT * FROM `students` WHERE department='$dep8' AND type='$typ8' AND level='$lev8'");
    for($r=0; $r<count($stide); $r++)
    {
        $ascore =0;
        $bscore = 0;
        $tscore = 0;
        $user = $stide[$r]['username'];
        echo '<tr><td style="text-align: center; font-weight: bold;">'.($r+1).'</td><td style="text-align: center; font-weight: bold;">'.$stide[$r]['surname'].'</td><td style="text-align: center; font-weight: bold;">'.$stide[$r]['othernames'].'</td><td style="text-align: center; font-weight: bold;">'.$stide[$r]['username'].'</td>';
        $sdetail = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $sdetail = $sdetail->execute_return("SELECT * FROM exam_table WHERE student_username='$user' AND title='$title'");
        if(count($sdetail) > 0)
        {
            for($y=0; $y<count($sdetail); $y++)
            {
                if($sdetail[$y]['mark'] == "pass")
                {
                    $ascore = $ascore + $sco;
                }
                else
                {
                    $bscore = $bscore + $sco;
                }
            }
            
            if($edetail[0]['strict'] == "true")
            {
                if(($ascore - $bscore) < 0)
                {
                    $tscore = 0;
                }
                else
                {
                    $tscore = $ascore - $bscore;
                }
            }
            else
            {
                $tscore = $ascore;
                
            }
            
            echo '<td style="text-align: center; font-weight: bold;">'.$tscore.'</td></tr>';
        }
        else
        {
            echo '<td style="text-align: center; font-weight: bold;">0</td></tr>';
        }
    }
    echo '
      
    </tbody>
    </table>
    </div>
    </div>
</div>
    <script>
    $(".fortune_modal").slideDown(2000);
    </script>';
   }
    ?>

    
    
    
    
<div class="container bdy">
            <div class="alert alert-success" id="successAlert">
                <strong>Success!</strong><span id="sat1"></span>
</div>
            <div class="alert alert-danger" id="errorAlert">
                <strong>Error!</strong><span id="eat1"></span>
</div>
            <div class="card" style="text-align: center;">
                <div class="card-header">Print Exam Result</div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="resetform" name="addreset" method="post" enctype="multipart/form-data"> 
                            <div style="margin-bottom: 25px" class="input-group">
                                                           <input class="form-control" type="hidden" name="schoolname1" value="<?php echo $_SESSION["school_name"]; ?>" required="" />
                                                   <span class="input-group-addon"><i class="fa fa-group"></i></span>
                                                   <select class="form-control" onchange="setType(this.value);" id="department" name="department" required="">
                                                       <option value="" selected="">SELECT DEPARTMENT</option>
                                                       <?php
                                                       $username = $_SESSION['username'];
                                                       $schoolname = preg_replace('/\s+/', '_', $_SESSION["school_name"]);
                                                        $stafdep = new config($schoolname);
                                                        $stafdep = $stafdep->execute_return("SELECT department FROM staffs WHERE email = '$username'");
                                                       
                                                        $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($stafdep); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($stafdep[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$stafdep[$i]["department"].'">'.$stafdep[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $stafdep[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
                                                       
                                                       ?>
                                                   </select>
                                                                        </div>
               
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setLevel(this.value);" class="form-control" id="type" name="type" required="">
                                                       <option value="" selected="">SELECT TYPE</option>
                                                   </select> </div>
            
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setTit(this.value);" class="form-control" id="level" name="level" required="">
                                                       <option value="" selected="">SELECT LEVEL</option>
                                                   </select></div>
                                           
                                         <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-hashtag"></i></span>
                                                           <input type="hidden"  class="form-control" id="sch" value='<?php echo $_SESSION['school_name']; ?>' name="sch" required=""/>
                                                           <select class="form-control" id="title" name="title" required="">
                                                               <option value="" selected="">SELECT SUBJECT</option>
                                                           </select>
                                                            </div>
                                                        
                         <div id="loader"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success" id="cema" type="submit" name="resettime" onclick="cexam();" value="Print Result" style="margin-bottom: 5px;"/> 
                        
                </div>
                                                            
                                                            </form>
            <br>
           
</div>
                
        
     

</div>
<script>
   
      function setType(e)
    {
        document.getElementById("type").value = "";
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/gtitle.php",
        type: "post",
        data: "data=type"+"&department="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("type").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("type").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel(e)
    {
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/gtitle.php",
        type: "post",
        data: "data=level"+"&type="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("level").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("level").innerHTML += myResp;
          
        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setTit(e)
    {
         document.getElementById("title").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/gtitle.php",
        type: "post",
        data: "data=title"+"&level="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("title").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("title").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
  function lio()
  {
        $('#tabler').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'csv', 'excel', 'pdf'
        ]
    } );
  }
function fnExcelReport()
{
    var tab_text = '<table border="none" style="font-size:15px; border: none !important;">';
    var textRange; 
    var j = 0;
    var tab = document.getElementById('tabler'); // id of table
    var lines = tab.rows.length;

    // the first headline of the table
    if (lines > 0) {
        tab_text = tab_text + '<tr bgcolor="#DFDFDF">' + tab.rows[0].innerHTML + '</tr>';
    }

    // table data lines, loop starting from 1
    for (j = 1 ; j < lines; j++) {     
        tab_text = tab_text + "<tr align='right'" + tab.rows[j].innerHTML + "</tr>";
    }

    tab_text = tab_text + "</table>";
    tab_text = tab_text.replace(/<A[^>]*>|<\/A>/g, "");             //remove if u want links in your table
    tab_text = tab_text.replace(/<img[^>]*>/gi,"");                 // remove if u want images in your table
    tab_text = tab_text.replace(/<input[^>]*>|<\/input>/gi, "");    // reomves input params
    // console.log(tab_text); // aktivate so see the result (press F12 in browser)

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

     // if Internet Explorer
    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa = txtArea1.document.execCommand("SaveAs", true, "exami.xls");
    }  
    else // other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}

</script>
<?php require_once 'footer.php'; ?>