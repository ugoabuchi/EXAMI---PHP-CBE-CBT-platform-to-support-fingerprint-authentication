<?php 
$title = "Reset Student Time";
$active1 = "";
$active2 = "";
$active3 = "";
$active4 = "";
$active5 = "";
$active6 = "";
$active7 = "activer";
$active8 = "";
$active9 = "";
if(isset($_POST['resettime']))
{
    include_once '../classes/config.php';
    $sch = preg_replace('/\s+/', '_', $_POST['sch']);
    $title = $_POST['title'];
    $username = $_POST['username'];
    
    
    //check if exist
    $etime = new config($sch);
    $etime = $etime->execute_count_no_return("SELECT COUNT(*) FROM timer WHERE username='$username' AND title='$title'");
    if($etime == 1)
    {
        $timedel = new config($sch);
        $timedel->execute_no_return("DELETE FROM timer WHERE username='$username' AND title='$title'");
        die("success");
    }
 else {
        die("notwritten");
    }
}
require_once 'header.php'; ?>
<style>
    #loader, #successAlert, #errorAlert
    {
        display: none;
    }
    </style>
<div class="container">
            <div class="alert alert-success" id="successAlert">
                <strong>Success!</strong><span id="sat1"></span>
</div>
            <div class="alert alert-danger" id="errorAlert">
                <strong>Error!</strong><span id="eat1"></span>
</div>
            <div class="card" style="text-align: center;">
                <div class="card-header">Create Exam</div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="resetform" name="addreset" method="post" enctype="multipart/form-data"> 
                            <div style="margin-bottom: 25px" class="input-group">
                                                           <input class="form-control" type="hidden" name="schoolname1" value="<?php echo $_SESSION["school_name"]; ?>" required="" />
                                                   <span class="input-group-addon"><i class="fa fa-group"></i></span>
                                                   <select class="form-control" onchange="setType(this.value);" id="department" name="department" required="">
                                                       <option value="" selected="">SELECT DEPARTMENT</option>
                                                       <?php
                                                       $username = $_SESSION['username'];
                                                       $schoolname = preg_replace('/\s+/', '_', $_SESSION["school_name"]);
                                                        $stafdep = new config($schoolname);
                                                        $stafdep = $stafdep->execute_return("SELECT department FROM staffs WHERE email = '$username'");
                                                       
                                                        $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($stafdep); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($stafdep[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$stafdep[$i]["department"].'">'.$stafdep[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $stafdep[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
                                                       
                                                       ?>
                                                   </select>
                                                                        </div>
               
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setLevel(this.value);" class="form-control" id="type" name="type" required="">
                                                       <option value="" selected="">SELECT TYPE</option>
                                                   </select> </div>
            
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setTit(this.value);" class="form-control" id="level" name="level" required="">
                                                       <option value="" selected="">SELECT LEVEL</option>
                                                   </select></div>
                                           
                                         <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-hashtag"></i></span>
                                                           <input type="hidden"  class="form-control" id="sch" value='<?php echo $_SESSION['school_name']; ?>' name="sch" required=""/>
                                                           <select class="form-control" id="title" name="title" required="">
                                                               <option value="" selected="">SELECT SUBJECT</option>
                                                           </select>
                                                           <input type="text"  class="form-control" id="username" value="" name="username" required="" placeholder="Student Username"/>
                                                           
                                                                        </div>
                                                        
                         <div id="loader"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success" id="cema" type="submit" name="resettime" onclick="cexam();" value="Reset" style="margin-bottom: 5px;"/> 
                        
                </div>
                                                            
                                                            </form>
            <br>
           
</div>
                
        
     
   
</div>
<script>
    function cexam() 
  {
      
    $('#resetform').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "none";
      document.getElementById("cema").style.display = "none";
      document.getElementById("loader").style.display = "block";
      
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
          if(myResp == "success")
          {
               document.getElementById("sat1").innerHTML = " Student time successfully reset for selected exam.";
               document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "block";
      document.getElementById("cema").style.display = "block";
      document.getElementById("loader").style.display = "none";
          }
          else if(myResp == "nowritten")
          {
               document.getElementById("eat1").innerHTML = " Student has not written selected exam.";
               document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
      document.getElementById("cema").style.display = "block";
      document.getElementById("loader").style.display = "none";
          }
          else
          {
               document.getElementById("eat1").innerHTML = " Opps something went wrong, please refresh the page and try again.";
               document.getElementById("errorAlert").style.display = "block";
      document.getElementById("successAlert").style.display = "none";
      document.getElementById("cema").style.display = "block";
      document.getElementById("loader").style.display = "none";
          }
       
      }
    }); 
  }
  
      function setType(e)
    {
        document.getElementById("type").value = "";
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/gtitle.php",
        type: "post",
        data: "data=type"+"&department="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("type").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("type").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel(e)
    {
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/gtitle.php",
        type: "post",
        data: "data=level"+"&type="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("level").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("level").innerHTML += myResp;
        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setTit(e)
    {
         document.getElementById("title").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/gtitle.php",
        type: "post",
        data: "data=title"+"&level="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("title").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("title").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
</script>
<?php require_once 'footer.php'; ?>