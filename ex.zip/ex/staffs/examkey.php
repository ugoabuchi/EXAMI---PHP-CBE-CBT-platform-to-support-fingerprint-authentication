<?php 
$title = "Set Key Mode";
$active1 = "";
$active2 = "";
$active3 = "";
$active4 = "";
$active5 = "";
$active6 = "";
$active7 = "";
$active8 = "";
$active9 = "activer";
if(isset($_POST['schdelete']))
{
    require_once '../classes/config.php';
    if(isset($_POST['stu_username']))
    {
      $sch = preg_replace('/\s+/', '_', $_POST['schoolname']);
    $etitle = base64_decode($_POST['etitle']);
    $edep = base64_decode($_POST['edep']);
    $etype = base64_decode($_POST['etype']);
    $elev = base64_decode($_POST['elev']);
    $stu_username = base64_decode($_POST['stu_username']);
    //delete schedule
    $desch = new config($sch);
    $desch->execute_no_return("DELETE FROM keytable WHERE stu_username = '$stu_username' AND title='$etitle' AND department='$edep' AND type='$etype' AND level='$elev'");
    die("success");
    }
    else
    {
      $sch = preg_replace('/\s+/', '_', $_POST['schoolname']);
    $etitle = base64_decode($_POST['etitle']);
    $edep = base64_decode($_POST['edep']);
    $etype = base64_decode($_POST['etype']);
    $elev = base64_decode($_POST['elev']);
    //delete schedule
    $desch = new config($sch);
    $desch->execute_no_return("DELETE FROM keytable WHERE title='$etitle' AND department='$edep' AND type='$etype' AND level='$elev'");
    die("success");
    }
    
}
if(isset($_POST['schedule']))
{
     require_once '../classes/config.php';
    $dep = $_POST['department'];
    $typ = $_POST['type'];
    $level = $_POST['level'];
    $tit = $_POST['subjecttitle'];
    $stu_username = strtoupper($_POST['stu_username']);
    $key = $_POST['keymode'];
    $sch = preg_replace('/\s+/', '_', $_POST['schoolname']);
    //heck if student exist in parameters of student db
    $chstu = new config($sch);
    $chstu = $chstu->execute_count_no_return("SELECT COUNT(*) FROM students WHERE username='$stu_username' AND department='$dep' AND type='$typ' AND level='$level'");
    if($chstu == 1)
    {
       //check if student is already available

    $stuch = new config($sch);
    $stuch = $stuch->execute_count_no_return("SELECT COUNT(*) FROM keytable WHERE stu_username = '$stu_username' AND title = '$tit'");
    if($stuch == 0)
    {
       //insert it to schedule table
     $newsch = new config($sch);
     $newsch->execute_no_return("INSERT INTO `keytable`(`title`, `keyer`,`department`, `type`, `level`,`stu_username`) VALUES ('$tit', '$key', '$dep', '$typ', '$level', '$stu_username')");
    }
    else
    {
       $newsch = new config($sch);
     $newsch->execute_no_return("UPDATE keytable SET keyer='$key' WHERE stu_username = '$stu_username' AND title = '$tit' AND department='$dep' AND type='$typ' AND level='$level'");
    }
    
     
     echo "success";
     exit();    
    }
    else
    {
      echo "s_exist";
      exit();
    }
     
}
require_once 'header.php'; 
//check if schedule db is created
$schde = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
$schde = $schde->execute_return("SHOW TABLES LIKE 'keytable'");
 if($schde == false && count($schde) <= 0)
 {
     //create schedule db
     $schdb = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
     $schdb->execute_no_return("CREATE TABLE `keytable` ( `id` INT(16) NOT NULL AUTO_INCREMENT , `title` VARCHAR(150) NOT NULL , `keyer` VARCHAR(150) NOT NULL, `department` VARCHAR(150) NOT NULL , `type` VARCHAR(150) NOT NULL , `level` VARCHAR(150) NOT NULL , `stu_username` VARCHAR(150) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;");
 }
?>

<style>
    #loader, #successAlert, #errorAlert, #successAlert4
    {
        display: none;
    }
    </style>
<div class="container">
    <div class="row">
              <div class="col-sm-12">
                        <div class="alert alert-success" id="successAlert">
                <strong>Success!</strong><span id="sat"></span>
</div>
            <div class="alert alert-danger" id="errorAlert">
                <strong>Error!</strong><span id="eat"></span>
</div>
            <div class="card" style="text-align: center;">
                <div class="card-header">Create Exam key</div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="scheduleexam" name="schedulingexam" method="post" enctype="multipart/form-data"> 
                        
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-group"></i></span>
                                                   <select class="form-control" onchange="setType(this.value);" id="department" name="department" required="">
                                                       <option value="" selected="">SELECT DEPARTMENT</option>
                                                       <?php
                                                       $username = $_SESSION['username'];
                                                       $schoolname = preg_replace('/\s+/', '_', $_SESSION["school_name"]);
                                                        $stafdep = new config($schoolname);
                                                        $stafdep = $stafdep->execute_return("SELECT department FROM staffs WHERE email = '$username'");
                                                       
                                                        $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($stafdep); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($stafdep[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$stafdep[$i]["department"].'">'.$stafdep[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $stafdep[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
                                                       
                                                       ?>
                                                   </select>
                                                                        </div>
               
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setLevel(this.value);" class="form-control" id="type" name="type" required="">
                                                       <option value="" selected="">SELECT TYPE</option>
                                                   </select> </div>
            
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setTitle(this.value);" class="form-control" id="level" name="level" required="">
                                                       <option value="" selected="">SELECT LEVEL</option>
                                                   </select></div>
                        <div id="subjecttitler"></div>
                                                        
                         <div id="loader"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-primary" id="cema" type="submit" name="schedule" onclick="scheduler();" value="Create Exam Key" style="margin-bottom: 5px;"/> 
                        
                </div>
                                                            
                                                            </form>
            <br>
           
</div>
                </div>
         <div class="col-sm-12">
            <div class="col-sm-12">
                        <div class="alert alert-success" id="successAlert4">
                <strong>Success!</strong><span id="sat4"></span>
</div>
            <div class="card-header" style="text-align: center;">Locked Exams</div>
                <div class="card-body">
                  <div style="margin-bottom: 25px" class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-group"></i></span>
                                                   <select class="form-control" onchange="setType1(this.value);" id="department1" name="department" required="">
                                                       <option value="" selected="">SELECT DEPARTMENT</option>
                                                       <?php
                                                       $username = $_SESSION['username'];
                                                       $schoolname = preg_replace('/\s+/', '_', $_SESSION["school_name"]);
                                                        $stafdep = new config($schoolname);
                                                        $stafdep = $stafdep->execute_return("SELECT department FROM staffs WHERE email = '$username'");
                                                       
                                                        $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($stafdep); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($stafdep[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$stafdep[$i]["department"].'">'.$stafdep[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $stafdep[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
                                                       
                                                       ?>
                                                   </select>
                                                                        </div>
               
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setLevel1(this.value);" class="form-control" id="type1" name="type" required="">
                                                       <option value="" selected="">SELECT TYPE</option>
                                                   </select> </div>
            
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-gem"></i></span>
                                                    <select onchange="setTitle1(this.value);" class="form-control" id="level1" name="level" required="">
                                                       <option value="" selected="">SELECT LEVEL</option>
                                                   </select></div>
                                                   <div id="subjecttitler1"></div>
                    <div class="table-responsive" style="max-height: 500px; background: #ffffff; color: #000000;">
            <table class="table" style="font-size: 14px !important;">
    
    <tbody id="tablebofy">
     
    </tbody>
            </table>
                    </div>
                </div>
        </div>
    </div>
    </div>
</div>
<script>
      function scheduler()
    {
         $('#scheduleexam').ajaxForm({
      beforeSubmit: function() {
          document.getElementById("successAlert").style.display = "none";
          document.getElementById("errorAlert").style.display = "none";
      },
      
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
        if(myResp == "success")
        {
            document.getElementById("sat").innerHTML = " Exam key successfully set, reloading page in 5 seconds.";
            document.getElementById("successAlert").style.display = "block";
            document.getElementById("errorAlert").style.display = "none";
            
          window.setInterval(function(){window.location.reload();},5000);
        }
        else if(myResp == "s_exist")
        {
            document.getElementById("eat").innerHTML = " Student with such username does not exist for the criterion";
            document.getElementById("successAlert").style.display = "none";
            document.getElementById("errorAlert").style.display = "block";
        }
        else
        {
            document.getElementById("eat").innerHTML = " Oops something went wrong, please make sure to use the date format suggested.";
            document.getElementById("successAlert").style.display = "none";
            document.getElementById("errorAlert").style.display = "block";
        }
      }
      });
    }
        function setType(e)
    {
        document.getElementById("type").value = "";
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/loadkey.php",
        type: "post",
        data: "data=type"+"&department="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("type").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("type").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel(e)
    {
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/loadkey.php",
        type: "post",
        data: "data=level"+"&type="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("level").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("level").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    function setTitle(e)
    {
      
         $.ajax({
        url: "../ajax_to_php_connectors/loadkey.php",
        type: "post",
        data: "data=exams"+"&level="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("subjecttitler").innerHTML = myResp;
          

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    function setRemains(e)
    {
       
         $.ajax({
       url: "../ajax_to_php_connectors/loadkey.php",
        type: "post",
        data: "data=remains"+"&title="+e,
       success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("drem").innerHTML = myResp;
          

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    function setType1(e)
    {
        document.getElementById("type1").value = "";
        document.getElementById("level1").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/loaddel.php",
        type: "post",
        data: "data=type"+"&department="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("type1").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("type1").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel1(e)
    {
        document.getElementById("level1").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/loaddel.php",
        type: "post",
        data: "data=level"+"&type="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("level1").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("level1").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    function setTitle1(e)
    {
         $.ajax({
        url: "../ajax_to_php_connectors/loaddel.php",
        type: "post",
        data: "data=exams"+"&level="+e,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("subjecttitler1").innerHTML = myResp;
          

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    function setRemains1(e)
    {
       
         $.ajax({
       url: "../ajax_to_php_connectors/loaddel.php",
        type: "post",
        data: "data=remains"+"&title="+e,
       success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("tablebofy").innerHTML = myResp;
          

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function sexami(e) 
  {
      
    $('#myschediling'+e).ajaxForm({
      beforeSubmit: function() {
        
      document.getElementById("successAlert4").style.display = "none";
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
          document.getElementById("sat4").innerHTML = "Successfully deleted, refreshing page in 5 seconds.";
          document.getElementById("successAlert4").style.display = "block";
         window.setInterval(function(){window.location.href = "examkey.php";},5000);
      }
      
        });
    }
    </script>
<?php require_once 'footer.php'; ?>