<?php 
$title = "Update Pay";
$active1 = "";
$active2 = "";
$active3 = "";
$active4 = "";
$active5 = "";
$active6 = "";
$active7 = "";
$active8 = "activer";
$active9 = "";
require_once 'header.php'; ?>
<form >
  <script src="https://js.paystack.co/v1/inline.js"></script>
</form>
 
<script>
  function payWithPaystack(e,sn,ti,d,t,l, ph, em){
    var handler = PaystackPop.setup({
      key: 'pk_live_6c845ce84bead3765479a2cb4129355bc3f833c1',
      email: em,
      amount: e,
      currency: "NGN",
      ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      metadata: {
         custom_fields: [
            {
                display_name: sn,
                variable_name: sn,
                value: ph
            }
         ]
      },
      callback: function(e){
          $.ajax({
        url: "../ajax_to_php_connectors/upay.php",
        type: "post",
        data: "resp="+e.reference+"&sn="+sn+"&ti="+ti+"&d="+d+"&t="+t+"&l="+l+"&ph="+ph,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          window.location.href="updatepay.php";

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
          
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }
</script>
<div class="table-responsive" style="max-height: 500px; background: #ffffff; color: #000000;">
            <table class="table" style="font-size: 14px !important;">
    <thead>
      <tr>
          <th style="text-align:center;">#</th>
          <th style="text-align:center;">Title</th>
        <th style="text-align:center;">Department</th>
        <th style="text-align:center;">Type</th>
        <th style="text-align:center;">Level</th>
        <th style="text-align:center;">AMOUNT</th>
        <th style="text-align:center;"></th>
      </tr>
    </thead>
<tbody>
    <?php
    if(count($up) > 0)
    {
        for($i=0; $i<count($up); $i++)
    {
        $ti = $up[$i]['title'];
        $de = $up[$i]['department'];
        $ty = $up[$i]['type'];
        $le = $up[$i]['level'];
        $amount = 100;
        $ph = $useim[0]['schooltelephone'];
        $schemail = $useim[0]['schoolemail'];
        $sss = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $sNo = (int)$sss->execute_count_return("SELECT COUNT(*) FROM students WHERE department='$de' AND type='$ty' AND level='$le'");
        $ex = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
    $ex = $ex->execute_return("SELECT * FROM exam WHERE department='$de' AND type='$ty' AND level='$le' AND title='$ti'");
    if($ex[0]['loaded'] == "false")
    {
        echo '<tr><td style="text-align:center">'.($i+1).'</td><td style="text-align:center">'.$ex[0]['title'].'</td><td style="text-align:center">'.$ex[0]['department'].'</td><td style="text-align:center">'.$ex[0]['type'].'</td><td style="text-align:center">'.$ex[0]['level'].'</td><td style="text-align:center">'.($amount * $sNo).' (Naira)</td><td style="text-align:center"><button class="btn btn-success" type="button" onclick="payWithPaystack(\''.($amount * $sNo).'00\', \''.$_SESSION['school_name'].'\', \''.$ti.'\', \''.$de.'\', \''.$ty.'\', \''.$le.'\', \''.$ph.'\', \''.$schemail.'\')">PAY</button></td></tr>';
    }
    else
    {
         echo '<tr><td style="text-align:center">'.($i+1).'</td><td style="text-align:center">'.$ex[0]['title'].'</td><td style="text-align:center">'.$ex[0]['department'].'</td><td style="text-align:center">'.$ex[0]['type'].'</td><td style="text-align:center">'.$ex[0]['level'].'</td><td style="text-align:center">'.($amount * $sNo).' (Naira)</td><td style="text-align:center">PAID</td></tr>';
   
    }
    }
    }
    else
    {
       echo '<tr><td colspan="6" style="text-align: center;">You have no updates available</td></tr>';
    }
    
    ?>
</tbody>
            </table>
</div>
<?php require_once 'footer.php'; ?>