
<?php 
//dont forget about the delete function for staffs
$title = "Edit Staff";
$active1 = "";
$active2 = "";
$active3 = "activer";
$active4 = "";
$active5 = "";
$active6 = "";
$active7 = "";
$active8 = "";
$active9 = "";
$listOfStaff = "";
if(isset($_POST['submit_staff']))
{
    require_once '../classes/config.php';
    $schoolname = preg_replace('/\s+/', '_', $_POST['schoolname']);
    $email = strtoupper($_POST['search_email']);
    $getStaff = new config($schoolname);
    $getStaff = $getStaff->execute_return("SELECT email FROM staffs WHERE email = '$email' AND root='true' LIMIT 1");
    if(count($getStaff) > 0)
    {
        die(base64_encode($getStaff[0]['email']));
    }
    else
    {
        die("invalid");
    }
    
}
if(isset($_POST['resetstaff']))
{
    session_start();
    if($_POST['surname'] == "" || $_POST['othernames'] == "" || $_POST['email'] == "")
    {
        die("empty");
    }
    else
    {
         $surname = strtoupper($_POST['surname']);
    $othernames = strtoupper($_POST['othernames']);
    $email = strtoupper($_POST['email']);
    $dep = strtoupper($_POST['department']);
    $type = strtoupper($_POST['type']);
    $level = strtoupper($_POST['level']);
    $schoolname = preg_replace('/\s+/', '_', $_SESSION['school_name']);
    require_once '../classes/config.php';
    //check if surname is and other names are qual
    if($_SESSION['stemailer'] == $email)
    {
        //update current staff
        $rand1 = mt_rand();
        $rand2 = mt_rand();
	$rand3 = mt_rand();
	$rand4 = mt_rand();
	$rand5 = mt_rand();
        
                    $password = sha1($surname).sha1($rand1).sha1($rand2).sha1($rand3).sha1($rand4).sha1($rand5);
        $ucst = new config($schoolname);
        $ucst->execute_no_return("UPDATE staffs SET rand1='$rand1', rand2='$rand2', rand3='$rand3', rand4='$rand4', rand5='$rand5', password='$password' WHERE email='$email' AND root='true'");
       
        die("success");
    }
    else
    {
        die("noexist");
    }
    }
    
}
if(isset($_POST['updatestaff']))
{
    session_start();
    if($_POST['surname'] == "" || $_POST['othernames'] == "" || $_POST['email'] == "")
    {
        die("empty");
    }
    else
    {
         $surname = strtoupper($_POST['surname']);
    $othernames = strtoupper($_POST['othernames']);
    $email = strtoupper($_POST['email']);
    $dep = strtoupper($_POST['department']);
    $type = strtoupper($_POST['type']);
    $level = strtoupper($_POST['level']);
    $schoolname = preg_replace('/\s+/', '_', $_SESSION['school_name']);
    require_once '../classes/config.php';
    //check if surname is and other names are qual
    if($_SESSION['stemailer'] == $email)
    {
        //update current staff
        $ucst = new config($schoolname);
        $ucst->execute_no_return("UPDATE staffs SET surname='$surname', othernames='$othernames' WHERE email='$email' AND department='$dep' AND type='$type' AND level='$level' and root='true'");
       
        die("cupdated");
    }
    else
    {
        $pemail = $_SESSION['stemailer'];
        //check if root is set
                    $checkroot = new config($schoolname);
                    $checkroot = $checkroot->execute_return("SELECT * FROM staffs WHERE email='$email' AND root='true'");
                    if(count($checkroot) <= 0)
                    {
                        //check if previous staff is root and if it is greater than 1
                         $checkroot1 = new config($schoolname);
                         $checkroot1 = $checkroot1->execute_return("SELECT * FROM staffs WHERE email='$pemail' AND department='$dep' AND type='$type' AND level='$level'");
                         if($checkroot1[0]['root'] == 'true')
                         {
                             //check if any staff with such email exist in order to transfer ownership
                             $newo = new config($schoolname);
                             $newo = $newo->execute_return("SELECT * FROM staffs WHERE email='$pemail' AND root='false' LIMIT 1");
                             if(count($newo) > 0)
                             {
                                 $nstaff1 = $newo[0]['email'];
                                 $nstaff2 = $newo[0]['department'];
                                 $nstaff3 = $newo[0]['type'];
                                 $nstaff4 = $newo[0]['level'];
                                 $nstaff5 = $checkroot1[0]['rand1'];
                                 $nstaff6 = $checkroot1[0]['rand2'];
                                 $nstaff7 = $checkroot1[0]['rand3'];
                                 $nstaff8 = $checkroot1[0]['rand4'];
                                 $nstaff9 = $checkroot1[0]['rand5'];
                                 $nstaff10 = $checkroot1[0]['password'];
                                  $nstaff11 = $checkroot1[0]['surname'];
                                   $nstaff12 = $checkroot1[0]['othernames'];
                                 //update ownership
                                 $unst = new config($schoolname);
        $unst->execute_no_return("UPDATE staffs SET surname='$nstaff11', othernames='$nstaff12', rand1 = '$nstaff5', rand2 = '$nstaff6', rand3 = '$nstaff7', rand4 = '$nstaff8', rand5 = '$nstaff9', password = '$nstaff10', root = 'true' WHERE email='$nstaff1' AND department='$nstaff2' AND type='$nstaff3' AND level='$nstaff4'");
                    
                             }
                         }
                        $rand1 = mt_rand();
        $rand2 = mt_rand();
	$rand3 = mt_rand();
	$rand4 = mt_rand();
	$rand5 = mt_rand();
        
                    $password = sha1($surname).sha1($rand1).sha1($rand2).sha1($rand3).sha1($rand4).sha1($rand5);
         
             //update new staff
        $unst = new config($schoolname);
        $unst->execute_no_return("UPDATE staffs SET surname='$surname', othernames='$othernames', email='$email', rand1 = '$rand1', rand2 = '$rand2', rand3 = '$rand3', rand4 = '$rand4', rand5 = '$rand5', password = '$password', root = 'true' WHERE email='$pemail' AND department='$dep' AND type='$type' AND level='$level'");
                    
         
           }
                    else
                    {
                         //check if previous staff is root and if it is greater than 1
                         $checkroot1 = new config($schoolname);
                         $checkroot1 = $checkroot1->execute_return("SELECT * FROM staffs WHERE email='$pemail' AND department='$dep' AND type='$type' AND level='$level'");
                         if($checkroot1[0]['root'] == 'true')
                         {
                             //check if any staff with such email exist in order to transfer ownership
                             $newo = new config($schoolname);
                             $newo = $newo->execute_return("SELECT * FROM staffs WHERE email='$pemail' AND root='false' LIMIT 1");
                             if(count($newo) > 0)
                             {
                                 $nstaff1 = $newo[0]['email'];
                                 $nstaff2 = $newo[0]['department'];
                                 $nstaff3 = $newo[0]['type'];
                                 $nstaff4 = $newo[0]['level'];
                                 $nstaff5 = $checkroot1[0]['rand1'];
                                 $nstaff6 = $checkroot1[0]['rand2'];
                                 $nstaff7 = $checkroot1[0]['rand3'];
                                 $nstaff8 = $checkroot1[0]['rand4'];
                                 $nstaff9 = $checkroot1[0]['rand5'];
                                 $nstaff10 = $checkroot1[0]['password'];
                                 $nstaff11 = $checkroot1[0]['surname'];
                                   $nstaff12 = $checkroot1[0]['othernames'];
                                 //update ownership
                                 $unst = new config($schoolname);
        $unst->execute_no_return("UPDATE staffs SET surname='$nstaff11', othernames='$nstaff12', rand1 = '$nstaff5', rand2 = '$nstaff6', rand3 = '$nstaff7', rand4 = '$nstaff8', rand5 = '$nstaff9', password = '$nstaff10', root = 'true' WHERE email='$nstaff1' AND department='$nstaff2' AND type='$nstaff3' AND level='$nstaff4'");
                    
                             }
                         }
                       
            
        $unst = new config($schoolname);
        $unst->execute_no_return("UPDATE staffs SET surname='', othernames='', email='$email', rand1 = '', rand2 = '', rand3 = '', rand4 = '', rand5 = '', password = '', root = 'false' WHERE email='$pemail' AND department='$dep' AND type='$type' AND level='$level'");
                     
        
                       }
        
        die("nupdated");
    }
   
   
       
    
    }
}


require_once 'header.php';



$checktt = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                    $checktt = $checktt->execute_return("SHOW TABLES LIKE 'staffs'");
                    if($checktt != false && count($checktt) > 0)
                    {
                        $getStaffs = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                        $getStaffs = $getStaffs->execute_return("SELECT * FROM `staffs`");
                        if(count($getStaffs) > 0)
                        {
                            $padded = array();
                            $acount = 0;
                            $sn = 0;
                            for($i = 0; $i<count($getStaffs); $i++)
                            {
                                
                                if($getStaffs[$i]['image'] == "null" || $getStaffs[$i]['image'] == "")
                                { 
                                    
                                    if($i > 0)
                                    {
                                        $dis = 0;
                                        for($j = 0; $j<count($padded); $j++)
                                        {
                                            if($getStaffs[$i]['email'] == $padded[$j])
                                        {
                                            $dis = 1;
                                        }
                                        }
                                        
                                        if($dis == 1)
                                        {
                                            continue;
                                        }
                                    }
                                    $sn++;
                                    $listOfStaff .= "<tr><td>".($sn)."</td><td><img class='img-responsive' style='height: 20px; width 20px;' src='images/def.png'/></td><td>".$getStaffs[$i]['email']."</td>";
                                    $dem = $getStaffs[$i]['email'];
                                    $getdep = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getdep = $getdep->execute_return("SELECT department FROM `staffs` where email = '$dem'");
                                    $getty = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getty = $getty->execute_return("SELECT type FROM `staffs` where email = '$dem'");
                                    $getlev = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getlev = $getlev->execute_return("SELECT level FROM `staffs` where email = '$dem'");
                                    $listOfStaff .="<td>";
                                    for($a = 0; $a<count($getdep); $a++)
                                    {
                                        $listOfStaff .= $getdep[$a]['department']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "<td>";
                                    for($b = 0; $b<count($getty); $b++)
                                    {
                                        $listOfStaff .= $getty[$b]['type']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "<td>";
                                    for($c = 0; $c<count($getlev); $c++)
                                    {
                                        $listOfStaff .= $getlev[$c]['level']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "<td><a class='btn btn-primary' href='". htmlspecialchars($_SERVER['PHP_SELF'])."?staffemail=". base64_encode($getStaffs[$i]['email'])."'>Edit</a></td></tr>";
                                
                                    $padded[$acount] = $getStaffs[$i]['email'];
                                    $acount++;
                                    }
                                else
                                {
                                    if($i > 0)
                                    {
                                        $dis = 0;
                                        for($j = 0; $j<count($padded); $j++)
                                        {
                                            if($getStaffs[$i]['email'] == $padded[$j])
                                        {
                                            $dis = 1;
                                        }
                                        }
                                        
                                        if($dis == 1)
                                        {
                                            continue;
                                        }
                                    }
                                    $sn++;
                                    $listOfStaff .= "<tr><td>".($sn)."</td><td><img class='img-responsive' style='height: 30px; width 30px;' src='../staffs/".preg_replace('/\s+/', '_', $_SESSION['school_name'])."/".$getStaffs[$i]['email']."-".$getStaffs[$i]['image'].".png'/></td><td>".$getStaffs[$i]['email']."</td>";
                                    $dem = $getStaffs[$i]['email'];
                                    $getdep = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getdep = $getdep->execute_return("SELECT department FROM `staffs` where email = '$dem'");
                                    $getty = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getty = $getty->execute_return("SELECT type FROM `staffs` where email = '$dem'");
                                    $getlev = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getlev = $getlev->execute_return("SELECT level FROM `staffs` where email = '$dem'");
                                    $listOfStaff .="<td>";
                                    for($a = 0; $a<count($getdep); $a++)
                                    {
                                        $listOfStaff .= $getdep[$a]['department']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "<td>";
                                    for($b = 0; $b<count($getty); $b++)
                                    {
                                        $listOfStaff .= $getty[$b]['type']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "<td>";
                                    for($c = 0; $c<count($getlev); $c++)
                                    {
                                        $listOfStaff .= $getlev[$c]['level']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "<td><a class='btn btn-primary' href='". htmlspecialchars($_SERVER['PHP_SELF'])."?staffemail=". base64_encode($getStaffs[$i]['email'])."'>Edit</a></td></tr>";
                                
                                    $padded[$acount] = $getStaffs[$i]['email'];
                                    $acount++;
                                    
                                        }
                                
                            }
                        }
                        else{
                            $listOfStaff = "<tr><td colspan='7' style='text-align: center;'>No Staff added yet</td></tr>";
                        }
                    }
                    else
                    {
                        $listOfStaff = "<tr><td colspan='7' style='text-align: center;'>No Staff added yet</td></tr>";
                    }
                    
                    
?>

<style>
#successAlert, #successAlert1, #errorAlert, #errorAlert1, #loadering
{
    display: none;
}
</style>
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <div class="alert alert-success" id="successAlert">
                <strong>Success!</strong><span id="sat"></span>
</div>
            <div class="alert alert-danger" id="errorAlert">
                <strong>Error!</strong><span id="eat"></span>
</div>
<div class="card" style="text-align: center;">
                <div class="card-header">
                    <h4>Search Staff to edit</h4>
                </div>
                <div class="card-body">
                     <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="myForm" name="frmupload" method="post" enctype="multipart/form-data">      
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-at"></i></span>
                                                           <input class="form-control" type="hidden" name="schoolname" value="<?php echo $_SESSION['school_name']; ?>" required="" />
                                                           <input class="form-control" type="email" name="search_email" required="" placeholder="staff email" />
                                                                        </div>
                                                                <input class="btn btn-success" id="sim" type="submit" name='submit_staff' value="Search Staff" onclick='search_staff();'/> 
                                                            </form>
 
                </div>
            </div>

        </div>
        
        <div class="col-sm-8">
                        
            
            
            
            
            

<div class="card" id="resultbox">
    <?php 
    $ste = "";
    if(isset($_GET['staffemail']))
                    {
    $ste = "(".base64_decode($_GET['staffemail']).")";
                    }
                    ?>
    <div class="card-header" style="text-align: center; font-weight: bold;">Edit Panel <?php echo $ste; ?></div>
                <div class="card-body" id="result">
                     
                    <?php
                    if(isset($_GET['staffemail']))
                    {
    $staffemail = base64_decode($_GET['staffemail']);
    //check if email exist
    $checkSraff = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
    $checkSraff = $checkSraff->execute_return("SELECT * FROM staffs WHERE email = '$staffemail'");
    if(count($checkSraff) <= 0)
    {
        echo '<div class="card">
                
                <div class="card-body">
                Invalid staff email<br>
                Click on edit button to edit staff or use the search field
            <br>
           
</div>
                </div>';
    }
    else
    {
        
        echo ' 
          
 <div class="alert alert-success" id="successAlert1">
                <strong>Success!</strong><span id="sat1"></span>
</div>
            <div class="alert alert-danger" id="errorAlert1">
                <strong>Error!</strong><span id="eat1"></span>
</div>
            <div class="card">
                
                <div class="card-body">
                    <form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="staffform" name="addstaff" method="post" enctype="multipart/form-data"> 
                        
                                           
                                                           
                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-paper-plane"></i></span>
                                                           <input class="form-control" type="email" name="email" value="'.$checkSraff[0]["email"].'" required="" placeholder="Email" />
                                                                        </div>
                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <select onchange="setType(this.value, \''.$checkSraff[0]["email"].'\');" class="form-control" name="department" required="">
                                                           <option value="" selected>Select Department</option>';
                                                           $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($checkSraff); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($checkSraff[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$checkSraff[$i]["department"].'">'.$checkSraff[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $checkSraff[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
                                                                   if(isset($_SESSION['stemailer']))
                                                                   {
                                                                       unset($_SESSION['stemailer']);
                                                                   }
                                                           $_SESSION['stemailer'] = $checkSraff[0]["email"];
                                                           
        echo '</select>
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list-alt"></i></span>
                                                           <select onchange="setLevel(this.value, \''.$checkSraff[0]["email"].'\');" class="form-control" name="type" required="" id="type">
                                                           <option value="" selected>Select Type</option>
                                                           </select>
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <select onchange="setNames(this.value,\''.$checkSraff[0]["email"].'\');" class="form-control" name="level" required="" id="level">
                                                           <option value="" selected>Select Level</option>
                                                           </select>
                                                                        </div>
                                                                        
                                                             <div id="appender">
                                                             
</div>

                                                            
                                                            </form>
            <br>
           
</div>
                </div>
           
';
    }
                    }
                    else
                    {
                        echo '<div class="card">
                
                <div class="card-body">
                Click on edit button to edit staff or use the search field
            <br>
           
</div>
                </div>';
                    }
                    ?>
                    
                </div>
            </div>
            
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="table-responsive" style="max-height: 500px; background: #ffffff; color: #000000;">
                <table class="table" style="font-size: 14px !important;">
    <thead>
      <tr>
        <th>#</th>
        <th>im</th>
        <th>Email</th>
        <th>Dep</th>
        <th>type</th>
        <th>level</th>
        <th>Edit</th>
      </tr>
    </thead>
    <tbody>
      <?php echo $listOfStaff; ?>
    </tbody>
  </table>
            </div>
    </div>
</div>
<script>
    var dis = "";
    function setType(e,b)
    {
        document.getElementById("type").value = "";
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getstaffdetails.php",
        type: "post",
        data: "data=type"+"&department="+e+"&staffemail="+b,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("type").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("type").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel(e,b)
    {
        document.getElementById("level").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getstaffdetails.php",
        type: "post",
        data: "data=level"+"&type="+e+"&staffemail="+b,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("level").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("level").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setNames(l,b)
    {
         
         $.ajax({
        url: "../ajax_to_php_connectors/getstaffdetails.php",
        type: "post",
        data: "data=names"+"&staffemail="+b+"&level="+l,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
            if(dis != "")
            {
                 var ele = document.getElementById("appender");
             ele.removeChild(document.getElementById("surnamer"));
               ele.removeChild(document.getElementById("othernamers"));
               ele.removeChild(document.getElementById("sending"));
               dis = "";
            }
               document.getElementById("appender").innerHTML += myResp;
               dis = "sett";
           
          

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    function search_staff() 
  {
      
    $('#myForm').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "none";
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
        if(myResp == "invalid")
        {
            document.getElementById("eat").innerHTML = " Email does not exist";
            document.getElementById("errorAlert").style.display = "block";
        }
        else
        {
            document.getElementById("sat").innerHTML = " Email exist, updating edit panel in 5 seconds.";
            document.getElementById("successAlert").style.display = "block";
            window.setInterval(function(){window.location.href = 'editstaff.php?staffemail='+myResp;},5000);
        }
      }
    }); 
  }
  
  function resetstaffer()
  {
      $('#staffform').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert1").style.display = "none";
      document.getElementById("successAlert1").style.display = "none";
      document.getElementById("loadering").style.display = "block";
      document.getElementById("sima").style.display = "none";
      document.getElementById("simar").style.display = "none";
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
       if(myResp == "empty")
        {
            
            document.getElementById("eat1").innerHTML = " All field must be filled.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
      document.getElementById("simar").style.display = "block";
        }
        
        else if(myResp == "noexist")
        {
            document.getElementById("eat1").innerHTML = " Staff selection does not exist, To reset staff click on the staff's edit button and click the reset button.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
      document.getElementById("simar").style.display = "block";
            
        }
        else if(myResp == "success")
        {
            
            document.getElementById("sat1").innerHTML = " Staff's password has successfully been set to  default, refreshing page in 5seconds";
            document.getElementById("successAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
            document.getElementById("sima").style.display = "block";
            document.getElementById("simar").style.display = "block";
            window.setTimeout(function(){window.location.href="editstaff.php";},5000);
        }
        else
        {
            document.getElementById("eat1").innerHTML = " Occured, please refresh the page and try again.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
      document.getElementById("simar").style.display = "block";
        }
      }
    }); 
  }
  function updatestaffs() 
  {
    $('#staffform').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert1").style.display = "none";
      document.getElementById("successAlert1").style.display = "none";
      document.getElementById("loadering").style.display = "block";
      document.getElementById("sima").style.display = "none";
      document.getElementById("simar").style.display = "none";
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
       if(myResp == "empty")
        {
            
            document.getElementById("eat1").innerHTML = " All field must be filled.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
      document.getElementById("simar").style.display = "block";
        }
        
        else if(myResp == "cupdated")
        {
            
            document.getElementById("sat1").innerHTML = " Current Staff successfully updated, refreshing page in 5seconds";
            document.getElementById("successAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
            document.getElementById("sima").style.display = "block";
            document.getElementById("simar").style.display = "block";
            window.setTimeout(function(){window.location.reload()},5000);
        }
        else if(myResp == "nupdated")
        {
            
            document.getElementById("sat1").innerHTML = " New Staff successfully updated, refreshing page in 5seconds";
            document.getElementById("successAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
            document.getElementById("sima").style.display = "block";
            document.getElementById("simar").style.display = "block";
            window.setTimeout(function(){window.location.href="editstaff.php";},5000);
        }
        else
        {
            document.getElementById("eat1").innerHTML = " Occured, please refresh the page and try again.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
      document.getElementById("simar").style.display = "block";
        }
      }
    }); 
  }
    </script>
<?php 

require_once 'footer.php';

?>
   