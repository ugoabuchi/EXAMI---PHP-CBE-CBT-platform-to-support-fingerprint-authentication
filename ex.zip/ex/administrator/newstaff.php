<?php 
$title = "New Staff";
$active1 = "";
$active2 = "activer";
$active3 = "";
$active4 = "";
$active5 = "";
$active6 = "";
$active7 = "";
$active8 = "";
$active9 = "";
$listOfStaff = "";
if(isset($_POST['addstaffer']))
{
    $surname = strtoupper($_POST['surname']);
    $othernames = strtoupper($_POST['othernames']);
    $email = strtoupper($_POST['email']);
    $dep = strtoupper($_POST['department']);
    $type = strtoupper($_POST['type']);
    $level = strtoupper($_POST['level']);
    $schoolname = preg_replace('/\s+/', '_', $_POST['schoolname1']);
    require_once '../classes/config.php';
    //check table rxist
                    $checkt = new config($schoolname);
                    $checkt = $checkt->execute_return("SHOW TABLES LIKE 'staffs'");
    if($checkt == false && count($checkt) <= 0)
                    {
                        //Create table
                        $staffsCreate = new config($schoolname);
                        $staffsCreate->execute_no_return("CREATE TABLE `staffs` (
  `id` int(16) NOT NULL,
  `image` varchar(150) NULL,
  `surname` varchar(150) NULL,
  `othernames` varchar(150) NULL,
  `email` varchar(150) NOT NULL,
  `department` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `level` varchar(150) NOT NULL,
  `rand1` varchar(150) NULL,
  `rand2` varchar(150) NULL,
  `rand3` varchar(150) NULL,
  `rand4` varchar(150) NULL,
  `rand5` varchar(150) NULL,
  `password` text NULL,
  `root` varchar(150) NOT NULL,
  `dor` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
                        
                        //Alter table set primary key and unique keys
                        $staffsAlter = new config($schoolname);
                        $staffsAlter->execute_no_return("ALTER TABLE `staffs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`department`,`type`,`level`);");
                        $staffsAlter1 = new config($schoolname);
                        $staffsAlter1->execute_no_return("ALTER TABLE `staffs`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT;");
                        
                    }
                    
                    //check if department and level already exist
                    $checkstaff = new config($schoolname);
                    $checkstaff = $checkstaff->execute_count_no_return("SELECT COUNT(*) FROM staffs WHERE department = '$dep' AND type = '$type' AND level = '$level'");
                    if($checkstaff == 1)
                    {
                        die("taken");
                    }
                     else
                     {
                         //check if root is set
                    $checkroot = new config($schoolname);
                    $checkroot = $checkroot->execute_count_no_return("SELECT COUNT(*) FROM staffs WHERE email='$email' AND root='true'");
                    if($checkroot == 0)
                    {
                        $rand1 = mt_rand();
                         $rand2 = mt_rand();
                         $rand3 = mt_rand();
                         $rand4 = mt_rand();
                         $rand5 = mt_rand();
        
 
                   
                    $password = sha1($surname).sha1($rand1).sha1($rand2).sha1($rand3).sha1($rand4).sha1($rand5);
                   
                         $saveStaff = new config($schoolname);
                 $saveStaff->execute_no_return("INSERT INTO `staffs`(`surname`, `othernames`, `email`, `department`, `type`, `level`, `rand1`, `rand2`, `rand3`, `rand4`, `rand5`, `password`, `root`, `dor`) VALUES ('$surname','$othernames','$email','$dep','$type','$level','$rand1','$rand2','$rand3','$rand4','$rand5','$password', 'true',now())");
                         
                    }
                    else
                    {
                 $saveStaff = new config($schoolname);
                 $saveStaff->execute_no_return("INSERT INTO `staffs`(`email`, `department`, `type`, `level`, `root`, `dor`) VALUES ('$email','$dep','$type','$level','false',now())");
                    }
                         die("success");
                     }
    
}
if(isset($_POST['submit_image']))
{
  $fileinfo = @getimagesize($_FILES["upload_file"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "CSV"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["upload_file"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'invalidf';
        exit();
    } 
    
 else {
     $filename=$_FILES["upload_file"]["tmp_name"];		
 
 
		 if($_FILES["upload_file"]["size"] > 0)
		 {
                     require_once '../classes/config.php';
                     $schoolname = preg_replace('/\s+/', '_', $_POST['schoolname']);
                     $empties = null;
                     $loaded = null;
                      //check table rxist
                    $checkt = new config($schoolname);
                    $checkt = $checkt->execute_return("SHOW TABLES LIKE 'staffs'");
                    if($checkt == false && count($checkt) <= 0)
                    {
                        //Create table
                        $staffsCreate = new config($schoolname);
                        $staffsCreate->execute_no_return("CREATE TABLE `staffs` (
  `id` int(16) NOT NULL,
  `image` varchar(150) NULL,
  `surname` varchar(150) NULL,
  `othernames` varchar(150) NULL,
  `email` varchar(150) NOT NULL,
  `department` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `level` varchar(150) NOT NULL,
  `rand1` varchar(150) NULL,
  `rand2` varchar(150) NULL,
  `rand3` varchar(150) NULL,
  `rand4` varchar(150) NULL,
  `rand5` varchar(150) NULL,
  `password` text NULL,
  `root` varchar(150) NOT NULL,
  `dor` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
                        
                        //Alter table set primary key and unique keys
                        $staffsAlter = new config($schoolname);
                        $staffsAlter->execute_no_return("ALTER TABLE `staffs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`department`,`type`,`level`);");
                        $staffsAlter1 = new config($schoolname);
                        $staffsAlter1->execute_no_return("ALTER TABLE `staffs`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT;");
                        
                    }
		  	$file = fopen($filename, "r");
	        while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
	         {
                    
                    //checking for empty field in CSV
                    if($getData[0] == "" || $getData[1] == "" || $getData[2] == "" || $getData[3] == "" || $getData[4] == "" || $getData[5] == "")
                    {
                        if($empties == null)
                        {
                            $empties = array($getData);
                        }
                        else
                        {
                            $empties = array_merge($empties, array($getData));
                        }
                    }
                    else
                    {
                        if($loaded == null)
                        {
                            $loaded = array($getData);
                        }
                        else
                        {
                            $loaded = array_merge($loaded, array($getData));
                        }
                    }
                    
	         }
			
	         fclose($file);
                 if($empties != null)
                 {
                      echo 'emptyd';
                     exit();
                 }
                 //check if department and level already exist
                 foreach ($loaded as $loader)
                 {
                    $surname = strtoupper(trim($loader[0]));
                    $othernames = strtoupper(trim($loader[1]));
                    $email = strtoupper(trim($loader[2]));
                    $department = strtoupper(trim($loader[3]));
                    $type = strtoupper(trim($loader[4]));
                    $level = strtoupper(trim($loader[5]));
        
                    
                    $checkstaff = new config($schoolname);
                    $checkstaff = $checkstaff->execute_count_no_return("SELECT COUNT(*) FROM staffs WHERE department = '$department' AND type = '$type' AND level = '$level'");
                    if($checkstaff == 1)
                    {
                        die("taken");
                    }
                 }
                 
                 //save satfff
                 foreach ($loaded as $loader)
                 {
                    $surname = strtoupper(trim($loader[0]));
                    $othernames = strtoupper(trim($loader[1]));
                    $email = strtoupper(trim($loader[2]));
                    $department = strtoupper(trim($loader[3]));
                    $type = strtoupper(trim($loader[4]));
                    $level = strtoupper(trim($loader[5]));
        
                    //check if root is set
                    $checkroot = new config($schoolname);
                    $checkroot = $checkroot->execute_count_no_return("SELECT COUNT(*) FROM staffs WHERE email='$email' AND root='true'");
                    if($checkroot == 0)
                    {
                        $rand1 = mt_rand();
                         $rand2 = mt_rand();
                         $rand3 = mt_rand();
                         $rand4 = mt_rand();
                         $rand5 = mt_rand();
        
 
                   
                    $password = sha1($surname).sha1($rand1).sha1($rand2).sha1($rand3).sha1($rand4).sha1($rand5);
                   
                         $saveStaff = new config($schoolname);
                 $saveStaff->execute_no_return("INSERT INTO `staffs`(`surname`, `othernames`, `email`, `department`, `type`, `level`, `rand1`, `rand2`, `rand3`, `rand4`, `rand5`, `password`, `root`, `dor`) VALUES ('$surname','$othernames','$email','$department','$type','$level','$rand1','$rand2','$rand3','$rand4','$rand5','$password', 'true',now())");
                         
                    }
                    else
                    {
                 $saveStaff = new config($schoolname);
                 $saveStaff->execute_no_return("INSERT INTO `staffs`(`email`, `department`, `type`, `level`, `root`, `dor`) VALUES ('$email','$department','$type','$level','false',now())");
                    }
                     
                     
                 }
                 die("success");
		 }
                 else
                 {
                     echo 'emptyf';
                     exit();
                 }
    }
  
}
require_once 'header.php'; 
$checktt = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                    $checktt = $checktt->execute_return("SHOW TABLES LIKE 'staffs'");
                    if($checktt != false && count($checktt) > 0)
                    {
                        $getStaffs = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                        $getStaffs = $getStaffs->execute_return("SELECT * FROM `staffs`");
                        if(count($getStaffs) > 0)
                        {
                            $padded = array();
                            $acount = 0;
                            $sn = 0;
                            for($i = 0; $i<count($getStaffs); $i++)
                            {
                                
                                if($getStaffs[$i]['image'] == "null" || $getStaffs[$i]['image'] == "")
                                { 
                                    
                                    if($i > 0)
                                    {
                                        $dis = 0;
                                        for($j = 0; $j<count($padded); $j++)
                                        {
                                            if($getStaffs[$i]['email'] == $padded[$j])
                                        {
                                            $dis = 1;
                                        }
                                        }
                                        
                                        if($dis == 1)
                                        {
                                            continue;
                                        }
                                    }
                                    $sn++;
                                    $listOfStaff .= "<tr><td>".($sn)."</td><td><img class='img-responsive' style='height: 20px; width 20px;' src='images/def.png'/></td><td>".$getStaffs[$i]['email']."</td>";
                                    $dem = $getStaffs[$i]['email'];
                                    $getdep = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getdep = $getdep->execute_return("SELECT department FROM `staffs` where email = '$dem'");
                                    $getty = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getty = $getty->execute_return("SELECT type FROM `staffs` where email = '$dem'");
                                    $getlev = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getlev = $getlev->execute_return("SELECT level FROM `staffs` where email = '$dem'");
                                    $listOfStaff .="<td>";
                                    for($a = 0; $a<count($getdep); $a++)
                                    {
                                        $listOfStaff .= $getdep[$a]['department']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "<td>";
                                    for($b = 0; $b<count($getty); $b++)
                                    {
                                        $listOfStaff .= $getty[$b]['type']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "<td>";
                                    for($c = 0; $c<count($getlev); $c++)
                                    {
                                        $listOfStaff .= $getlev[$c]['level']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "</tr>";
                                
                                    $padded[$acount] = $getStaffs[$i]['email'];
                                    $acount++;
                                    }
                                else
                                {
                                    if($i > 0)
                                    {
                                        $dis = 0;
                                        for($j = 0; $j<count($padded); $j++)
                                        {
                                            if($getStaffs[$i]['email'] == $padded[$j])
                                        {
                                            $dis = 1;
                                        }
                                        }
                                        
                                        if($dis == 1)
                                        {
                                            continue;
                                        }
                                    }
                                    $sn++;
                                    $listOfStaff .= "<tr><td>".($sn)."</td><td><img class='img-responsive' style='height: 30px; width 30px;' src='../staffs/".preg_replace('/\s+/', '_', $_SESSION['school_name'])."/".$getStaffs[$i]['email']."-".$getStaffs[$i]['image'].".png'/></td><td>".$getStaffs[$i]['email']."</td>";
                                    $dem = $getStaffs[$i]['email'];
                                    $getdep = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getdep = $getdep->execute_return("SELECT department FROM `staffs` where email = '$dem'");
                                    $getty = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getty = $getty->execute_return("SELECT type FROM `staffs` where email = '$dem'");
                                    $getlev = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                                    $getlev = $getlev->execute_return("SELECT level FROM `staffs` where email = '$dem'");
                                    $listOfStaff .="<td>";
                                    for($a = 0; $a<count($getdep); $a++)
                                    {
                                        $listOfStaff .= $getdep[$a]['department']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "<td>";
                                    for($b = 0; $b<count($getty); $b++)
                                    {
                                        $listOfStaff .= $getty[$b]['type']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "<td>";
                                    for($c = 0; $c<count($getlev); $c++)
                                    {
                                        $listOfStaff .= $getlev[$c]['level']."<br>";
                                    }
                                    $listOfStaff .= "</td>";
                                    $listOfStaff .= "</tr>";
                                
                                    $padded[$acount] = $getStaffs[$i]['email'];
                                    $acount++;
                                    
                                        }
                                
                            }
                        }
                        else{
                            $listOfStaff = "<tr><td colspan='7' style='text-align: center;'>No Staff added yet</td></tr>";
                        }
                    }
                    else
                    {
                        $listOfStaff = "<tr><td colspan='7' style='text-align: center;'>No Staff added yet</td></tr>";
                    }


?>
<style>
    .progress {text-align:left;margin-top:20px;display:none; position:relative; width:100%; border: 1px solid #ddd; padding: 1px; border-radius: 3px; }
.bar { background-color:#2E64FE; width:0%; height:30px; border-radius: 3px; }
.percent { position:absolute; display:inline-block; left:48%; top: 0px; bottom: 2px; color: #ffffff; font-weight: bold; }
#out
{
  margin-top:20px;
  width:300px;
}
#successAlert, #successAlert1, #errorAlert, #errorAlert1, #loadering
{
    display: none;
}
</style>
<div class="container">
    <div class="row">
        <div class="col-sm-7" style="text-align: center;">
            <div class="panel panel-default" style="text-align: justify;">
                <div class="panel-heading" style="text-align: center; font-weight: bold;">How to use the CSV uploader</div>
  <div class="panel-body">
      <p> 1.    Make sure CSV fields are in the form, SURNAME, OTHERNAMES, EMAIL, DEPARTMENT, TYPE, LEVEL.</p>
      
      <p>2.    Open your Excel file and click Save As. Choose to save it as a .CSV (Comma Separated) file. If you are running Excel on a Mac, you will need to save the file as a Windows Comma Separated (.csv) or CSV (Windows) to maintain the correct formatting</p>
  </div>
</div>
            <div class="alert alert-success" id="successAlert">
                <strong>Success!</strong><span id="sat"></span>
</div>
            <div class="alert alert-danger" id="errorAlert">
                <strong>Error!</strong><span id="eat"></span>
</div>
            <div class="card">
                <div class="card-header">
                    <h4>Upload a list of Staff CSV document</h4>
                </div>
                <div class="card-body">
                     <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="myForm" name="frmupload" method="post" enctype="multipart/form-data">      
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-upload"></i></span>
                                                           <input class="form-control" type="hidden" name="schoolname" value="<?php echo $_SESSION['school_name']; ?>" required="" />
                                                           <input class="form-control" type="file" accept=".csv" id="upload_file" name="upload_file" required="" />
                                                                        </div>
                                                                <input class="btn btn-success" id="sim" type="submit" name='submit_image' value="Upload CSV" onclick='upload_image();'/> 
                                                            </form>
            <br>
            <div class='progress' id="progress_div">
<div class='bar' id='bar'></div>
<div class='percent' id='percent'>0%</div>
</div>
                </div>
            </div>
        </div>
        <div class="col-sm-5" style="text-align: center;">
            <div class="alert alert-success" id="successAlert1">
                <strong>Success!</strong><span id="sat1"></span>
</div>
            <div class="alert alert-danger" id="errorAlert1">
                <strong>Error!</strong><span id="eat1"></span>
</div>
            <div class="card">
                <div class="card-header">
                    <h4 style="text-align: center;">Add Staff</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="staffform" name="addstaff" method="post" enctype="multipart/form-data">      
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <input class="form-control" type="hidden" name="schoolname1" value="<?php echo $_SESSION['school_name']; ?>" required="" />
                                                           <span class="input-group-addon"><i class="fa fa-edit"></i></span>
                                                           <input class="form-control" type="text" name="surname" required="" placeholder="Surname" />
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-edit"></i></span>
                                                           <input class="form-control" type="text" name="othernames" required="" placeholder="Othernames" />
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-paper-plane"></i></span>
                                                           <input class="form-control" type="text" name="email" required="" placeholder="Email" />
                                                                        </div>
                                                            
                                                           <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <input class="form-control" type="text" name="department" required="" placeholder="Department" />
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list-alt"></i></span>
                                                           <input class="form-control" type="text" name="type" required="" placeholder="Type" />
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <input class="form-control" type="text" name="level" required="" placeholder="Level" />
                                                                        </div>
                         <div id="loadering"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success" id="sima" type="submit" name='addstaffer' onclick="addstafff();" value="Add Staff"/> 
                                                            </form>
            <br>
            <div class='progress' id="progress_div">
<div class='bar' id='bar'></div>
<div class='percent' id='percent'>0%</div>
</div>
                </div>
            </div>
        </div>
        <div class="table-responsive" style="max-height: 500px; background: #ffffff; color: #000000;">
            <table class="table" style="font-size: 14px !important;">
    <thead>
      <tr>
        <th>#</th>
        <th>im</th>
        <th>Email</th>
        <th>Dep</th>
        <th>type</th>
        <th>level</th>
      </tr>
    </thead>
    <tbody>
      <?php echo $listOfStaff; ?>
    </tbody>
  </table>
            </div>
    </div>
</div>
<script>
  function upload_image() 
  {
      
      document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "none";
    var bar = $('#bar');
    var percent = $('#percent');
    
    $('#myForm').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("progress_div").style.display="block";
        var percentVal = '0%';
        bar.width(percentVal);
        percent.html(percentVal);
      },
      uploadProgress: function(event, position, total, percentComplete) {
        var percentVal = percentComplete + '%';
        bar.width(percentVal);
        percent.html(percentVal);
      },
      success: function() {
        var percentVal = '100%';
        bar.width(percentVal);
        percent.html(percentVal);
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
        if(myResp == "invalidf")
        {
            
            document.getElementById("eat").innerHTML = " File is not a CSV";
            document.getElementById("errorAlert").style.display = "block";
            
        }
        else if(myResp == "success")
        {
             document.getElementById("sat").innerHTML = " CSV upload completed, refreshing page in 5seconds";
            document.getElementById("successAlert").style.display = "block";
            window.setTimeout(function(){window.location.href="newstaff.php";},5000);
        }
        else  if(myResp == "emptyf")
        {
            
            document.getElementById("eat").innerHTML = " File is empty";
            document.getElementById("errorAlert").style.display = "block";
            
        }
        else  if(myResp == "emptyd")
        {
            
            document.getElementById("eat").innerHTML = " CSV contains empty data, please correct the CSV file";
            document.getElementById("errorAlert").style.display = "block";
            
        }
        else  if(myResp == "taken")
        {
            
            document.getElementById("eat").innerHTML = " Department, Type and Level is already registered with a staff, Cross check staff CSV with the List shown.";
            document.getElementById("errorAlert").style.display = "block";
            
        }
        else
        {
            document.getElementById("eat").innerHTML = " Invalid upload file";
            document.getElementById("errorAlert").style.display = "block";
        }
      }
    }); 
  }
  
    function addstafff() 
  {
    $('#staffform').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert1").style.display = "none";
      document.getElementById("successAlert1").style.display = "none";
      document.getElementById("loadering").style.display = "block";
      document.getElementById("sima").style.display = "none";
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, ''));
       if(myResp == "taken")
        {
            
            document.getElementById("eat1").innerHTML = " Department, Type and Level is already registered with a staff, Cross check staff details with the List shown.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
        }
        else if(myResp == "success")
        {
            
            document.getElementById("sat1").innerHTML = " Staff added, refreshing page in 5seconds";
            document.getElementById("successAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
            document.getElementById("sima").style.display = "block";
            window.setTimeout(function(){window.location.href="newstaff.php";},5000);
        }
        else
        {
            document.getElementById("eat1").innerHTML = " Occured, please refresh the page and try again.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
        }
      }
    }); 
  }
</script> 
<?php require_once 'footer.php'; ?>
