<?php 
$title = "New Student";
$active1 = "";
$active2 = "";
$active3 = "";
$active4 = "activer";
$active5 = "";
$active6 = "";
$active7 = "";
$active8 = "";
$active9 = "";
$listOfStudents = "<tr><td colspan='3' style='text-align: center;'>Select department, level, and type to view student</td></tr>";

if(isset($_POST['getstud']))
{
    $listOfStudents = "";
    $depr = strtoupper($_POST['departmentv']);
    $tyy = strtoupper($_POST['typev']);
    $levv = strtoupper($_POST['levelv']);
    require_once '../classes/config.php';
    $schoolname = preg_replace('/\s+/', '_', $_POST['studentschool']);
    $getSt = new config($schoolname);
    $getSt = $getSt->execute_return("SELECT username FROM students WHERE department = '$depr' AND type = '$tyy' AND level = '$levv'");
    if(count($getSt) > 0)
    {
        for($i = 0; $i<count($getSt); $i++)
    {
           $listOfStudents .= '<tr><td style="text-align:center;">'.($i+1).'</td><td style="text-align:center;"><img class="img-responsive" style="height: 20px; width 20px;" src="images/def.png"/></td><td style="text-align:center;">'.$getSt[$i]["username"].'</td></tr>';
    }
    }
    else
    {
        $listOfStudents = "<tr><td colspan='3' style='text-align: center;'>Selection does not have a student/td></tr>";
    }
    
    die($listOfStudents);
}
if(isset($_POST['addstaffer']))
{
    $surname = strtoupper($_POST['surname']);
    $othernames = strtoupper($_POST['othernames']);
    $username = strtoupper($_POST['username']);
    $depa = strtoupper($_POST['department']);
    $type = strtoupper($_POST['type']);
    $level = strtoupper($_POST['level']);
    $schoolname = preg_replace('/\s+/', '_', $_POST['schoolname1']);
    require_once '../classes/config.php';
    //check table rxist
                    $checkt = new config($schoolname);
                    $checkt = $checkt->execute_return("SHOW TABLES LIKE 'students'");
    if($checkt == false && count($checkt) <= 0)
                    {
                        //Create table
                        $staffsCreate = new config($schoolname);
                        $staffsCreate->execute_no_return("CREATE TABLE `students` (
  `id` int(16) NOT NULL,
  `surname` varchar(150) NOT NULL,
  `othernames` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `department` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `level` varchar(150) NOT NULL,
  `rand1` varchar(150) NOT NULL,
  `rand2` varchar(150) NOT NULL,
  `rand3` varchar(150) NOT NULL,
  `rand4` varchar(150) NOT NULL,
  `rand5` varchar(150) NOT NULL,
  `password` text NOT NULL,
  `fingerprint` text NULL,
  `dor` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
                        
                        //Alter table set primary key and unique keys
                        $staffsAlter = new config($schoolname);
                        $staffsAlter->execute_no_return("ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY (`username`);");
                        $staffsAlter1 = new config($schoolname);
                        $staffsAlter1->execute_no_return("ALTER TABLE `students`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT;");
                        
                    }
                    
                    $checkstaff = new config($schoolname);
                    $checkstaff = $checkstaff->execute_count_no_return("SELECT COUNT(*) FROM students WHERE username = '$username'");
                    if($checkstaff == 1)
                    {
                        die("taken");
                    }
                     //check department exist
                    $dep  =  new config($schoolname);
                    $dep = $dep->execute_return("SELECT * FROM staffs WHERE department = '$depa'");
                    if($dep == 0)
                    {
                        die("depNexist");
                    }
                    $typ  =  new config($schoolname);
                    $typ = $typ->execute_count_no_return("SELECT COUNT(*) FROM staffs WHERE type = '$type'");
                    if($typ == 0)
                    {
                        die("typNexist");
                    }
                    $lev  =  new config($schoolname);
                    $lev = $lev->execute_count_no_return("SELECT COUNT(*) FROM staffs WHERE level = '$level'");
                    if($lev == 0)
                    {
                        die("levNexist");
                    }
                    
                    $rand1 = mt_rand();
                         $rand2 = mt_rand();
                         $rand3 = mt_rand();
                         $rand4 = mt_rand();
                         $rand5 = mt_rand();
        
 
                   
                    $password = sha1($surname).sha1($rand1).sha1($rand2).sha1($rand3).sha1($rand4).sha1($rand5);
                     
                        $saveStaff = new config($schoolname);
                 $saveStaff->execute_no_return("INSERT INTO `students`(`surname`, `othernames`, `username`, `department`, `type`, `level`, `rand1`, `rand2`, `rand3`, `rand4`, `rand5`, `password`, `dor`) VALUES ('$surname','$othernames','$username','$depa','$type','$level','$rand1','$rand2','$rand3','$rand4','$rand5','$password',now())");
                     
                         die("success");
                     
    
}
if(isset($_POST['submit_image']))
{
  $fileinfo = @getimagesize($_FILES["upload_file"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "CSV"
    );
    
    $file_extension = strtoupper(pathinfo($_FILES["upload_file"]["name"], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_image_extension)) {
        echo 'invalidf';
        exit();
    } 
    
 else {
     $filename=$_FILES["upload_file"]["tmp_name"];		
 
 
		 if($_FILES["upload_file"]["size"] > 0)
		 {
                     require_once '../classes/config.php';
                     $schoolname = preg_replace('/\s+/', '_', $_POST['schoolname']);
                     $empties = null;
                     $loaded = null;
                      //check table rxist
                    $checkt = new config($schoolname);
                    $checkt = $checkt->execute_return("SHOW TABLES LIKE 'students'");
                    if($checkt == false && count($checkt) <= 0)
                    {
                        //Create table
                        $staffsCreate = new config($schoolname);
                        $staffsCreate->execute_no_return("CREATE TABLE `students` (
  `id` int(16) NOT NULL,
  `surname` varchar(150) NOT NULL,
  `othernames` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `department` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `level` varchar(150) NOT NULL,
  `rand1` varchar(150) NOT NULL,
  `rand2` varchar(150) NOT NULL,
  `rand3` varchar(150) NOT NULL,
  `rand4` varchar(150) NOT NULL,
  `rand5` text NOT NULL,
  `password` varchar(150) NOT NULL,
  `dor` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
                        
                        //Alter table set primary key and unique keys
                        $staffsAlter = new config($schoolname);
                        $staffsAlter->execute_no_return("ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY (`username`);");
                        $staffsAlter1 = new config($schoolname);
                        $staffsAlter1->execute_no_return("ALTER TABLE `students`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT;");
                        
                    }
		  	$file = fopen($filename, "r");
	        while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
	         {
                    
                    //checking for empty field in CSV
                    if($getData[0] == "" || $getData[1] == "" || $getData[2] == "" || $getData[3] == "" || $getData[4] == "" || $getData[5] == "")
                    {
                        if($empties == null)
                        {
                            $empties = array($getData);
                        }
                        else
                        {
                            $empties = array_merge($empties, array($getData));
                        }
                    }
                    else
                    {
                        if($loaded == null)
                        {
                            $loaded = array($getData);
                        }
                        else
                        {
                            $loaded = array_merge($loaded, array($getData));
                        }
                    }
                    
	         }
			
	         fclose($file);
                 if($empties != null)
                 {
                      echo 'emptyd';
                     exit();
                 }
                 
                  //check if department and level already exist
                 foreach ($loaded as $loader)
                 {
                    
                    $username = strtoupper(trim($loader[2]));
                    $department = strtoupper(trim($loader[3]));
                    $type = strtoupper(trim($loader[4]));
                    $level = strtoupper(trim($loader[5]));
        
                   
                    $checkstaff = new config($schoolname);
                    $checkstaff = $checkstaff->execute_count_no_return("SELECT COUNT(*) FROM students WHERE username = '$username'");
                    if($checkstaff == 1)
                    {
                        die("taken");
                    }
                    
                      //check department exist
                    $dep  =  new config($schoolname);
                    $dep = $dep->execute_return("SELECT * FROM staffs WHERE department = '$department'");
                    if($dep == 0)
                    {
                        die("depNexist");
                    }
                    $typ  =  new config($schoolname);
                    $typ = $typ->execute_count_no_return("SELECT COUNT(*) FROM staffs WHERE type = '$type'");
                    if($typ == 0)
                    {
                        die("typNexist");
                    }
                    $lev  =  new config($schoolname);
                    $lev = $lev->execute_count_no_return("SELECT COUNT(*) FROM staffs WHERE level = '$level'");
                    if($lev == 0)
                    {
                        die("levNexist");
                    }
                 }
                 
                 //save student
                 foreach ($loaded as $loader)
                 {
                    $surname = strtoupper(trim($loader[0]));
                    $othernames = strtoupper(trim($loader[1]));
                    $username = strtoupper(trim($loader[2]));
                    $department = strtoupper(trim($loader[3]));
                    $type = strtoupper(trim($loader[4]));
                    $level = strtoupper(trim($loader[5]));
                  
                    
                         $rand1 = mt_rand();
                         $rand2 = mt_rand();
                         $rand3 = mt_rand();
                         $rand4 = mt_rand();
                         $rand5 = mt_rand();
        
 
                   
                    $password = sha1($surname).sha1($rand1).sha1($rand2).sha1($rand3).sha1($rand4).sha1($rand5);
                   
                         $saveStaff = new config($schoolname);
                 $saveStaff->execute_no_return("INSERT INTO `students`(`surname`, `othernames`, `username`, `department`, `type`, `level`, `rand1`, `rand2`, `rand3`, `rand4`, `rand5`, `password`, `dor`) VALUES ('$surname','$othernames','$username','$department','$type','$level','$rand1','$rand2','$rand3','$rand4','$rand5','$password',now())");
                     
                 }
                 die("success");
		 }
                 else
                 {
                     echo 'emptyf';
                     exit();
                 }
    }
  
}

require_once 'header.php'; 



?>
<style>
    .progress {text-align:left;margin-top:20px;display:none; position:relative; width:100%; border: 1px solid #ddd; padding: 1px; border-radius: 3px; }
.bar { background-color:#2E64FE; width:0%; height:30px; border-radius: 3px; }
.percent { position:absolute; display:inline-block; left:48%; top: 0px; bottom: 2px; color: #ffffff; font-weight: bold; }
#out
{
  margin-top:20px;
  width:300px;
}
#successAlert, #successAlert1, #errorAlert, #errorAlert1, #loadering,  #successAlertv, #errorAlertv, #loaderingv
{
    display: none;
}
</style>
<div class="container">
    <div class="row">
        <div class="col-sm-7" style="text-align: center;">
            <div class="panel panel-default" style="text-align: justify;">
                <div class="panel-heading" style="text-align: center; font-weight: bold;">How to use the CSV uploader</div>
  <div class="panel-body">
      <p> 1.    Make sure CSV fields are in the form, SURNAME, OTHERNAMES, USERNAME, DEPARTMENT, TYPE, LEVEL.</p>
      <p> 2.    Make sure DEPARTMENT corresponds to a department in the list above.</p>
      <p>3.    Open your Excel file and click Save As. Choose to save it as a .CSV (Comma Separated) file. If you are running Excel on a Mac, you will need to save the file as a Windows Comma Separated (.csv) or CSV (Windows) to maintain the correct formatting</p>
  </div>
</div>
            <div class="alert alert-success" id="successAlert">
                <strong>Success!</strong><span id="sat"></span>
</div>
            <div class="alert alert-danger" id="errorAlert">
                <strong>Error!</strong><span id="eat"></span>
</div>
            <div class="card">
                <div class="card-header">
                    <h4>Upload a list of Student CSV document</h4>
                </div>
                <div class="card-body">
                     <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="myForm" name="frmupload" method="post" enctype="multipart/form-data">      
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-upload"></i></span>
                                                           <input class="form-control" type="hidden" name="schoolname" value="<?php echo $_SESSION['school_name']; ?>" required="" />
                                                           <input class="form-control" type="file" accept=".csv" id="upload_file" name="upload_file" required="" />
                                                                        </div>
                                                                <input class="btn btn-success" id="sim" type="submit" name='submit_image' value="Upload CSV" onclick='upload_image();'/> 
                                                            </form>
            <br>
            <div class='progress' id="progress_div">
<div class='bar' id='bar'></div>
<div class='percent' id='percent'>0%</div>
</div>
                </div>
            </div>
        </div>
        <div class="col-sm-5" style="text-align: center;">
            <div class="alert alert-success" id="successAlert1">
                <strong>Success!</strong><span id="sat1"></span>
</div>
            <div class="alert alert-danger" id="errorAlert1">
                <strong>Error!</strong><span id="eat1"></span>
</div>
            <div class="card">
                <div class="card-header">
                    <h4 style="text-align: center;">Add Student</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="staffform" name="addstaff" method="post" enctype="multipart/form-data">      
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <input class="form-control" type="hidden" name="schoolname1" value="<?php echo $_SESSION['school_name']; ?>" required="" />
                                                           <span class="input-group-addon"><i class="fa fa-edit"></i></span>
                                                           <input class="form-control" type="text" name="surname" required="" placeholder="Surname" />
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-edit"></i></span>
                                                           <input class="form-control" type="text" name="othernames" required="" placeholder="Othernames" />
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-paper-plane"></i></span>
                                                           <input class="form-control" type="text" name="username" required="" placeholder="username" />
                                                                        </div>
                                                            
                                                           <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <input class="form-control" type="text" name="department" required="" placeholder="Department" />
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list-alt"></i></span>
                                                           <input class="form-control" type="text" name="type" required="" placeholder="Type" />
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <input class="form-control" type="text" name="level" required="" placeholder="Level" />
                                                                        </div>
                         <div id="loadering"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success" id="sima" type="submit" name='addstaffer' onclick="addstafff();" value="Add Student"/> 
                                                            </form>
            <br>
            <div class='progress' id="progress_div">
<div class='bar' id='bar'></div>
<div class='percent' id='percent'>0%</div>
</div>
                </div>
            </div>
        </div>
       
        <?php
        //check if staff exist
        $dstaff = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $dstaff = $dstaff->execute_return("SELECT * FROM students");
        if(count($dstaff) > 0)
        {
            echo '<div class="card" style="width: 100%; text-align: center;">
             <div class="alert alert-success" id="successAlertv">
                <strong>Success!</strong><span id="satv"></span>
</div>
            <div class="alert alert-danger" id="errorAlertv">
                <strong>Error!</strong><span id="eatv"></span>
</div>
            <div class="card-header">Select to view students</div>
            <div class="card-body">
                 <form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="getstudent" name="getst" method="post" enctype="multipart/form-data">
                <div style="margin-bottom: 25px" class="input-group">
                                                          <input class="form-control" type="hidden" name="studentschool" value="'.$_SESSION['school_name'].'" required="" />
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <select onchange="setType(this.value, \''.$dstaff[0]["username"].'\');" class="form-control" name="departmentv" required="" id="departmentv" />
                                                           <option value="" selected>Select Department</option>
               ';
            $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($dstaff); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($dstaff[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$dstaff[$i]["department"].'">'.$dstaff[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $dstaff[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
            echo ' </select>
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list-alt"></i></span>
                                                           <select onchange="setLevel(this.value, \''.$dstaff[0]["username"].'\');" class="form-control" name="typev" required="" id="typev">
                                                           <option value="" selected>Select Type</option>
                                                           </select>
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <select class="form-control" name="levelv" required="" id="levelv">
                                                           <option value="" selected>Select Level</option>
                                                           </select>
                                                                        </div>
                 <div id="loaderingv"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success" id="simav" type="submit" name="getstud" onclick="getstudents();" value="View Students"/> 
                
</form>
            </div>
        </div>';
        }
        
        ?>
          <div class="table-responsive" style="max-height: 500px; background: #ffffff; color: #000000;">
            <table class="table" style="font-size: 14px !important;">
    <thead>
      <tr>
          <th style="text-align:center;">#</th>
          <th style="text-align:center;">Im</th>
        <th style="text-align:center;">Username</th>
      </tr>
    </thead>
    <tbody id="tablebofy">
      <?php echo $listOfStudents; ?>
    </tbody>
  </table>
            </div>
        
        
        
    </div>
</div>
<script>
    
    function setType(e,b)
    {
        document.getElementById("typev").value = "";
        document.getElementById("levelv").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getstudentdetails.php",
        type: "post",
        data: "data=type"+"&department="+e+"&studentusername="+b,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("typev").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("typev").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel(e,b)
    {
        document.getElementById("levelv").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getstudentdetails.php",
        type: "post",
        data: "data=level"+"&type="+e+"&studentusername="+b,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("levelv").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("levelv").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    
    function getstudents() 
  {
      
    $('#getstudent').ajaxForm({
      beforeSubmit: function() {
        
      },
      
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
       document.getElementById('tablebofy').innerHTML = "";
       document.getElementById('tablebofy').innerHTML += myResp;
      }
    }); 
  }
  
  function upload_image() 
  {
      
      document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "none";
    var bar = $('#bar');
    var percent = $('#percent');
    
    $('#myForm').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("progress_div").style.display="block";
        var percentVal = '0%';
        bar.width(percentVal);
        percent.html(percentVal);
      },
      uploadProgress: function(event, position, total, percentComplete) {
        var percentVal = percentComplete + '%';
        bar.width(percentVal)
        percent.html(percentVal);
      },
      success: function() {
        var percentVal = '100%';
        bar.width(percentVal);
        percent.html(percentVal);
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
        if(myResp == "invalidf")
        {
            
            document.getElementById("eat").innerHTML = " File is not a CSV";
            document.getElementById("errorAlert").style.display = "block";
            
        }
        else if(myResp == "success")
        {
             document.getElementById("sat").innerHTML = " CSV upload completed, refreshing page in 5seconds";
            document.getElementById("successAlert").style.display = "block";
            window.setTimeout(function(){window.location.href="newstudent.php";},5000);
        }
        else  if(myResp == "emptyf")
        {
            
            document.getElementById("eat").innerHTML = " File is empty";
            document.getElementById("errorAlert").style.display = "block";
            
        }
        else  if(myResp == "depNexist")
        {
            
            document.getElementById("eat").innerHTML = " A department in your CSV does not exist";
            document.getElementById("errorAlert").style.display = "block";
            
        }
        else  if(myResp == "typNexist")
        {
            
            document.getElementById("eat").innerHTML = "  A type in your CSV does not exist";
            document.getElementById("errorAlert").style.display = "block";
            
        }
        else  if(myResp == "levNexist")
        {
            
            document.getElementById("eat").innerHTML = " A level in your CSV does not exist";
            document.getElementById("errorAlert").style.display = "block";
            
        }
        else  if(myResp == "emptyd")
        {
            
            document.getElementById("eat").innerHTML = " CSV contains empty data, please correct the CSV file";
            document.getElementById("errorAlert").style.display = "block";
            
        }
        else  if(myResp == "taken")
        {
            
            document.getElementById("eat").innerHTML = " Username is already registered with a student, Cross check student CSV with the List shown.";
            document.getElementById("errorAlert").style.display = "block";
            
        }
        else
        {
            document.getElementById("eat").innerHTML = " Invalid upload file";
            document.getElementById("errorAlert").style.display = "block";
        }
      }
    }); 
  }
  
    function addstafff() 
  {
    $('#staffform').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert1").style.display = "none";
      document.getElementById("successAlert1").style.display = "none";
      document.getElementById("loadering").style.display = "block";
      document.getElementById("sima").style.display = "none";
      },
      complete: function(xhr) {
       var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
        if(myResp == "taken")
        {
            
            document.getElementById("eat1").innerHTML = " Username is already registered with a student";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
            
        }
        else if(myResp == "success")
        {
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
             document.getElementById("sat1").innerHTML = " Student successfully added, refreshing page in 5seconds";
            document.getElementById("successAlert1").style.display = "block";
            window.setTimeout(function(){window.location.href="newstudent.php";},5000);
        }
        else  if(myResp == "depNexist")
        {
            
            document.getElementById("eat1").innerHTML = " Department does not exist, cross check staff departments";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
            
        }
        else  if(myResp == "typNexist")
        {
            
            document.getElementById("eat1").innerHTML = "  Type does not exist, croos check staff types";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
            
        }
        else  if(myResp == "levNexist")
        {
            
            document.getElementById("eat1").innerHTML = " Level does not exist, cross check staff levels";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
        }
        else
        {
            document.getElementById("eat1").innerHTML = " Occured, please refresh the page and try again.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
        }
      }
    }); 
  }
</script> 
<?php require_once 'footer.php'; ?>
