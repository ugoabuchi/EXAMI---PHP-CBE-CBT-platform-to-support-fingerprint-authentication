
<?php 
//dont forget about the delete function for staffs
$title = "Edit Student";
$active1 = "";
$active2 = "";
$active3 = "";
$active4 = "";
$active5 = "activer";
$active6 = "";
$active7 = "";
$active8 = "";
$active9 = "";
$listOfStudents = "<tr><td colspan='4' style='text-align: center;'>Select department, level, and type to view student</td></tr>";
if(isset($_POST['getstud']))
{
    $listOfStudents = "";
    $depr = strtoupper($_POST['departmentv']);
    $tyy = strtoupper($_POST['typev']);
    $levv = strtoupper($_POST['levelv']);
    require_once '../classes/config.php';
    $schoolname = preg_replace('/\s+/', '_', $_POST['studentschool']);
    $getSt = new config($schoolname);
    $getSt = $getSt->execute_return("SELECT username FROM students WHERE department = '$depr' AND type = '$tyy' AND level = '$levv'");
    if(count($getSt) > 0)
    {
        for($i = 0; $i<count($getSt); $i++)
    {
            $listOfStudents .= '<tr><td style="text-align:center;">'.($i+1).'</td><td style="text-align:center;"><img class="img-responsive" style="height: 20px; width 20px;" src="images/def.png"/></td><td style="text-align:center;">'.$getSt[$i]["username"].'</td><td><a class="btn btn-primary" href="'.htmlspecialchars($_SERVER['PHP_SELF']).'?studentusername='.base64_encode($getSt[$i]["username"]).'">Edit</a></td></tr>';
        
                                }
    }
    else
    {
        $listOfStudents = "<tr><td colspan='4' style='text-align: center;'>Selection does not have a student/td></tr>";
    }
    
    die($listOfStudents);
}
if(isset($_POST['submit_staff']))
{
    require_once '../classes/config.php';
    $schoolname = preg_replace('/\s+/', '_', $_POST['schoolname']);
    $username = strtoupper($_POST['search_username']);
    $getStudent = new config($schoolname);
    $getStudent = $getStudent->execute_return("SELECT username FROM students WHERE username = '$username' LIMIT 1");
    if(count($getStudent) > 0)
    {
        die(base64_encode($getStudent[0]['username']));
    }
    else
    {
        die("invalid");
    }
    
}
if(isset($_POST['resetstudent']))
{
    session_start();
    require_once '../classes/config.php';
    $username = strtoupper($_POST['username']);
    $department = strtoupper($_POST['department']);
    $type = strtoupper($_POST['type']);
    $level = strtoupper($_POST['level']);
    $surname = strtoupper($_POST['surname']);
    $othernames = strtoupper($_POST['othernames']);
if($username != $_SESSION['up_username'] || $department != $_SESSION['up_dep'] || $type != $_SESSION['up_type'] || $level != $_SESSION['up_level'])
{
    die("manipulated");
}
else if($surname == "" || $othernames == "")
{
    die("empty");
}
else
{
    $rand1 = mt_rand();
        $rand2 = mt_rand();
	$rand3 = mt_rand();
	$rand4 = mt_rand();
	$rand5 = mt_rand();
        
                    $password = sha1($surname).sha1($rand1).sha1($rand2).sha1($rand3).sha1($rand4).sha1($rand5);
    //update student;
    $upstudent = new config(preg_replace('/\s+/', '_', $_POST['schoolname1']));
    $upstudent = $upstudent->execute_no_return("UPDATE students set rand1='$rand1', rand2='$rand2', rand3='$rand3', rand4='$rand4', rand5='$rand5', password='$password' WHERE username = '$username' AND department = '$department' AND type = '$type' AND level = '$level'");
    die("success");
    
}
}
if(isset($_POST['updatestaff']))
{
    session_start();
    require_once '../classes/config.php';
    $username = strtoupper($_POST['username']);
    $department = strtoupper($_POST['department']);
    $type = strtoupper($_POST['type']);
    $level = strtoupper($_POST['level']);
    $surname = strtoupper($_POST['surname']);
    $othernames = strtoupper($_POST['othernames']);
if($username != $_SESSION['up_username'] || $department != $_SESSION['up_dep'] || $type != $_SESSION['up_type'] || $level != $_SESSION['up_level'])
{
    die("manipulated");
}
else if($surname == "" || $othernames == "")
{
    die("empty");
}
else
{
    //update student;
    $upstudent = new config(preg_replace('/\s+/', '_', $_POST['schoolname1']));
    $upstudent = $upstudent->execute_no_return("UPDATE students set surname = '$surname', othernames = '$othernames' WHERE username = '$username' AND department = '$department' AND type = '$type' AND level = '$level'");
    die("success");
    
}
}


require_once 'header.php';
                    
                    
?>

<style>
#successAlert, #successAlert1, #errorAlert, #errorAlert1, #loadering,  #successAlertv, #errorAlertv, #loaderingv
{
    display: none;
}
</style>
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <div class="alert alert-success" id="successAlert">
                <strong>Success!</strong><span id="sat"></span>
</div>
            <div class="alert alert-danger" id="errorAlert">
                <strong>Error!</strong><span id="eat"></span>
</div>
<div class="card" style="text-align: center;">
                <div class="card-header">
                    <h4>Search Student to edit</h4>
                </div>
                <div class="card-body">
                     <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="myForm" name="frmupload" method="post" enctype="multipart/form-data">      
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-user-plus"></i></span>
                                                           <input class="form-control" type="hidden" name="schoolname" value="<?php echo $_SESSION['school_name']; ?>" required="" />
                                                           <input class="form-control" type="text"  name="search_username" required="" placeholder="student username" />
                                                                        </div>
                                                                <input class="btn btn-success" id="sim" type="submit" name='submit_staff' value="Search Student" onclick='search_stud();'/> 
                                                            </form>
 
                </div>
            </div>

        </div>
        
        <div class="col-sm-8">
                        
            
            
            
            
            

<div class="card" id="resultbox">
    <?php 
    $ste = "";
    if(isset($_GET['staffemail']))
                    {
    $ste = "(".base64_decode($_GET['staffemail']).")";
                    }
                    ?>
    <div class="card-header" style="text-align: center; font-weight: bold;">Edit Panel <?php echo $ste; ?></div>
                <div class="card-body" id="result">
                     
                    <?php
                    if(isset($_GET['studentusername']))
                    {
    $studentemail = base64_decode($_GET['studentusername']);
    //check if email exist
    $checkSrat = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
    $checkSrat = $checkSrat->execute_return("SELECT * FROM students WHERE username = '$studentemail'");
    if(count($checkSrat) <= 0)
    {
        echo '<div class="card">
                
                <div class="card-body">
                Invalid student username<br>
                Click on edit button to edit student or use the search field
            <br>
           
</div>
                </div>';
    }
    else
    {
        if(isset($_SESSION['up_username']))
        {
            unset($_SESSION['up_username']);
        }
        if(isset($_SESSION['up_dep']))
        {
            unset($_SESSION['up_dep']);
        }
        if(isset($_SESSION['up_type']))
        {
            unset($_SESSION['up_type']);
        }
        if(isset($_SESSION['up_level']))
        {
            unset($_SESSION['up_level']);
        }
        
        
        $_SESSION['up_username'] = $checkSrat[0]['username'];
        $_SESSION['up_dep'] = $checkSrat[0]['department'];
        $_SESSION['up_type'] = $checkSrat[0]['type'];
        $_SESSION['up_level'] = $checkSrat[0]['level'];
        
        
        echo ' 
          
 <div class="alert alert-success" id="successAlert1">
                <strong>Success!</strong><span id="sat1"></span>
</div>
            <div class="alert alert-danger" id="errorAlert1">
                <strong>Error!</strong><span id="eat1"></span>
</div>
            <div class="card">
                
                <div class="card-body">
                    <form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="staffform" name="addstaff" method="post" enctype="multipart/form-data"> 
                        
                                           
                                                           
                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-paper-plane"></i></span>
                                                           <input class="form-control" readonly="" type="text" name="username" value="'.$checkSrat[0]["username"].'" required="" placeholder="Username" />
                                                                        </div>
                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <input type="text" readonly="" class="form-control" value="'.$checkSrat[0]["department"].'" name="department" required=""/>
                                                           
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list-alt"></i></span>
                                                           <input type="text" readonly="" class="form-control" name="type" value="'.$checkSrat[0]["type"].'" required="" id="type">
                                                          
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <input type="text" readonly="" class="form-control" value="'.$checkSrat[0]["level"].'" name="level" required="" id="level">
                                                          
                                                                        </div>
                                                                        
                                                             <div style="margin-bottom: 25px" id="surnamer" class="input-group">
                                                           
                                                           <input class="form-control" type="hidden" name="schoolname1" value="'.$_SESSION["school_name"].'" required="" />
                                                           <span class="input-group-addon"><i class="fa fa-edit"></i></span>
                                                           <input class="form-control" type="text" id="surname" name="surname" value="'.$checkSrat[0]["surname"].'" required="" placeholder="Surname" />
                                                                        </div>
                                                            <div style="margin-bottom: 25px" id="othernamers" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-edit"></i></span>
                                                           <input class="form-control" type="text" id="othernames" name="othernames" value="'.$checkSrat[0]["othernames"].'" required="" placeholder="Othernames" />
                                                                        </div>
                          <div id="sending" style="text-align:center;">                                           
                         <div id="loadering"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success pull-left" id="sima" type="submit" name="updatestaff" onclick="updatestaffs();" value="Update Student" style="margin-bottom: 5px;"/> 
                         <input class="btn btn-danger pull-right" id="simar" type="submit" name="resetstudent" onclick="resetstud();" value="Reset Student Password" style="margin-bottom: 5px;"/>
</div>

                                                            
                                                            </form>
            <br>
           
</div>
                </div>
           
';
    }
                    }
                    else
                    {
                        echo '<div class="card">
                
                <div class="card-body">
                Click on edit button to edit student or use the search field
            <br>
           
</div>
                </div>';
                    }
                    ?>
                    
                </div>
            </div>
            
        </div>
    </div>
</div>
<?php 
//check if staff exist
        $dstaff = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $dstaff = $dstaff->execute_return("SELECT * FROM students");
        if(count($dstaff) > 0)
        {
            echo '<div class="card" style="width: 100%; text-align: center;">
             <div class="alert alert-success" id="successAlertv">
                <strong>Success!</strong><span id="satv"></span>
</div>
            <div class="alert alert-danger" id="errorAlertv">
                <strong>Error!</strong><span id="eatv"></span>
</div>
            <div class="card-header">Select to edit students</div>
            <div class="card-body">
                 <form action="'.htmlspecialchars($_SERVER['PHP_SELF']).'" id="getstudent" name="getst" method="post" enctype="multipart/form-data">
                <div style="margin-bottom: 25px" class="input-group">
                                                          <input class="form-control" type="hidden" name="studentschool" value="'.$_SESSION['school_name'].'" required="" />
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <select onchange="setType(this.value, \''.$dstaff[0]["username"].'\');" class="form-control" name="departmentv" required="" id="departmentv" />
                                                           <option value="" selected>Select Department</option>
               ';
            $padded1 = array();
                                                            $acount1 = 0;
                                                           for($i = 0; $i<count($dstaff); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($dstaff[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               echo '<option value="'.$dstaff[$i]["department"].'">'.$dstaff[$i]["department"].'</option>';
                                                               $padded1[$acount1] = $dstaff[$i]["department"];
                                    $acount1++;
                                                               
                                                                   }
                                                    
            echo ' </select>
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list-alt"></i></span>
                                                           <select onchange="setLevel(this.value, \''.$dstaff[0]["username"].'\');" class="form-control" name="typev" required="" id="typev">
                                                           <option value="" selected>Select Type</option>
                                                           </select>
                                                                        </div>
                                                            <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                           <select class="form-control" name="levelv" required="" id="levelv">
                                                           <option value="" selected>Select Level</option>
                                                           </select>
                                                                        </div>
                 <div id="loaderingv"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success" id="simav" type="submit" name="getstud" onclick="getstudents();" value="View Students to Edit"/> 
                
</form>
            </div>
        </div>';
        }

?>
 <div class="table-responsive" style="max-height: 500px; background: #ffffff; color: #000000;">
            <table class="table" style="font-size: 14px !important;">
    <thead>
      <tr>
          <th style="text-align:center;">#</th>
          <th style="text-align:center;">Im</th>
        <th style="text-align:center;">Username</th>
        <th style="text-align:center;"></th>
      </tr>
    </thead>
    <tbody id="tablebofy">
      <?php echo $listOfStudents; ?>
    </tbody>
  </table>
            </div>
<script>
    function setType(e,b)
    {
        document.getElementById("typev").value = "";
        document.getElementById("levelv").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getstudentdetails.php",
        type: "post",
        data: "data=type"+"&department="+e+"&studentusername="+b,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("typev").innerHTML ="<option value='' selected>Select Type</option>";
          document.getElementById("typev").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    function setLevel(e,b)
    {
        document.getElementById("levelv").value = "";
        
         $.ajax({
        url: "../ajax_to_php_connectors/getstudentdetails.php",
        type: "post",
        data: "data=level"+"&type="+e+"&studentusername="+b,
        success: function (response) {
           var myResp = $.trim(response.replace(/[\n]+/g, '')); 
          document.getElementById("levelv").innerHTML ="<option value='' selected>Select Level</option>";
          document.getElementById("levelv").innerHTML += myResp;

        },
        error: function(jqXHR, textStatus, errorThrown) {
           //console.log($.trim(textStatus.replace(/[\t\n]+/g, ' ')), $.trim(errorThrown.replace(/[\t\n]+/g, ' ')));
        }


    });
    }
    
    
    function getstudents() 
  {
      
    $('#getstudent').ajaxForm({
      beforeSubmit: function() {
        
      },
      
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
       document.getElementById('tablebofy').innerHTML = "";
       document.getElementById('tablebofy').innerHTML += myResp;
      }
    }); 
  }
  
    function search_stud() 
  {
      
    $('#myForm').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert").style.display = "none";
      document.getElementById("successAlert").style.display = "none";
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
        if(myResp == "invalid")
        {
            document.getElementById("eat").innerHTML = " Username does not exist";
            document.getElementById("errorAlert").style.display = "block";
        }
        else
        {
            document.getElementById("sat").innerHTML = " Username exist, updating edit panel in 5 seconds.";
            document.getElementById("successAlert").style.display = "block";
            window.setInterval(function(){window.location.href = 'editstudent.php?studentusername='+myResp;},5000);
        }
      }
    }); 
  }
  
  function resetstud()
  {
      $('#staffform').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert1").style.display = "none";
      document.getElementById("successAlert1").style.display = "none";
      document.getElementById("loadering").style.display = "block";
      document.getElementById("sima").style.display = "none";
      document.getElementById("simar").style.display = "none";
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
       if(myResp == "empty")
        {
            
            document.getElementById("eat1").innerHTML = " All field must be filled.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
      document.getElementById("simar").style.display = "block";
        }
        else if(myResp == "manipulated")
        {
            
            document.getElementById("eat1").innerHTML = " Read-only fields have been manipulated, please browse this website properly, refreshing page in 5seconds";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
       document.getElementById("simar").style.display = "block";
      window.setTimeout(function(){window.location.reload()},5000);
        }
        else if(myResp == "success")
        {
            
            document.getElementById("sat1").innerHTML = " Student password successfully set to default, refreshing page in 5seconds";
            document.getElementById("successAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
            document.getElementById("sima").style.display = "block";
             document.getElementById("simar").style.display = "block";
            window.setTimeout(function(){window.location.reload()},5000);
        }
        
        else
        {
            document.getElementById("eat1").innerHTML = " Occured, please refresh the page and try again.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
       document.getElementById("simar").style.display = "block";
        }
      }
    }); 
  }
  function updatestaffs() 
  {
    $('#staffform').ajaxForm({
      beforeSubmit: function() {
        document.getElementById("errorAlert1").style.display = "none";
      document.getElementById("successAlert1").style.display = "none";
      document.getElementById("loadering").style.display = "block";
      document.getElementById("sima").style.display = "none";
      document.getElementById("simar").style.display = "none";
      },
      complete: function(xhr) {
          var respp = xhr.responseText;
          var myResp = $.trim(respp.replace(/[\n]+/g, '')); 
       if(myResp == "empty")
        {
            
            document.getElementById("eat1").innerHTML = " All field must be filled.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
      document.getElementById("simar").style.display = "block";
        }
        else if(myResp == "manipulated")
        {
            
            document.getElementById("eat1").innerHTML = " Read-only fields have been manipulated, please browse this website properly, refreshing page in 5seconds";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
       document.getElementById("simar").style.display = "block";
      window.setTimeout(function(){window.location.reload()},5000);
        }
        else if(myResp == "success")
        {
            
            document.getElementById("sat1").innerHTML = " Student successfully updated, refreshing page in 5seconds";
            document.getElementById("successAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
            document.getElementById("sima").style.display = "block";
             document.getElementById("simar").style.display = "block";
            window.setTimeout(function(){window.location.reload()},5000);
        }
        
        else
        {
            document.getElementById("eat1").innerHTML = " Occured, please refresh the page and try again.";
            document.getElementById("errorAlert1").style.display = "block";
            document.getElementById("loadering").style.display = "none";
      document.getElementById("sima").style.display = "block";
       document.getElementById("simar").style.display = "block";
        }
      }
    }); 
  }
    </script>
<?php 

require_once 'footer.php';

?>
   