
	<footer id="footer" class="top-space">


		<div class="footer2">
			<div class="container">
				<div class="row">
					
					

					<div class="col-md-6 widget sfooter">
						<div class="widget-body">
                                                    <p style="text-align: center;">
								Copyright &copy; 2019, EXAMI.COM.NG. Designed by <a href="http://www.exami.com.ng/" rel="designer">EXAMI FOUNDATION</a> 
							</p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>

	</footer>	
		




	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap3.js"></script>
        
	<script src="assets/js/headroom.min.js"></script>
	<script src="assets/js/jQuery.headroom.min.js"></script>
	<script src="assets/js/template.js"></script>
        <script src="js/former.js"></script>
</body>
</html>