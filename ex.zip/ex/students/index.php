<?php 
$title = "Dashboard";
require_once 'header.php'; 
if(isset($_SESSION['paper']))
{
    header("location: exam.php");
}
?>

	
		
	<!-- Highlights - jumbotron -->
	<div class="jumbotron top-space">
		<div class="container">
			
                    
		
		</div>
	</div>
	<!-- /Highlights -->

	

<?php require_once 'footer.php'; ?>