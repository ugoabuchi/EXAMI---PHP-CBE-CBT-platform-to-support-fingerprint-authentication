<?php


session_start();

if(isset($_SESSION['paper']))
{
    include_once '../classes/config.php';
    $p = base64_decode($_SESSION['paper']);
    $u = $_SESSION['username'];
    $ctime =    new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $ctime->execute_no_return("UPDATE `timer` SET `h`='0',`m`='0',`s`='0' WHERE username='$u' AND title='$p'");
        
        unset($_SESSION['paper']);
        unset($_SESSION['nquestion']);
        unset($_SESSION['key']);
        header("location: exam.php");
}
 else {
header("location: exam.php");    
}

?>