<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
if($_SERVER['REQUEST_METHOD'] == "POST")
{
    require_once '../classes/config.php';
    
     $data = $_POST['data'];
     $username = $_SESSION['username'];
    if($data == "type")
    {
       
    $dep = $_POST['department'];
        $type = "";
        $getType = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $getType = $getType->execute_return("SELECT type FROM staffs WHERE email = '$username' AND department='$dep' ");
        $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getType); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getType[$i]["type"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $type .= '<option value="'.$getType[$i]["type"].'">'.$getType[$i]["type"].'</option>';
                                                           $padded1[$acount1] = $getType[$i]["type"];
                                    $acount1++;
                                                               
                                        }
                                                           if(isset($_SESSION['depppp']))
                                                           {
                                                               unset($_SESSION['depppp']);
                                                               
                                                               
                                                           }
                                                           
                                                           $_SESSION['depppp'] = $dep;                                          
        die($type);
    }
 else if($data == "level"){
    $dep = $_SESSION['depppp'];
    $type = $_POST['type'];
     $level = "";
        $getLevel = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $getLevel = $getLevel->execute_return("SELECT level FROM staffs WHERE email = '$username' AND department='$dep' AND type='$type'");
        $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getLevel); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getLevel[$i]["level"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $level .= '<option value="'.$getLevel[$i]["level"].'">'.$getLevel[$i]["level"].'</option>';
                                                               $padded1[$acount1] = $getLevel[$i]["level"];
                                    $acount1++;
                                                           }
                                                           if(isset($_SESSION['tyyyyp']))
                                                           {
                                                               unset($_SESSION['tyyyyp']);
                                                               
                                                               
                                                           }
                                                           
                                                           $_SESSION['tyyyyp'] = $type;
                                                          
                                                          
        die($level);
 }
 else if($data == "exams")
 {
     $examlist = '<div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-header"></i></span><select onchange="setRemains(this.value);" class="form-control" id="subjecttitle" name="subjecttitle" required=""><option value="" selected>SELECT EXAM</option>';
     $depppp = $_SESSION['depppp'];
     $typppp = $_SESSION['tyyyyp'];
     $levvvv = $_POST['level'];
    
     //get all exam based the crireria above
     $getExam = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
     $getExam = $getExam->execute_return("SELECT * FROM exam WHERE department = '$depppp' AND type = '$typppp' AND level = '$levvvv'");
     for($i = 0; $i<count($getExam); $i++)
     {
         $examlist .= '
                                                           <option value="'.$getExam[$i]['title'].'">'.$getExam[$i]['title'].'</option>
                                                                        ';
     }
     $examlist .= '</select></div><div style="margin-bottom: 25px" class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-upload"></i></span>
                                                           <input class="form-control" type="hidden" name="schoolname" value="'.$_SESSION['school_name'].'" required="" />
                                                           <input class="form-control" type="file" accept=".csv" id="upload_file" name="upload_file" required="" />
                                                                        </div>
                                                                        <div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-cut"> Override</i></span>
                                                           <input type="checkbox" id="override" class="form-control" name="override">
                                                          <div id="drem"><br></div>
                                                                        </div>
            <div class="progress" id="progress_div">
<div class="bar" id="bar"></div>
<div class="percent" id="percent">0%</div>
</div>';
      if(isset($_SESSION['levvv']))
                                                           {
                                                               unset($_SESSION['levvv']);
                                                               
                                                               
                                                           }
                                                           
                                                           $_SESSION['levvv'] = $levvvv;
     die($examlist);
 }
 else
 {
     $depppp = $_SESSION['depppp'];
     $typppp = $_SESSION['tyyyyp'];
     $levvvv = $_SESSION['levvv'];
     $title = $_POST['title'];
     
     $loaded = 0;
     $Qno = 0;
     
     $getRemains = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
     $getRemains = $getRemains->execute_count_return("SELECT COUNT(*) FROM questions WHERE title = '$title' AND department = '$depppp' AND type = '$typppp' AND level = '$levvvv'");
     $loaded = (int)$getRemains;
     
     //get question no;
      $getqno = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
     $getqno = $getqno->execute_return("SELECT questions FROM exam WHERE title = '$title' AND department = '$depppp' AND type = '$typppp' AND level = '$levvvv'");
     $Qno = (int)$getqno[0]['questions'];
     
      if($getRemains == 1)
    {
         $Qno = (int)$getqno[0]['questions'];
     
     die('<div class="input-group">
         
                                <p style="text-align: center; font-weigth:bold;">'.($Qno - $loaded).' Out of '.$Qno.' questions to be loaded.</p>               </div>');
     
     

    }
    else
    {
        die('<div class="input-group">
         
                                <p style="text-align: center; font-weigth:bold;">0 Out of '.(int)$getqno[0]['questions'].' questions to be loaded.</p>               </div>');
     
     

   
    }
 }
 
}


?>