<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
if($_SERVER['REQUEST_METHOD'] == "POST")
{
    require_once '../classes/config.php';
    
     $data = $_POST['data'];
    if($data == "dep")
    {
       
    $sch = strtolower("examicom_".$_POST['school']);
    
        $dep = "";
        $getType = new config(preg_replace('/\s+/', '_',$sch));
        $getType = $getType->execute_return("SELECT department FROM staffs");
        $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getType); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getType[$i]["department"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $dep .= '<option value="'.$getType[$i]["department"].'">'.$getType[$i]["department"].'</option>';
                                                           $padded1[$acount1] = $getType[$i]["department"];
                                    $acount1++;
                                                               
                                        }
                                                           if(isset($_SESSION['sn']))
                                                           {
                                                               unset($_SESSION['sn']);
                                                               
                                                               
                                                           }
                                                           
                                                           $_SESSION['sn'] = preg_replace('/\s+/', '_',$sch); 
        die($dep);
    }
    else if($data == "type")
    {
       
    $dep = $_POST['department'];
        $type = "";
        $getType = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
        $getType = $getType->execute_return("SELECT type FROM staffs WHERE department='$dep' ");
        $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getType); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getType[$i]["type"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $type .= '<option value="'.$getType[$i]["type"].'">'.$getType[$i]["type"].'</option>';
                                                           $padded1[$acount1] = $getType[$i]["type"];
                                    $acount1++;
                                                               
                                        }
                                                           if(isset($_SESSION['depp']))
                                                           {
                                                               unset($_SESSION['depp']);
                                                               
                                                               
                                                           }
                                                           
                                                           $_SESSION['depp'] = $dep;                                          
        die($type);
    }
 else if($data == "level"){
    $dep = $_SESSION['depp'];
    $type = $_POST['type'];
     $level = "";
        $getLevel = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
        $getLevel = $getLevel->execute_return("SELECT level FROM staffs WHERE department='$dep' AND type='$type'");
        $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getLevel); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getLevel[$i]["level"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $level .= '<option value="'.$getLevel[$i]["level"].'">'.$getLevel[$i]["level"].'</option>';
                                                               $padded1[$acount1] = $getLevel[$i]["level"];
                                    $acount1++;
                                                           }
                                                           if(isset($_SESSION['ty']))
                                                           {
                                                               unset($_SESSION['ty']);
                                                           }
                                                           $_SESSION['ty'] = $type; 
                                                          
                                                          
        die($level);
 }
 else
     {
    $dep = $_SESSION['depp'];
    $type = $_SESSION['ty'];
    $level = $_POST['level'];
     $sub = "";
        $getLevel = new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
        $getLevel = $getLevel->execute_return("SELECT * FROM exam WHERE department='$dep' AND type='$type' AND level='$level'");
        $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getLevel); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getLevel[$i]["title"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $sub .= '<option value="'.$getLevel[$i]["title"].'">'.$getLevel[$i]["title"].'</option>';
                                                               $padded1[$acount1] = $getLevel[$i]["title"];
                                    $acount1++;
                                                           }
                                                           
                                                          
                                                          
        die($sub);
 }
 
}


?>