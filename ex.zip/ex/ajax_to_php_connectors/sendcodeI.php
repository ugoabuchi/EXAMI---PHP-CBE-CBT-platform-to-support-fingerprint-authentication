<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if($_SERVER['REQUEST_METHOD'] == "POST")
{
    require_once '../classes/config.php';
    $checkExist = new config("records");
    $email = $_POST['email'];
    $schoolname = $_POST['school_name'];
    $code = sha1(md5(md5(uniqid())));
    $userex = new config(preg_replace('/\s+/', '_', $schoolname));
    $userex = $userex->execute_count_no_return("SELECT COUNT(*) FROM administrator WHERE schoolemail = '$email'");
    if($userex > 0)
    {
        $checkExist = $checkExist->execute_count_no_return("SELECT COUNT(*) FROM activation_code WHERE email='$email'");
    if($checkExist > 0)
    {
        //DELETE IT
        $del = new config("records");
        $del->execute_no_return("DELETE FROM `activation_code` WHERE email = '$email'");
        //INSERT NEW
        $ins = new config("records");
        $ins->execute_no_return("INSERT INTO `activation_code`(`email`, `school_name`, `code`, `dos`) VALUES ('$email','$schoolname','$code',now())");
        die("");
    }
    else
    {
        //INSERT NEW
        $ins = new config("records");
        $ins->execute_no_return("INSERT INTO `activation_code`(`email`, `school_name`, `code`, `dos`) VALUES ('$email','$schoolname','$code',now())");
        die("");
    }
    }
 else {
        die("");
    }
    
    
    
}

?>

