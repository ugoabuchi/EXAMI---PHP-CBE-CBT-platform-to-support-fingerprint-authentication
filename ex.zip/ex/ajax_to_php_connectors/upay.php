<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 session_start();
 require_once '../classes/config.php';
if(isset($_POST['resp']))
{
    $response = $_POST['resp'];
    $result = array();
//The parameter after verify/ is the transaction reference to be verified
$url = 'https://api.paystack.co/transaction/verify/'.$response.'';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt(
  $ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer sk_live_be6957f8c486834fb1851ddce503e591310a8e3f']
);
$request = curl_exec($ch);
if(curl_error($ch)){
 echo 'error:' . curl_error($ch);
 }
curl_close($ch);

if ($request) {
  $result = json_decode($request, true);
}

if (array_key_exists('data', $result) && array_key_exists('status', $result['data']) && ($result['data']['status'] === 'success')) {
    
    $checkt = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                    $checkt = $checkt->execute_return("SHOW TABLES LIKE 'pay_ref'");
    if($checkt == false && count($checkt) <= 0)
                    {
                        $adddetails = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                        $adddetails->execute_no_return("CREATE TABLE `pay_ref` ( `id` INT(16) NOT NULL AUTO_INCREMENT , `ref_id` VARCHAR(150) NOT NULL , `reference` VARCHAR(150) NOT NULL , `amount` VARCHAR(150) NOT NULL , `status` VARCHAR(150) NOT NULL , `pay_channel` VARCHAR(150) NOT NULL , `currency` VARCHAR(150) NOT NULL , `schoolname` VARCHAR(150) NOT NULL , `schoolnumber` VARCHAR(150) NOT NULL , `dop` DATE NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;");
                      
                    }

//activate exam
$ti = $_POST['ti'];
$d = $_POST['d'];
$t = $_POST['t'];
$l = $_POST['l'];
$aexam = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
$aexam->execute_no_return("UPDATE exam SET loaded='true' WHERE title='$ti' AND department='$d' AND type='$t' AND level='$l'");
//save details to db
$ref_id = $result['data']['id'];
$ref = $result['data']['reference'];
$amount = $result['data']['amount'];
$status = $result['data']['status'];
$pay_channel = $result['data']['channel'];
$currency = $result['data']['currency'];
$school = $result['data']['metadata']['custom_fields'][0]['display_name'];
$telephone = $result['data']['metadata']['custom_fields'][0]['value'];
$idetails = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
$idetails->execute_no_return("INSERT INTO `pay_ref`(`ref_id`, `reference`, `amount`, `status`, `pay_channel`, `currency`, `schoolname`, `schoolnumber`, `dop`) VALUES ('$ref_id','$ref','$amount','$status','$pay_channel','$currency','$school','$telephone',now())");
  die("success");
	//Perform necessary action
}else{
  $checkt = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                    $checkt = $checkt->execute_return("SHOW TABLES LIKE 'pay_ref'");
    if($checkt == false && count($checkt) <= 0)
                    {
                        $adddetails = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                        $adddetails->execute_no_return("CREATE TABLE `pay_ref` ( `id` INT(16) NOT NULL AUTO_INCREMENT , `ref_id` VARCHAR(150) NOT NULL , `reference` VARCHAR(150) NOT NULL , `amount` VARCHAR(150) NOT NULL , `status` VARCHAR(150) NOT NULL , `pay_channel` VARCHAR(150) NOT NULL , `currency` VARCHAR(150) NOT NULL , `schoolname` VARCHAR(150) NOT NULL , `schoolnumber` VARCHAR(150) NOT NULL , `dop` DATE NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;");
                      
                    }


//save details to db
$ref_id = $result['data']['id'];
$ref = $result['data']['reference'];
$amount = $result['data']['amount'];
$status = $result['data']['status'];
$pay_channel = $result['data']['channel'];
$currency = $result['data']['currency'];
$school = $result['data']['metadata']['custom_fields'][0]['display_name'];
$telephone = $result['data']['metadata']['custom_fields'][0]['value'];
$idetails = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
$idetails->execute_no_return("INSERT INTO `pay_ref`(`ref_id`, `reference`, `amount`, `status`, `pay_channel`, `currency`, `schoolname`, `schoolnumber`, `dop`) VALUES ('$ref_id','$ref','$amount','$status','$pay_channel','$currency','$school','$telephone',now())");
  die("nsuccess");
}
    
}
?>

