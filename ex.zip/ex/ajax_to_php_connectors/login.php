<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//Check if user is logged in
session_start();
include_once '../classes/config.php';
    if(isset($_SESSION['sessionid']) && isset($_SESSION['username']) && isset($_SESSION['school_name']))
    {
        $username = $_SESSION['username'];
        $session_val = $_SESSION['sessionid'];
        //check if session exist in database
        $cSession = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $cSession = $cSession->execute_return("SELECT * FROM `sessioner` WHERE username = '$username' AND sessioner_val = '$session_val'");
        if(count($cSession) > 0)
        {
            date_default_timezone_set("Africa/Lagos");
            $datedb = $cSession[0]['dos'];
            $dateR = date_create($datedb);
            $cDate = date_create(date("Y-m-d"));
            $diff=date_diff($cDate,$dateR);
            $dcount =  (int)$diff->format("%a");
            if($dcount > 0)
            {
               
                
                //delete previous session value
            $delsession = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
            $delsession->execute_no_return("DELETE FROM sessioner WHERE username = '$username'");
            session_unset();
            session_destroy();
                die("home");
            }
            else
            {
                 //check session user
    $duse = $_SESSION['username'];
    $checkduseA = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
    $checkduseA = $checkduseA->execute_count_no_return("SELECT COUNT(*) FROM administrator WHERE username = '$username'");
    $checkduseB = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
    $checkduseB = $checkduseB->execute_count_no_return("SELECT COUNT(*) FROM staffs WHERE email = '$username' AND root='true'");
    
                if($checkduseA == 1)
                {
                    die("admin");
                }
                
                if($checkduseB == 1)
                {
                    die("staff");
                }
            }
        }
        else
        {
            session_unset();
            session_destroy();
        }
    }
    else
    {
         session_unset();
     session_destroy();
    }
if($_SERVER['REQUEST_METHOD'] == "POST")
{
    
    include_once '../classes/loginizer.php';
    
    define("username", $_POST['username']);
    define("school_name", $_POST['school_name']);
    define("password", $_POST['password']);
    define("usertype", $_POST['usertype']);
    $new_login = new loginizer(school_name, username, password, usertype);
    $response = $new_login->loginize_user();
    die($response);
}

?>