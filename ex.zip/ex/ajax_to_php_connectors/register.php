<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


if($_SERVER['REQUEST_METHOD'] == "POST")
{
   
    include_once '../classes/registrator.php';
    
    define("username", $_POST['username']);
    define("school_name", $_POST['school_name']);
    define("school_type", $_POST['school_type']);
    define("school_telephone", $_POST['school_telephone']);
    define("school_website", $_POST['school_website']);
    define("school_email", $_POST['school_email']);
    define("password", $_POST['password']);
    $new_register = new registrator(username, school_name, school_type, school_telephone, school_website, school_email, password);
    $newresult = $new_register->registrate_user();
    if($newresult == 1)
    {
        die("success");
    }
    else
    {
        die("not successfull");
    }
}
?>
