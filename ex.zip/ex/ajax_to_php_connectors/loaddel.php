<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
if($_SERVER['REQUEST_METHOD'] == "POST")
{
    require_once '../classes/config.php';
    
     $data = $_POST['data'];
     $username = $_SESSION['username'];
    if($data == "type")
    {
       
    $dep = $_POST['department'];
        $type = "";
        $getType = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $getType = $getType->execute_return("SELECT type FROM staffs WHERE email = '$username' AND department='$dep' ");
        $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getType); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getType[$i]["type"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $type .= '<option value="'.$getType[$i]["type"].'">'.$getType[$i]["type"].'</option>';
                                                           $padded1[$acount1] = $getType[$i]["type"];
                                    $acount1++;
                                                               
                                        }
                                                           if(isset($_SESSION['depppp']))
                                                           {
                                                               unset($_SESSION['depppp']);
                                                               
                                                               
                                                           }
                                                           
                                                           $_SESSION['depppp'] = $dep;                                          
        die($type);
    }
 else if($data == "level"){
    $dep = $_SESSION['depppp'];
    $type = $_POST['type'];
     $level = "";
        $getLevel = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $getLevel = $getLevel->execute_return("SELECT level FROM staffs WHERE email = '$username' AND department='$dep' AND type='$type'");
        $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getLevel); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getLevel[$i]["level"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $level .= '<option value="'.$getLevel[$i]["level"].'">'.$getLevel[$i]["level"].'</option>';
                                                               $padded1[$acount1] = $getLevel[$i]["level"];
                                    $acount1++;
                                                           }
                                                           if(isset($_SESSION['tyyyyp']))
                                                           {
                                                               unset($_SESSION['tyyyyp']);
                                                               
                                                               
                                                           }
                                                           
                                                           $_SESSION['tyyyyp'] = $type;
                                                          
                                                          
        die($level);
 }
 else if($data == "exams")
 {
     $examlist = '<div style="margin-bottom: 25px" class="input-group">
                                                           
                                                           <span class="input-group-addon"><i class="fa fa-header"></i></span><select onchange="setRemains1(this.value);" class="form-control" id="subjecttitle" name="subjecttitle" required=""><option value="" selected>SELECT EXAM</option>';
     $depppp = $_SESSION['depppp'];
     $typppp = $_SESSION['tyyyyp'];
     $levvvv = $_POST['level'];
    
     //get all exam based the crireria above
     $getExam = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
     $getExam = $getExam->execute_return("SELECT * FROM exam WHERE keymode='true' AND department = '$depppp' AND type = '$typppp' AND level = '$levvvv'");
     //dont show scheduled
    // $getSchedule = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
    // $getSchedule = $getSchedule->execute_return("SELECT * FROM keytable WHERE department = '$depppp' AND type = '$typppp' AND level = '$levvvv'");
     
     for($i = 0; $i<count($getExam); $i++)
     {
        
         $examlist .= '
                                                           <option value="'.$getExam[$i]['title'].'">'.$getExam[$i]['title'].'</option>
                                                                        ';
     }
     $examlist .= '</select></div>
                                                                        
                                                                        
         ';
      if(isset($_SESSION['levvv']))
                                                           {
                                                               unset($_SESSION['levvv']);
                                                               
                                                               
                                                           }
                                                           
                                                           $_SESSION['levvv'] = $levvvv;
     die($examlist);
 }
 else
 {
     $depppp = $_SESSION['depppp'];
     $typppp = $_SESSION['tyyyyp'];
     $levvvv = $_SESSION['levvv'];
     $title = $_POST['title'];
     $dey = "";
     $co = 0;
     $dey .= '<tr><td colspan="7"><form action="examkey.php" method="post" name="dschedulingz" id="myschedilingz" enctype="multipart/form-data"><input type="hidden" value="'. base64_encode($title).'" name="etitle"/><input type="hidden" value="'. base64_encode($depppp).'" name="edep"/><input type="hidden" value="'. base64_encode($typppp).'" name="etype"/><input type="hidden" value="'. base64_encode($levvvv).'" name="elev"/><input class="form-control" type="hidden" name="schoolname" value="'.$_SESSION['school_name'].'" required="" /><input class="btn btn-danger" type="submit" name="schdelete" onclick="sexami(\'z\');" value="DELETE ALL"/> </form></td><tr>';
       $getSchedule = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
       
       $getSchedule = $getSchedule->execute_return("SELECT * FROM `keytable` WHERE title='$title' AND department = '$depppp' AND type='$typppp' AND level='$levvvv'");
       if(count($getSchedule) > 0)
       {
          
           for($d=0; $d<count($getSchedule); $d++)
           {
                $co++;
               $dey .= '<tr><td colspan="4" style="text-align: center;">'.($co).'</td><td colspan="4" style="text-align: center;">'.$getSchedule[$d]['title'].'</td><td colspan="4" style="text-align: center;">'.$getSchedule[$d]['stu_username'].'</td><td colspan="4" style="text-align: center;">'.$getSchedule[$d]['keyer'].'</td><td colspan="4" style="text-align: center;">'.$getSchedule[$d]['department'].'</td><td colspan="4" style="text-align: center;">'.$getSchedule[$d]['type'].'</td><td colspan="4" style="text-align: center;">'.$getSchedule[$d]['level'].'</td><td colspan="4" style="text-align: center;"><form action="examkey.php" method="post" name="dscheduling'.$getSchedule[$d]['id'].'" id="myschediling'.$getSchedule[$d]['id'].'" enctype="multipart/form-data"><input type="hidden" value="'. base64_encode($getSchedule[$d]['title']).'" name="etitle"/><input type="hidden" value="'. base64_encode($getSchedule[$d]['department']).'" name="edep"/><input type="hidden" value="'. base64_encode($getSchedule[$d]['type']).'" name="etype"/><input type="hidden" value="'. base64_encode($getSchedule[$d]['stu_username']).'" name="stu_username"/><input type="hidden" value="'. base64_encode($getSchedule[$d]['level']).'" name="elev"/><input class="form-control" type="hidden" name="schoolname" value="'.$_SESSION['school_name'].'" required="" /><input class="btn btn-danger" type="submit" name="schdelete" onclick="sexami(\''.$getSchedule[$d]['id'].'\');" value="DELETE"/> </form></td></tr>';
           }

           die($dey);
       }
      
      
     
 }
 
}


?>