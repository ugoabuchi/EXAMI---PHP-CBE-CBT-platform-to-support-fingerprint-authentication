<?php
session_start();
include_once '../classes/config.php';
if(isset($_POST['h']) && isset($_POST['m']) && isset($_POST['s']))
{
    $u = $_SESSION['user'];
     $p = $_SESSION['paper'];
        $h = $_POST['h'];
        $m = $_POST['m'];
        $s = $_POST['s'];
        //check if username has time already
        $ctime =    new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
        $ctime = $ctime->execute_return("SELECT * FROM ptimer WHERE username='$u' AND title='$p'");
        if(count($ctime) > 0)
        {
            
            
            $utime =    new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
            $utime->execute_no_return("UPDATE ptimer SET h='$h', m='$m', s='$s' WHERE username='$u' AND title='$p'");
           //check if key is set, if set look for key changes or absent
            
            
          
            
        }
        else
        {
            $itime =    new config(preg_replace('/\s+/', '_', $_SESSION['sn']));
            $itime->execute_no_return("INSERT INTO `ptimer`(`username`, `title`, `h`, `m`, `s`) VALUES ('$u','$p','$h','$m','$s')");
        }
}

?>