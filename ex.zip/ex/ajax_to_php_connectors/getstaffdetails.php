<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
if($_SERVER['REQUEST_METHOD'] == "POST")
{
    require_once '../classes/config.php';
    
     $data = $_POST['data'];
    if($data == "type")
    {
       
    $dep = $_POST['department'];
    $semail = $_POST['staffemail'];
        $type = "";
        $getType = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $getType = $getType->execute_return("SELECT type FROM staffs WHERE email='$semail' AND department='$dep' ");
        $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getType); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                    $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getType[$i]["type"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $type .= '<option value="'.$getType[$i]["type"].'">'.$getType[$i]["type"].'</option>';
                                                               $padded1[$acount1] = $getType[$i]["type"];
                                    $acount1++;
                                                           }
                                                           if(isset($_SESSION['depppp']))
                                                           {
                                                               unset($_SESSION['depppp']);
                                                               if(isset($_SESSION['tyyyyp']))
                                                               {
                                                                   unset($_SESSION['tyyyyp']);
                                                                   
                                                                   
                                                               }
                                                               
                                                           }
                                                           
                                                           $_SESSION['depppp'] = $dep;                                          
        die($type);
    }
 else if($data == "level"){
      
    $dep = $_SESSION['depppp'];
    $semail = $_POST['staffemail'];
    $type = $_POST['type'];
     $level = "";
        $getLevel = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $getLevel = $getLevel->execute_return("SELECT level FROM staffs WHERE email='$semail' AND department='$dep' AND type='$type'");
         $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getLevel); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                    $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getLevel[$i]["level"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $level .= '<option value="'.$getLevel[$i]["level"].'">'.$getLevel[$i]["level"].'</option>';
                                                               $padded1[$acount1] = $getLevel[$i]["level"];
                                    $acount1++;
                                                           }
                                                          
                                                           if(isset($_SESSION['tyyyyp']))
                                                               {
                                                                   unset($_SESSION['tyyyyp']);
                                                                  
                                                               }
                                                           
                                                           
        $_SESSION['tyyyyp'] = $type;
        die($level);
 }
 else
 {
     $dep = $_SESSION['depppp'];
    $semail = $_POST['staffemail'];
    $type = $_SESSION['tyyyyp'];
    $level = $_POST['level'];
   
        $getNames = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $getNames = $getNames->execute_return("SELECT surname, othernames FROM staffs WHERE email='$semail' AND root='true'");
       $sur = $getNames[0]['surname'];
       $oth = $getNames[0]['othernames'];
       
        die('<div style="margin-bottom: 25px" id="surnamer" class="input-group">
                                                           
                                                           <input class="form-control" type="hidden" name="schoolname1" value="" required="" />
                                                           <span class="input-group-addon"><i class="fa fa-edit"></i></span>
                                                           <input class="form-control" type="text" id="surname" name="surname" value="'.$sur.'" required="" placeholder="Surname" />
                                                                        </div>
                                                            <div style="margin-bottom: 25px" id="othernamers" class="input-group">
                                                           
                                                   <span class="input-group-addon"><i class="fa fa-edit"></i></span>
                                                           <input class="form-control" type="text" id="othernames" name="othernames" value="'.$oth.'" required="" placeholder="Othernames" />
                                                                        </div>
                                                            
                                                            
                          <div id="sending" style="text-align:center;">                                 
                         <div id="loadering"><i class="fa fa-spin fa-2x"><img style="height: 60px; width: 90px;" src="../img/exlogo.png"/></i></div>
                         <input class="btn btn-success pull-left" id="sima" type="submit" name="updatestaff" onclick="updatestaffs();" value="Update Staff" style="margin-bottom: 5px;"/> 
                         <input class="btn btn-danger pull-right" id="simar" type="submit" name="resetstaff" onclick="resetstaffer();" value="Reset Staff Password" style="margin-bottom: 5px;"/>
</div> ');
 }
}


?>