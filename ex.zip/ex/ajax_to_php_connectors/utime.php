<?php
session_start();
include_once '../classes/config.php';
if(isset($_POST['h']) && isset($_POST['m']) && isset($_POST['s']))
{
    $u = $_SESSION['username'];
     $p = base64_decode($_SESSION['paper']);
        $h = $_POST['h'];
        $m = $_POST['m'];
        $s = $_POST['s'];
        //check if username has time already
        $ctime =    new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $ctime = $ctime->execute_return("SELECT * FROM timer WHERE username='$u' AND title='$p'");
        if(count($ctime) > 0)
        {
            
            
            $utime =    new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
            $utime->execute_no_return("UPDATE timer SET h='$h', m='$m', s='$s' WHERE username='$u' AND title='$p'");
           //check if key is set, if set look for key changes or absent
            
            //get dep details
            $usernamer = $_SESSION['username'];
            $depppppp = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
            $depppppp = $depppppp->execute_return("SELECT department, type, level FROM students WHERE username = '$usernamer'");
            $mydep = $depppppp[0]['department'];
            $mytyp = $depppppp[0]['type'];
            $mylev = $depppppp[0]['level'];
              //chec if key is set in exam table
            $thexam = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
            $thexam = $thexam->execute_count_no_return("SELECT COUNT(*) FROM exam WHERE keymode='true' AND department='$mydep' AND type='$mytyp' AND level='$mylev' AND title='$p'");
            if($thexam == 1)
            {
               //check if key is logged
                if(!isset($_SESSION['key']))
                {
                    session_destroy();
                    die("nsession");
                }
                else
                {
                    //check if key is changed
                    $leyyy = $_SESSION['key'];
                     $student = $_SESSION['username'];
                    $keyc =    new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
                    $keyc = $keyc->execute_count_no_return("SELECT COUNT(*) FROM `keytable` WHERE stu_username='$student' AND keyer='$leyyy' AND title='$p' AND department='$mydep' AND type='$mytyp' AND level='$mylev'");
                    
                    if($keyc != 1)
                    {
                        unset($_SESSION['paper']);
        unset($_SESSION['nquestion']);
        unset($_SESSION['key']);
        die('changed');
                    }
                }
            }
          
            
        }
        else
        {
            $itime =    new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
            $itime->execute_no_return("INSERT INTO `timer`(`username`, `title`, `h`, `m`, `s`) VALUES ('$u','$p','$h','$m','$s')");
        }
}

?>