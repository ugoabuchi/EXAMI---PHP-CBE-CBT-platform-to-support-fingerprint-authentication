<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
if($_SERVER['REQUEST_METHOD'] == "POST")
{
    require_once '../classes/config.php';
    
     $data = $_POST['data'];
     $username = $_SESSION['username'];
    if($data == "type")
    {
       
    $dep = $_POST['department'];
        $type = "";
        $getType = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $getType = $getType->execute_return("SELECT type FROM staffs WHERE email = '$username' AND department='$dep' ");
        $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getType); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getType[$i]["type"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $type .= '<option value="'.$getType[$i]["type"].'">'.$getType[$i]["type"].'</option>';
                                                           $padded1[$acount1] = $getType[$i]["type"];
                                    $acount1++;
                                                               
                                        }
                                                           if(isset($_SESSION['depppp']))
                                                           {
                                                               unset($_SESSION['depppp']);
                                                               
                                                               
                                                           }
                                                           
                                                           $_SESSION['depppp'] = $dep;                                          
        die($type);
    }
 else if($data == "level"){
    $dep = $_SESSION['depppp'];
    $type = $_POST['type'];
     $level = "";
        $getLevel = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
        $getLevel = $getLevel->execute_return("SELECT level FROM staffs WHERE email = '$username' AND department='$dep' AND type='$type'");
        $padded1 = array();
                                                            $acount1 = 0;
        for($i = 0; $i<count($getLevel); $i++)
                                                           {
                                                               if($i > 0)
                                                               {
                                                                  $dish = 0;
                                        for($j = 0; $j<count($padded1); $j++)
                                        {
                                            if($getLevel[$i]["level"] == $padded1[$j])
                                        {
                                            $dish = 1;
                                        }
                                        }
                                        
                                        if($dish == 1)
                                        {
                                            continue;
                                        }
                                                               }
                                                               $level .= '<option value="'.$getLevel[$i]["level"].'">'.$getLevel[$i]["level"].'</option>';
                                                               $padded1[$acount1] = $getLevel[$i]["level"];
                                    $acount1++;
                                                           }
                                                           if(isset($_SESSION['tyyyyp']))
                                                           {
                                                               unset($_SESSION['tyyyyp']);
                                                               
                                                               
                                                           }
                                                           
                                                           $_SESSION['tyyyyp'] = $type;
                                                          
                                                          
        die($level);
 }
 else
 {$depppp = $_SESSION['depppp'];
     $typppp = $_SESSION['tyyyyp'];
     $levvvv = $_POST['level'];
    
     //get all exam based the crireria above
     $getExam = new config(preg_replace('/\s+/', '_', $_SESSION['school_name']));
     $getExam = $getExam->execute_return("SELECT * FROM exam WHERE department = '$depppp' AND type = '$typppp' AND level = '$levvvv'");
     for($i = 0; $i<count($getExam); $i++)
     {
         $examlist .= '
                                                           <option value="'.$getExam[$i]['title'].'">'.$getExam[$i]['title'].'</option>
                                                                        ';
     }
     
      if(isset($_SESSION['levvv']))
                                                           {
                                                               unset($_SESSION['levvv']);
                                                               
                                                               
                                                           }
                                                           
                                                           $_SESSION['levvv'] = $levvvv;
     die($examlist);
 }
 
}


?>