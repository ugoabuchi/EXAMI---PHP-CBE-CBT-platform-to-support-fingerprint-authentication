<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if($_SERVER['REQUEST_METHOD'] == "POST")
{
    require_once '../classes/config.php';
    $code = $_POST['code'];
    
    //check if code exist
    $cExist = new config("records");
    $cExist = $cExist->execute_return("SELECT * FROM activation_code WHERE code = '$code'");
    if(count($cExist) > 0)
    {
        $email = $cExist[0]['email'];
        $sname = $cExist[0]['school_name'];
        
        //Activate user account
        $account = new config(preg_replace('/\s+/', '_', $sname));
        $account->execute_no_return("UPDATE `administrator` SET activated = 'true' WHERE schoolemail='$email'");
        
        //DELETE code
        $del = new config("records");
        $del->execute_no_return("DELETE FROM activation_code WHERE code = '$code'");
        die("success");
    }
    else
    {
        die("error");
    }

}
?>
