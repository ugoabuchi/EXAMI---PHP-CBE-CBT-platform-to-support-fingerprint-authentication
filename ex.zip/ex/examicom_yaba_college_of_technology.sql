-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 12, 2019 at 08:29 PM
-- Server version: 5.7.11
-- PHP Version: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `examicom_yaba_college_of_technology`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `id` int(25) NOT NULL,
  `logoimage` text,
  `username` varchar(150) NOT NULL,
  `schoolname` varchar(150) NOT NULL,
  `schooltype` varchar(150) NOT NULL,
  `schooltelephone` varchar(150) NOT NULL,
  `schoolwebsite` varchar(150) NOT NULL,
  `schoolemail` varchar(150) NOT NULL,
  `rand1` varchar(150) NOT NULL,
  `rand2` varchar(150) NOT NULL,
  `rand3` varchar(150) NOT NULL,
  `rand4` varchar(150) NOT NULL,
  `rand5` varchar(150) NOT NULL,
  `user_password` varchar(150) NOT NULL,
  `dor` date NOT NULL,
  `paid` varchar(150) NOT NULL,
  `activated` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`id`, `logoimage`, `username`, `schoolname`, `schooltype`, `schooltelephone`, `schoolwebsite`, `schoolemail`, `rand1`, `rand2`, `rand3`, `rand4`, `rand5`, `user_password`, `dor`, `paid`, `activated`) VALUES
(1, '5c747f60092e6', 'Fortune', 'YABA_COLLEGE_OF_TECHNOLOGY', 'POLYTECHNIC', '09083273485', 'HTTP://WWW.YABATECH.EDU.NG', 'admin@jamb.edu.ng', '826209397', '1726113169', '1520434360', '1845258559', '560866216', '18b548e50fd80a74bd24a0a9a168e96b', '2019-02-07', 'false', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login_dump`
--

CREATE TABLE `admin_login_dump` (
  `id` int(25) NOT NULL,
  `username` varchar(150) NOT NULL,
  `sessionid` varchar(150) NOT NULL,
  `dol` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login_dump`
--

INSERT INTO `admin_login_dump` (`id`, `username`, `sessionid`, `dol`) VALUES
(12, 'Fortune', 'd219845cc077a46f383b4097e4d004cb', '2019-02-24'),
(13, 'Fortune', 'f4d8db38b4a89b4acf01adca56da2f8d', '2019-02-26');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `id` int(16) NOT NULL,
  `title` varchar(150) NOT NULL,
  `code` varchar(150) NOT NULL,
  `questions` varchar(150) NOT NULL,
  `answers` int(16) NOT NULL,
  `score` varchar(150) NOT NULL,
  `keymode` varchar(150) NOT NULL,
  `strict` varchar(150) NOT NULL,
  `time` varchar(150) NOT NULL,
  `hour` varchar(150) NOT NULL,
  `instruction` text NOT NULL,
  `department` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `level` varchar(150) NOT NULL,
  `loaded` varchar(150) NOT NULL,
  `doc` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`id`, `title`, `code`, `questions`, `answers`, `score`, `keymode`, `strict`, `time`, `hour`, `instruction`, `department`, `type`, `level`, `loaded`, `doc`) VALUES
(3, 'MATHEMATICS', 'MTH101', '5', 4, '5', 'true', 'false', '5', '0', 'Answer all questions', 'SCIENCE', 'FULLTIME', 'ND1', 'false', '2019-02-24');

-- --------------------------------------------------------

--
-- Table structure for table `exam_table`
--

CREATE TABLE `exam_table` (
  `id` int(16) NOT NULL,
  `student_username` varchar(150) NOT NULL,
  `title` varchar(150) NOT NULL,
  `sn` int(16) NOT NULL,
  `ans` varchar(150) NOT NULL,
  `mark` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `keytable`
--

CREATE TABLE `keytable` (
  `id` int(16) NOT NULL,
  `title` varchar(150) NOT NULL,
  `keyer` varchar(150) NOT NULL,
  `department` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `level` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pay_ref`
--

CREATE TABLE `pay_ref` (
  `id` int(16) NOT NULL,
  `ref_id` varchar(150) NOT NULL,
  `reference` varchar(150) NOT NULL,
  `amount` varchar(150) NOT NULL,
  `status` varchar(150) NOT NULL,
  `pay_channel` varchar(150) NOT NULL,
  `currency` varchar(150) NOT NULL,
  `schoolname` varchar(150) NOT NULL,
  `schoolnumber` varchar(150) NOT NULL,
  `dop` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pexam_table`
--

CREATE TABLE `pexam_table` (
  `id` int(16) NOT NULL,
  `student_username` varchar(150) NOT NULL,
  `title` varchar(150) NOT NULL,
  `sn` int(16) NOT NULL,
  `ans` varchar(150) NOT NULL,
  `mark` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pexam_table`
--

INSERT INTO `pexam_table` (`id`, `student_username`, `title`, `sn`, `ans`, `mark`) VALUES
(22, 'nexlord', 'MATHEMATICS', 1, 'b', 'pass'),
(23, 'nexlord', 'MATHEMATICS', 2, 'c', 'pass'),
(24, 'fortune', 'MATHEMATICS', 1, 'a', 'fail'),
(25, 'fortune', 'MATHEMATICS', 2, 'c', 'pass'),
(26, 'fortune', 'MATHEMATICS', 3, 'b', 'pass'),
(27, 'fortune', 'MATHEMATICS', 4, 'a', 'fail'),
(28, 'fortune', 'MATHEMATICS', 5, 'c', 'pass');

-- --------------------------------------------------------

--
-- Table structure for table `pquestions`
--

CREATE TABLE `pquestions` (
  `id` int(16) NOT NULL,
  `sn` int(16) NOT NULL,
  `title` varchar(150) NOT NULL,
  `question` text NOT NULL,
  `image` varchar(150) NOT NULL,
  `a` varchar(150) DEFAULT NULL,
  `b` varchar(150) DEFAULT NULL,
  `c` varchar(150) DEFAULT NULL,
  `d` varchar(150) DEFAULT NULL,
  `e` varchar(150) DEFAULT NULL,
  `answer` varchar(150) DEFAULT NULL,
  `department` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `level` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pquestions`
--

INSERT INTO `pquestions` (`id`, `sn`, `title`, `question`, `image`, `a`, `b`, `c`, `d`, `e`, `answer`, `department`, `type`, `level`) VALUES
(18, 1, 'MATHEMATICS', '<p>_________________ is used for <strong>subtraction</strong>?</p>\n', '', '+', '-', '%', '^', NULL, 'b', 'SCIENCE', 'FULLTIME', 'ND1'),
(19, 2, 'MATHEMATICS', '<p>_________________ is used for addition?</p>\n', '', '-', '%', '+', '/', NULL, 'c', 'SCIENCE', 'FULLTIME', 'ND1'),
(20, 3, 'MATHEMATICS', '<p>&nbsp;</p>\n\n<figure class="easyimage easyimage-full"><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOkAAAAlCAIAAAAof1l7AAAAAXNSR0IArs4c6QAAAAlwSFlzAAAOxAAADsQBlSsOGwAABWpJREFUeF7tXD124jAQNnsWSJGXE5ATkDRUadPhEpp0KbejgTJ026aiCT5BfII8isBdvDOWbGRbsv6NncjVvmWk+Wb0eTyjkTLKsiwKT/DAAD3wZ4CYA+TgAfRA4G7gwVA9ELg7yJU7b+9H99uzf+xJPBrFiZ4eHJM/nhEG7uqtSw+kkbfP0b/sczn2j2b2lmXzvQZ/Ad3f2xNUUdlhka7WmrTXMwi1hGc4HjhtptNNzg1fz2ERNTTw/k+mH5AuDjIhm99D3NV71a8tnaxX0dOjr4CLIX30sIvubmoaZi+bSC+InrfPx9e3mU9/Be769K7zuZP9buqLupCmYioCIZbzjG/uoq9v1QQb3gGYyi9zwz6DMrvykESqD1qLMCUM8yP9Wbe+ueBoUwTUrcbEVlTKthFBSG1bUujJ7TR9/7iQV2wyIS5OlcTmblAAH+KugpMishyQwKXHdTzaz7EQiXZ7Woict+s8XuHagiT+nBnGnHZFCHV6OykQy4VVbFOUwcDLvmAikyFXWKXpaoL7DJB9eH1skuVfNjb/mtLyo1m8ALORWi7qKKEiQRklRcVlkAAqKufVWBzdDk02oVJkMuh3jsGVKhaVRyL2dysPiRVxeCVDpY1EwF3U02C7M5O1UeKAkDOoftXOH+9p8cE+f3/Va/H8W6lRzojVtiiazRc1FRJUqsbJ5U7H1J/JcvU8icBdVb/B4hUlfkGYSy2SxDQfxnLGskRpUwTkrVRMUSsqVdMacs0dBXxbF3N2y8ulyYZA2WjN/S4YhXP5IFFaJR95HYkKXrqPlGcQTHJK8j9utqgOWqiITFHtTUiE1bWiZH13jEkRqjmSa5P1YJbSZb7bJW8L7UPjr6GPHQ/rPMnsXKGiwyh3BZ1Gk1agomIqVtNAIhfEMxIDnFTtNKQ4m0vPQD/S6J5ODOpMkYGfCHeF+x8KH0BLflde6sNmcyrpC6hcLA/9kMu/5JaGKDq/Gy2KYK4o5sAPea3W6DS2tgcNE2vBsEqzcbZcRlDOQ9yFvX1A1eir6+ru0BBdaEHe1gPI3UanUdIe1NbZ2jKtNRuhcCb1LKCCfyRbq1Oq7X1ObUPCgD55gO6RMZ1G5+gkLdNqsxE/AWXXc/cw2t/UTqmS94D7eD7q7NwxYUJLD/CzXZIICfcBihySo1uUoor7hw4yH1neZm2IgZMZTBruMlDU8yFmfsg3A5l6lG2Tk58WBxp30+NJxwXj5WcJqUY90VGk8eMTtFRfm2f9cdf7ao+qIbKXg/M7Y5OqFhhioKjnQ8z8oMII5G6z06gyUk9G3DLlNBvbpg45g57jByudv/BlJMS7R+XhvPynt1kedxudRsZg9QPHLV5q6R82m43t3mZjWC3itF/gcmLIYJnwE4GTnAGvdLAHi+nxajx/SY5impdB+UHt/Rx4hVkDzrafM4db8Q7L5sXf1RByTtyFIT9x9QduUxG7rtH4u4ZOR9mhqJvj93ahJXjmwMKlpKaFj+XU1xheniPDbzFeZjaPsHovMQZEvB5leMFAT5lTaeGFRNDic6/RzghETS+fY52erp6ZjfP+wm4zunIGEhPiTm79Y5rSoS67Va+MHmyjDmNTsbb5no/m1pJDH7qaKpzf1fOkpFFn3cTWQ2MjzcbaAcFmTA7ctVn/ythqg9DZtB4mggI5LbfahwO77onAXZfcGELeCInvQ5QfdiqfIcDmLFPgrkvu9n+uJJ68P52GVyDzPDuCzY3+e7x3CKFkqwev3mFsAgLUsNXQVTXu3SEh7hq7uN6o6+zvihoiTmJ43UriJjHdDe07bLG1gbuaTBhqow6Yu4vgUGnxPNgf7Nf0nHPxkDM4d2mYsCMP/AdldjdvWaE+6gAAAABJRU5ErkJggg==" width="233" />\n<figcaption></figcaption>\n</figure>\n\n<p>The formula above is used for calculating ..........................?</p>\n', '', 'Algebra', 'Calculus', 'Permutation', 'Statistics', NULL, 'b', 'SCIENCE', 'FULLTIME', 'ND1'),
(21, 4, 'MATHEMATICS', '<p>The&nbsp;<strong>-&nbsp;</strong>symbol between two number represents ______________?</p>\n', '', '', '', '', '', NULL, 'subtraction', 'SCIENCE', 'FULLTIME', 'ND1'),
(22, 5, 'MATHEMATICS', '<p>The formula below is used for calculating _____________?</p>\n\n<figure class="easyimage easyimage-full"><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQoAAAAxCAIAAACtY3BEAAAAAXNSR0IArs4c6QAAAAlwSFlzAAAOxAAADsQBlSsOGwAAB/9JREFUeF7tXT164jwQFt9ZIEWenICcALZJlTYdlNCk2zJdGihDlzYVTfAJlhPwpFi4C9+MRpZlW7YlW/hnJTcBLEszo3ml+ZMzul6vLFxBAkECOgn8F8Ry2T6O+LWMGIuW9Jl/CZfvEgjwiN6/ns+wh16vT/vRaM4O/PP5fr+9+K4cgf8AD8Ye7saoCJe/J8YWT7OgFEECsQQCPGav92/cnJrgLoI7CP/y87TioAmXzxIYBdfc5+kPvJdLIOweQUOCBAolEOARlCNIIMAj6ECQgL0Ewu5hL7PwhDcS8A4eMgko0n9Gfx5DDsQbRKQY9Q4e49XvBUlguqFsYPl1EK37rx4EfI5kkfuXmf+CNYHuK8+JJ4dUMXBjrqvU41+8f95MzQGCjY2QdDhQwr2TC6gEIpHWxWLBFkAJ4hr/4iekn1rQd3GDlwdsFvAr/ESP0xNDuVxznZtCNhRJuKXTBiCJXhXTkOiiWzote+NbndBw0vikAwIJoSMHd5KH0SpgSVILzR1ynZ1HT+FBWsKv5uulCX5a0BLcCWDzEMt/Hh1yL9HBQH20FVrdDeKY69Rseud7SB9i9kEA2c2bmdqX7cv64XcfKlAu31/H6f2Ec4gFZKKWjH+P9ju6lb1BrYGHIzv9HWIRpmuux6vP56+XOBbjDsUD7MnGxipgT2eqdCQJhZTYYTosYvcj3jJEo/iG9E2yT3TEg/2wt+Ba9mlkXJV7pz2xu+0FS56phZeeH6JPNklqHoTpSODgTAqrSzCcOCjxnfSNetLs4KnbcB3joxIeZoGbAUOkCUD6hI4OVPMfHlLgIw2PWFVkEMPC6+yRlWE7bXW9dLOlw5aaIbcnSTaNgPVAroIE1TWPlpP1A+7GwCS5ddH7mj3/Mjv3MHvdsPV7L46gQlbMKs9d10s//xxT/m//U4cNKawULJfk1FRlGlJzy8fHdw/s+HNO4HHZvu2mm1c8LDf7uH7gXwx3mLOKPQ4z+IEc08ZpFcbCIFAcKbrlVA2pb21gzJaB8erP9U/HscDJ/RS0meCBmfkJhPaO64koSxDBwOziWFqAAD0ev77dBAeTMojldvvYLPRqNDsQzxMAMd54cPPQXnWIV+s+JAXqj4oM5Psi+vfKCJAJnEcWBBpKMsMOfaVn6TOwHrcx7NJoyksb0fZB8AC4Jl6mitv04njZvrNPML0QBDBz+ycwxPg2Qxf2WKUvuQpAHb/QtzDzwNBj6zUTwfzmTJf1AELgprMVxNXcAnVei3i0a5lMauc7gtnZzYWoouX8JNLhvSsIA3tjwfYj1Awg2UiSOXbinRylQJ93c94j77Jl+z12BDWedYGzXVyA4MY7V8OQ+hIInfOaRBVyEDD3FNNDV/nIunBdLeK1rmjmx+QrDptnyeHSkebbRrAp7g2jmRp2VNZTYsh1eTOuRc1a7HsA7HVeJngnOQrGv56hdkGTJ+av+mh88Swo+UC4Fmeyv6mXUqljob1aAHVTM5bnjhcHZT+0ZqaceOvutA+AZ3h4QCs49TKuKixb3E+PaiFY5F7Kz9Qz07NjKCoLrqqaakcU8EBecu+wmT0tNL52cQFCcSCn5JCF1piUJguEztCWjUmHsemlVOfNqWEtSE4aDsBBfRYRbzjjajPd6kQ2B2X7TvNeva6OHA+xruEqZxjX6Sk7wIhwzZVqHWV6AB9Z8zFavrDP2KyMlqrPrIUY9aauQBkUa5d2CoABqOY7HhuKlhxFuDqR8jmPkgnj32rnoOBGLhRRRDw/jiG9THVZwP04MarBC0Wx8k169yaKf3CdIG1LgqvFvl4NJDp4BC0QcaE4j8LCoLVRyzi07is7tPlRWrDQTFTTgtwPVKoUMsWubhyPmBoUszjAIEdVjiykilNz26Y1KXpzvmo71oot9pazxB82dByDpCary+MxFAtfKSFWXG/pbaTc8eblxpVMqg1KBYsnRw6iRkdxjioYz7OjSFCWVXPu1RtWZNdpTD4Ph0eZE2VWN2HWqg6Z6jPKKBbp/MpRa4KDapnM/X4F0jBiu4rdqmblBJ7MW7uMN+GaVgKER2WIoVx/amtXpd7qtgXSK3dwtAtWZSiqlFyqvdQN+oDLqr0I6j7R4izppk0WDrfLeG2uxcwytJgsVsC6s+PqObkXu1l9G4HDZGVR+E4sE2LCDQeGgrXc6Ax7NWvWHeO1uY6X38qKXTMJDLNVU3BY4qNLIVm7Y10S62zsulxL48Tf04IQM+GZaqtgVS6+A4WY092+F4WYZbGngrSWg3BVn7uoyzVW4orMmzOkDqwjC6u0Yg1y5wfdTIQDIPEGvNfkWp1uT3cPKPSB8uRPo6rQqmIArNVirpOUThdl9Ti204573Vk9rkEz2CFJxt0AtX3v0s7l4H50tRtd18xtQ1hp2nI5lzZI6GAMe67z241/rnlJiV3xYlgNjw7m33TI1KzXtDhMx+pPOydc+waPWuAYUuRbl3TIwH7QWDfEXyoZz/mvxXX471C9tp8Dcd1KwFPXvFuhh9GHIoEAD7OZwsOcLRzpNSMmtGpLAgEesaQ1Z1KU885vJ3pdXLi8koB/8Cg6fqA5k0Lhb35Y5/PZK7UIzJIEvINH9M2Pc4nT/fkAR1CMIIFEAt7BY7ZaMX4kGt+xAkU58uhroXEV1MVfCXgHD5hqeSQaXzsDL2Xa8gOrhcaVv8oROPcQHvJfXeDso5F1V1F6hVErfEketLV7OWlQr6FLIKQFhz6Dgf4bSuB/y7TXhKIGSDkAAAAASUVORK5CYII=" width="266" />\n<figcaption></figcaption>\n</figure>\n\n<p>&nbsp;</p>\n', '', 'Surd', 'Law', 'Calculus', 'Log', NULL, 'c', 'SCIENCE', 'FULLTIME', 'ND1');

-- --------------------------------------------------------

--
-- Table structure for table `ptimer`
--

CREATE TABLE `ptimer` (
  `id` int(16) NOT NULL,
  `username` varchar(150) NOT NULL,
  `title` varchar(150) NOT NULL,
  `h` varchar(150) NOT NULL,
  `m` varchar(150) NOT NULL,
  `s` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ptimer`
--

INSERT INTO `ptimer` (`id`, `username`, `title`, `h`, `m`, `s`) VALUES
(5, 'nexlord', 'MATHEMATICS', '0', '0', '0'),
(6, 'fortune', 'MATHEMATICS', '0', '0', '0'),
(8, 'ceo@exami.com.ng', 'MATHEMATICS', '0', '4', '58');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(16) NOT NULL,
  `sn` int(16) NOT NULL,
  `title` varchar(150) NOT NULL,
  `question` text NOT NULL,
  `image` varchar(150) NOT NULL,
  `a` varchar(150) DEFAULT NULL,
  `b` varchar(150) DEFAULT NULL,
  `c` varchar(150) DEFAULT NULL,
  `d` varchar(150) DEFAULT NULL,
  `e` varchar(150) DEFAULT NULL,
  `answer` varchar(150) DEFAULT NULL,
  `department` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `level` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `id` int(16) NOT NULL,
  `title` varchar(150) NOT NULL,
  `start_date` date NOT NULL,
  `department` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `level` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sessioner`
--

CREATE TABLE `sessioner` (
  `id` int(25) NOT NULL,
  `username` varchar(150) NOT NULL,
  `sessioner_val` varchar(150) NOT NULL,
  `dos` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessioner`
--

INSERT INTO `sessioner` (`id`, `username`, `sessioner_val`, `dos`) VALUES
(163, 'Fortune', 'f4d8db38b4a89b4acf01adca56da2f8d', '2019-02-26'),
(165, 'MATHEWFORTUNE54@GMAIL.COM', '15fe6d7b71294efcd7ece77b7326bf06', '2019-02-26'),
(170, 'STAFF@YABATECH.EDU.NG', '0f1044ca9630f4dd43417ced6efd2e8d', '2019-03-11');

-- --------------------------------------------------------

--
-- Table structure for table `staffs`
--

CREATE TABLE `staffs` (
  `id` int(16) NOT NULL,
  `image` varchar(150) DEFAULT NULL,
  `surname` varchar(150) DEFAULT NULL,
  `othernames` varchar(150) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `department` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `level` varchar(150) NOT NULL,
  `rand1` varchar(150) DEFAULT NULL,
  `rand2` varchar(150) DEFAULT NULL,
  `rand3` varchar(150) DEFAULT NULL,
  `rand4` varchar(150) DEFAULT NULL,
  `rand5` varchar(150) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL,
  `root` varchar(150) NOT NULL,
  `dor` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffs`
--

INSERT INTO `staffs` (`id`, `image`, `surname`, `othernames`, `email`, `department`, `type`, `level`, `rand1`, `rand2`, `rand3`, `rand4`, `rand5`, `password`, `root`, `dor`) VALUES
(3, '5c747f8f868c0', 'YABATECH', 'YABA', 'STAFF@YABATECH.EDU.NG', 'SCIENCE', 'FULLTIME', 'ND1', '1582285611', '1288664155', '1262067110', '883842882', '866032998', '007e858ce196128092e0cb8ceda2a34e', 'true', '2019-02-24');

-- --------------------------------------------------------

--
-- Table structure for table `staff_login_dump`
--

CREATE TABLE `staff_login_dump` (
  `id` int(25) NOT NULL,
  `username` varchar(150) NOT NULL,
  `sessionid` varchar(150) NOT NULL,
  `dol` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_login_dump`
--

INSERT INTO `staff_login_dump` (`id`, `username`, `sessionid`, `dol`) VALUES
(45, 'STAFF@YABATECH.EDU.NG', '7ea98a719a8645d49ff99008132573e3', '2019-02-24'),
(46, 'STAFF@YABATECH.EDU.NG', '9ed1867e352c8327b2871c445709726a', '2019-02-24'),
(47, 'STAFF@YABATECH.EDU.NG', '3e8a30c313686466cd75f19507a1160d', '2019-02-24'),
(48, 'STAFF@YABATECH.EDU.NG', 'd6c41db213798a201b99ff5895d4e90e', '2019-02-26'),
(49, 'STAFF@YABATECH.EDU.NG', '7d5ea38f446706733b078732a22a0157', '2019-03-04'),
(50, 'STAFF@YABATECH.EDU.NG', 'a312a85f877bd72cb156dd9910001e58', '2019-03-04'),
(51, 'STAFF@YABATECH.EDU.NG', '99a488d7f8355bf403c9a2cbc3b562a6', '2019-03-11'),
(52, 'STAFF@YABATECH.EDU.NG', '4343410d454f10731b5ef8fe5bfaf910', '2019-03-11'),
(53, 'STAFF@YABATECH.EDU.NG', '0f1044ca9630f4dd43417ced6efd2e8d', '2019-03-11');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(16) NOT NULL,
  `surname` varchar(150) NOT NULL,
  `othernames` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `department` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `level` varchar(150) NOT NULL,
  `rand1` varchar(150) NOT NULL,
  `rand2` varchar(150) NOT NULL,
  `rand3` varchar(150) NOT NULL,
  `rand4` varchar(150) NOT NULL,
  `rand5` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `dor` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `surname`, `othernames`, `username`, `department`, `type`, `level`, `rand1`, `rand2`, `rand3`, `rand4`, `rand5`, `password`, `dor`) VALUES
(4, 'MATHEW', 'FORTUNE', 'MATHEWFORTUNE54@GMAIL.COM', 'SCIENCE', 'FULLTIME', 'ND1', '2006685636', '583170265', '393888748', '1225130849', '324372898', '1d0add38be1bd9889e545c2083b3654d', '2019-02-24');

-- --------------------------------------------------------

--
-- Table structure for table `student_login_dump`
--

CREATE TABLE `student_login_dump` (
  `id` int(25) NOT NULL,
  `username` varchar(150) NOT NULL,
  `sessionid` varchar(150) NOT NULL,
  `dol` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_login_dump`
--

INSERT INTO `student_login_dump` (`id`, `username`, `sessionid`, `dol`) VALUES
(1, 'MATHEWFORTUNE54@GMAIL.COM', '15fe6d7b71294efcd7ece77b7326bf06', '2019-02-26');

-- --------------------------------------------------------

--
-- Table structure for table `timer`
--

CREATE TABLE `timer` (
  `id` int(16) NOT NULL,
  `username` varchar(150) NOT NULL,
  `title` varchar(150) NOT NULL,
  `h` varchar(150) NOT NULL,
  `m` varchar(150) NOT NULL,
  `s` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `admin_login_dump`
--
ALTER TABLE `admin_login_dump`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_table`
--
ALTER TABLE `exam_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `keytable`
--
ALTER TABLE `keytable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay_ref`
--
ALTER TABLE `pay_ref`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pexam_table`
--
ALTER TABLE `pexam_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pquestions`
--
ALTER TABLE `pquestions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ptimer`
--
ALTER TABLE `ptimer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessioner`
--
ALTER TABLE `sessioner`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `staffs`
--
ALTER TABLE `staffs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`department`,`type`,`level`);

--
-- Indexes for table `staff_login_dump`
--
ALTER TABLE `staff_login_dump`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `student_login_dump`
--
ALTER TABLE `student_login_dump`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timer`
--
ALTER TABLE `timer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `admin_login_dump`
--
ALTER TABLE `admin_login_dump`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `exam`
--
ALTER TABLE `exam`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `exam_table`
--
ALTER TABLE `exam_table`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `keytable`
--
ALTER TABLE `keytable`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pay_ref`
--
ALTER TABLE `pay_ref`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pexam_table`
--
ALTER TABLE `pexam_table`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `pquestions`
--
ALTER TABLE `pquestions`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `ptimer`
--
ALTER TABLE `ptimer`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sessioner`
--
ALTER TABLE `sessioner`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;
--
-- AUTO_INCREMENT for table `staffs`
--
ALTER TABLE `staffs`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `staff_login_dump`
--
ALTER TABLE `staff_login_dump`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `student_login_dump`
--
ALTER TABLE `student_login_dump`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `timer`
--
ALTER TABLE `timer`
  MODIFY `id` int(16) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
